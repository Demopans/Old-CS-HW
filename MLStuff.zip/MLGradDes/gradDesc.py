import numpy as np
import multiprocessing as mp
import math


def f(x, y):
    return pow(x, 2) + 2 * pow(y, 2) + 2 * math.sin(2 * np.pi * x) * math.sin(2 * np.pi * y)


def gf(x, y):
    return 2 * x + 4 * np.pi * math.cos(2 * np.pi * x) * math.sin(2 * np.pi * y), 4 * y + 4 * np.pi * math.sin(
        2 * np.pi * x) * math.cos(2 * np.pi * y)


def gd(d):
    x, y, i, n = d
    x0, y0 = x,y
    for itr in range(i):
        gx, gy = gf(x, y)
        dirx, diry = n * gx, n * gy
        x -= dirx
        y -= diry
    return f(x, y), x0, y0, x, y


if __name__ == '__main__':
    pts = [(0.1, 0.1), (1, 1), (-.5, -.5), (-1, -1)]
    t = [(0.1, 0.1), (1, 1), (-.5, -.5), (-1, -1)]
    # start multiple worker processes to save time
    ps = mp.Pool(processes=4)
    data = ps.map(gd, [(*i, 50, 0.01) for i in t])
    ps.close()
    print("")
    print("\n")
    print("\n")
    i = gd((0.1,0.1,50,0.01))
    print(f"\nval: {i[0]:.2}, (x0,y0): ({i[1]},{i[2]}), (x,y): ({i[3]:.2},{i[4]:.2})")

    print("")
    for i in data:
        print(f"val: {i[0]:.2}, (x0,y0): ({i[1]},{i[2]}), (x,y): ({i[3]:.2},{i[4]:.2})")
