import threading
from multiprocessing.pool import ThreadPool
import threading as thr
from typing import Iterable

import matplotlib as mpl

import numpy as np
import matplotlib.pyplot as plt
import multiprocessing as mp
from matplotlib.colors import ListedColormap
from sklearn import neighbors  # only want plotting funcs


class LinkedHashSet:  # done better in c++, but lazy
    links: list = []
    sett: set = set()

    def __init__(self, iterable: Iterable = None) -> None:
        self.links = list(iterable) if iterable is not None else []
        self.sett = set(iterable) if iterable is not None else set()

    def add(self, element: object) -> None:  # only needs this for the scope of this assignment
        self.links.append(element)
        self.sett.add(element)

    def __getitem__(self, i):  # no setitem as out of scope
        return self.links[i]

    def clear(self):
        self.links.clear()
        self.sett.clear()

    def __len__(self):
        return len(self.links)

    def __contains__(self, item):
        return self.sett.__contains__(item)

    def __iter__(self):
        self.i = 0
        return self

    def __next__(self):
        if self.i < len(self):
            result = self.links[self.i]
            self.i += 1
            return result
        else:
            raise StopIteration


def sixpoint1():
    X = np.array([[1, 0], [0, 1], [0, -1], [-1, 0], [0, 2], [0, -2], [-2, 0]])
    Y = np.array([-1, -1, -1, -1, 1, 1, 1])
    k1 = 1
    k3 = 3

    def knn():
        # knn learn
        knn1 = neighbors.KNeighborsClassifier(k1, weights='distance')
        knn3 = neighbors.KNeighborsClassifier(k3, weights='distance')
        knn1.fit(X, Y)
        knn3.fit(X, Y)
        xx, yy = np.meshgrid(np.arange(-4, 5, .1),
                             np.meshgrid(np.arange(-4, 5, .1)))
        f1 = knn1.predict(np.c_[xx.ravel(), yy.ravel()])
        f3 = knn3.predict(np.c_[xx.ravel(), yy.ravel()])
        f1 = f1.reshape(xx.shape)
        f3 = f3.reshape(xx.shape)
        plt.figure()
        plt.xlim(-4, 4)
        plt.ylim(-4, 5)
        plt.pcolormesh(xx, yy, f1, cmap=ListedColormap(['#FFAAAA', '#AAFFAA']))
        plt.title("k=1")
        plt.scatter(X[:, 0], X[:, 1], c=Y, cmap=ListedColormap(['#cc0000', '#00cc00']))
        plt.show()
        plt.title("k=3")
        plt.pcolormesh(xx, yy, f3, cmap=ListedColormap(['#FFAAAA', '#AAFFAA']))
        plt.scatter(X[:, 0], X[:, 1], c=Y, cmap=ListedColormap(['#cc0000', '#00cc00']))
        plt.show()

    knn()
    # use new calced def
    X = np.array(
        [[1, 0], [1, np.pi / 2], [1, np.pi], [1, 3 * np.pi / 2], [2, 3 * np.pi / 2], [2, np.pi / 2], [2, np.pi]])
    Y = np.array([-1, -1, -1, -1, 1, 1, 1])
    knn()


def sixpoint4():
    rad = 10
    thk = 5
    sep = 5

    def init():
        from numpy.random import rand
        d0 = [(thk * rand() + rad, np.pi * rand()) for _ in range(1000)]  # polar x,r
        d1 = [(thk * rand() + rad, -1 * np.pi * rand()) for _ in range(1000)]
        d0 = [(a * np.cos(b), a * np.sin(b)) for a, b in d0]
        d1 = [(a * np.cos(b) + (rad + thk / 2.0), a * np.sin(b) - sep) for a, b in d1]

        return np.array(d0 + d1), [1 for _ in range(1000)] + [-1 for _ in range(1000)]

    def knn():
        # knn learn
        knn1 = neighbors.KNeighborsClassifier(1, weights='distance')
        knn1.fit(X, Y)
        knn3 = neighbors.KNeighborsClassifier(3, weights='distance')
        knn3.fit(X, Y)
        xx, yy = np.meshgrid(np.arange(-21, 29, .1),
                             np.meshgrid(np.arange(-21, 29, .1)))
        f1 = knn1.predict(np.c_[xx.ravel(), yy.ravel()])
        f1 = f1.reshape(xx.shape)
        f3 = knn3.predict(np.c_[xx.ravel(), yy.ravel()])
        f3 = f3.reshape(xx.shape)
        plt.figure()
        plt.xlim(-21, 29)
        plt.ylim(-21, 29)

        plt.pcolormesh(xx, yy, f1, cmap=ListedColormap(['#FFAAAA', '#AAFFAA']))
        plt.title("k=1")
        plt.scatter(X[:, 0], X[:, 1], c=Y, cmap=ListedColormap(['#cc0000', '#00cc00']))
        plt.show()

        plt.pcolormesh(xx, yy, f3, cmap=ListedColormap(['#FFAAAA', '#AAFFAA']))
        plt.scatter(X[:, 0], X[:, 1], c=Y, cmap=ListedColormap(['#cc0000', '#00cc00']))
        plt.title("k=3")
        plt.show()

    X, Y = init()

    knn()


def sixpoint16():
    import time
    # uniform random
    def init():
        from numpy.random import rand
        return np.array([[rand(), rand()] for _ in range(10000)])

    # gaussian
    def initt():
        from numpy.random import normal
        return np.array([[normal(), normal()] for _ in range(10000)])

    def par10(X: np.ndarray):
        centers = LinkedHashSet()
        t = X[np.random.choice([_ for _ in range(10000)])]
        centers.add(tuple(t))
        t = centers[0]
        furtherest = t

        for j in X:
            if np.linalg.norm(np.array(furtherest) - np.array(t)) < np.linalg.norm(j - np.array(t)) \
                    and tuple(j) not in centers:
                furtherest = j
        centers.add(tuple(furtherest))

        # add pts furthest from current centers
        for i in range(8):
            bestest = centers[1], 0
            for j in X:
                if tuple(j) not in centers:  # j is query pt
                    # evaluate pt
                    distances = [np.linalg.norm(j - np.array(ii)) for ii in centers]
                    # maximize average/std
                    metric = np.average(distances) / np.std(distances)
                    bestest = (j, metric) if metric > bestest[1] else bestest

            centers.add(tuple(bestest[0]))
        a = [np.array(_) for _ in list(centers)]

        # assign to cluster
        cluster = [[] for _ in range(10)]
        for x in X:
            # find nearest
            bestest = 0, a[0]
            for i, j in enumerate(a):
                bestest = (i, j) if np.linalg.norm(j - x) < np.linalg.norm(bestest[1] - x) else bestest
            # assign
            cluster[bestest[0]].append(x)

        return [(a[i], cluster[i]) for i in range(10)]

    def bruteForce(X, Z):
        start = time.time()
        for z in Z:
            bestest = X[0]
            for x in X:
                bestest = x if np.linalg.norm(x - z) < np.linalg.norm(bestest - z) else bestest
        end = time.time()
        print("bruteforce")
        print(end - start)

    def brnb(X, Z, centers):
        start = time.time()
        # search closest 3 centers
        bestest = centers[0]
        best = centers[0]
        bes = centers[0]
        for z in Z:
            sort = lambda x: np.linalg.norm(x[0] - z)
            cenSort = sorted(centers, key=sort)
            # search through first 3.
            bestest = cenSort[0][1][0]
            for i in range(0,2):
                lookup = cenSort[i][1]
                for x in lookup:
                    bestest = x if np.linalg.norm(x - z) < np.linalg.norm(bestest - z) else bestest
        end = time.time()
        print("Bounding")
        print(end - start)



    X = init()
    centers = par10(X)

    # query centers
    Z = init()

    # this is annoying
    a = thr.Thread(target=bruteForce, args=(X, Z))
    b = thr.Thread(target=brnb, args=(X, Z, centers))
    a.start()
    b.start()
    a.join()
    b.join()


    # do the same for gaussian
    X = initt()
    centers = par10(X)

    # query centers
    Z = initt()

    # this is annoying
    a = thr.Thread(target=bruteForce, args=(X, Z))
    b = thr.Thread(target=brnb, args=(X, Z, centers))
    a.start()
    b.start()
    a.join()
    b.join()

if __name__ == '__main__':
    print("\n")
    np.random.seed(0)

    sixpoint16()
