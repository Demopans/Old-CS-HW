class HW6:
    @staticmethod
    def pla(w, d, y):
        wpla = np.reshape(np.frombuffer(w, dtype=np.float64), -1)
        Xt = np.vstack((d.T, np.array(2000 * [1.]))).T

        eta = 1
        epochs = 0
        wpla.fill(.0)
        flag = lambda i: 1 if ((np.dot(Xt[i], wpla[:3]) * y[i]) <= 0) else 0
        # lambda: (Xt @ w) @ y
        p = None
        while c := sum([flag(i) for i in range(len(y))]):
            p = (wpla, c) if p is None or p[1] > c else p
            for i, g in enumerate(y):
                if flag(i) != 0:
                    wpla[:3] = wpla[:3] + eta * Xt[i] * g
                    epochs += 1

        wpla[3] = epochs
        print(epochs)

    @staticmethod
    def svm(w, d, y):
        wpla = np.reshape(np.frombuffer(w, dtype=np.float64), -1)
        wpla.fill(0.0)
        eta = 1
        epochs = 100000
        Xt = d

        for epoch in range(1, epochs):
            for i, x in enumerate(Xt):
                if (y[i] * np.dot(Xt[i], w)) < 1:
                    w = w + eta * ((Xt[i] * Xt[i]) + (-2 * (1 / epoch) * w))
                else:
                    w = w + eta * (-2 * (1 / epoch) * w)

        wlr = np.reshape(np.frombuffer(w, dtype=np.float64), -1)
        wlr[0], wlr[1] = w[0], w[1]

    @staticmethod
    def lr(w, d, y):
        wlr = np.reshape(np.frombuffer(w, dtype=np.float64), -1)
        t = np.linalg.pinv(d) @ y  # Xt y
        wlr[0], wlr[1] = t[0], t[1]

    @staticmethod
    def m():
        rad = 10
        thk = 5
        sep = 5

        def init():
            from numpy.random import rand
            d0 = [(thk * rand() + rad, np.pi * rand()) for _ in range(1000)]  # polar x,r
            d1 = [(thk * rand() + rad, -1 * np.pi * rand()) for _ in range(1000)]
            d0 = [(a * np.cos(b), a * np.sin(b)) for a, b in d0]
            d1 = [(a * np.cos(b) + (rad + thk / 2.0), a * np.sin(b) - sep) for a, b in d1]

            return np.array(d0 + d1)

        def plot(wpla, wlr, wlr2, dataset):
            import wxmplot as wxmi
            import wx

            dataset0 = dataset[:1000]
            dataset1 = dataset[1000:]

            app = wx.App()
            frame = wxmi.PlotFrame()
            frame.plot(x=[0], y=[0], delay_draw=False, show_legend=True, legend_loc='ul', viewpad=10,
                       linewidth=0, xlabel='x', ylabel='y', label=' ')
            frame.oplot(x=dataset0.T[0], y=dataset0.T[1], label='-1', linewidth=0, marker='x', delay_draw=False)
            frame.oplot(x=dataset1.T[0], y=dataset1.T[1], label='+1', linewidth=0, marker='o', delay_draw=False)

            # pla w to ax+b
            xp = np.linspace(-30, 30, 100)
            a, b = wpla[0] / wpla[1], wpla[2] / wpla[1]
            yp = a * xp + b
            frame.oplot(x=xp, y=yp, label=f'PLA: {a:.1}x+{b:.1}', linewidth=1,
                        marker=' ', delay_draw=False)

            # lr
            yl = wlr[0] * xp + wlr[1]
            frame.oplot(x=xp, y=yl, label=f'LR (projection from R3): {wlr[0]:.1}x+{wlr[1]:.1}', linewidth=1, marker=' ',
                        delay_draw=False)

            yl2 = wlr2[0] * xp + wlr2[1]
            frame.oplot(x=xp, y=yl2, label=f'LR (R2): {wlr[0]:.1}x+{wlr[1]:.1}', linewidth=1, marker=' ',
                        delay_draw=False)

            frame.Show()
            app.MainLoop()

        y = 1000 * [-1] + 1000 * [1]
        dataset = init()

        w1, w2, w3 = mp.RawArray('d', 2), mp.RawArray('d', 4), mp.RawArray('d', 2)
        p1 = mp.Process(target=HW6.lr, args=(w1, dataset, y))
        p2 = mp.Process(target=HW6.pla, args=(w2, dataset, y))
        p3 = mp.Process(target=HW6.lr, args=(w3, np.vstack([dataset.T[0], np.ones(2000)]).T,
                                             dataset.T[1][:, np.newaxis]))

        p2.start()
        p1.start()
        p3.start()

        p1.join()
        p2.join()
        p3.join()

        wlr = np.reshape(np.frombuffer(w1, dtype=np.float64), -1)
        wpla, epla = (x := np.reshape(np.frombuffer(w2, dtype=np.float64), -1))[:3], x[3]
        wlr2 = np.reshape(np.frombuffer(w3, dtype=np.float64), -1)

        plot(wpla, wlr, wlr2, dataset)

    @staticmethod
    def m2():
        rad = 10
        thk = 5
        max = 26

        def init(s):
            from numpy.random import rand
            dataset0 = [(thk * rand() + rad, np.pi * rand()) for _ in range(1000)]  # polar x,r
            dataset1 = [(thk * rand() + rad, -1 * np.pi * rand()) for _ in range(1000)]
            dataset = [(a * np.cos(b), a * np.sin(b)) for a, b in dataset0] + [
                (a * np.cos(b) + (rad + thk / 2.0), a * np.sin(b) - s) for a, b in dataset1]

            return np.array(dataset)

        def plot(es):
            import wxmplot as wxmi
            import wx

            app = wx.App()
            frame = wxmi.PlotFrame()
            frame.plot(x=[0], y=[0], delay_draw=False, show_legend=True, legend_loc='ul', viewpad=10,
                       linewidth=0, xlabel='sep', ylabel='Epochs', label=' ')
            frame.oplot(x=[i * 2 / 10. for i in range(max)], y=es, label='Epochs', linewidth=0, marker='x',
                        delay_draw=False)

            frame.Show()
            app.MainLoop()

        y = 1000 * [-1] + 1000 * [1]
        d1 = init(0.1)

        ws = [mp.RawArray('d', 4) for _ in range(max)]
        ps = [mp.Process(target=HW6.pla, args=(w, init(i * 2 / 10.), y)) for i, w in enumerate(ws)]
        for p in ps: p.start()
        for p in ps: p.join()
        wplas, eplas = np.transpose([((x := np.reshape(np.frombuffer(w, dtype=np.float64), -1))[:3], x[3]) for w in ws])
        plot(eplas)