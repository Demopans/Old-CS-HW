def expandedString(inputStr):
    # Write your code here
    """import re
    regexStr = '\((.*?)\)'
    regexNum = '\{(.*?)\}'
    r0 = re.compile(regexStr)
    r1 = re.compile(regexNum)
    m0 = [_ for _ in re.finditer(r0, inputStr)]
    m1 = [_ for _ in re.finditer(r1, inputStr)]
    out = ''
    for s,i in zip(m0,m1):
        out=f'{out}{s*i}'"""

    out0 = []
    ct = 0
    brack = False
    cache = ''
    c0 = ''
    c1 = ''
    ct2 = 0
    out = ''
    for ii, i in enumerate(inputStr):
        if i == '(':
            if ct>=1:
                cache = cache + i
            else:
                out0 += [(cache, 1)]
                cache = ''
            ct += 1
        elif i == ')':
            if ct == 1:
                c0 = cache
                cache = ''
                brack = True
                ct = 0
            else:
                ct -= 1
                cache = cache + i
        elif i == '{':
            if ct>=1:
                cache = cache + i
        elif i == '}' and brack:
            out0 += [(c0, cache)]
            cache = ''
            brack = False
        else:
            cache = cache + i

    for i in out0:
        if ('(' not in i[0]) or (')' not in i[0]) or ('{' not in i[0]) or ('}' not in i[0]):
            out += i[0]*int(i[1])
        else:
            out += expandedString(i[0])*int(i[1])
    return out


if __name__ == '__main__':
    expandedString('(ab){3}(cd(42){4}){2}')
