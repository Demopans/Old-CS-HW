import multiprocessing as mp
from multiprocessing.dummy import Pool as ThreadPool
from typing import Any

import matplotlib.pyplot as plt
import cupy
import numpy as np
import pandas
import sklearn
import tensorflow as tf

from matplotlib.colors import ListedColormap
from NNet import NNet, Params
from RBFNet import RBFNet

np_ones_16_16 = np.ones(16) / 16


def readData():
    def a(imgV):
        vM = []

        for i in range(16):
            vM += [imgV[16 * i:16 * i + 16]]

        return vM

    def process(file, X, Y):
        for l in file.readlines():
            a = [float(i) for i in l[:len(l) - 2].split(' ')]
            Y += a[:1]
            X += [a[1:]]
        return X, Y

    trainAug = open('ZipDigits-1-5.train', 'r')
    testAug = open('ZipDigits-1-5.test', 'r')

    trainX, trainY, testX, testY = [], [], [], []

    trainX, trainY = process(trainAug, trainX, trainY)
    testX, testY = process(testAug, testX, testY)

    return [np.array(a(i)).T for i in trainX], np.array([1 if i == 1 else -1 for i in trainY]), \
           [np.array(a(i)).T for i in testX], np.array([1 if i == 1 else -1 for i in testY])


# <editor-fold desc="hardcoded legrence transforms. derived with paper to save on calc time later on">

l = lambda x, p: sum([j * x ** i for i, j in enumerate(p)])
l1 = lambda x: l(x, [0, 1])
l2 = lambda x: l(x, [-.1 / 2, 0, 3 / 2])
l3 = lambda x: l(x, [0, -3 / 2, 0, 5 / 2])
l4 = lambda x: l(x, [.375, 0, -3.75, 0, 4.375])
l5 = lambda x: l(x, [0, 1.875, 0, -8.75, 0, 7.875])
l6 = lambda x: l(x, [-.3125, 0, 6.5625, 0, -19.6875, 0, 14.4375])
l7 = lambda x: l(x, [0, 2.1875, 0, 19.875, 0, -43.3125, 0, 26.8125])
l8 = lambda x: l(x, [35 / 128, 0, 1260 / 128, 0, 6930 / 128, 0, 12012 / 128, 0, 6435 / 128])


# </editor-fold>
def transform(D):
    return [
        [
            1,
            l1(d[0]), l1(d[1]),
            l2(d[0]), l1(d[0]) * l1(d[1]), l2(d[1]),
            l3(d[0]), l2(d[0]) * l1(d[1]), l2(d[0]) * l3(d[1]), l3(d[1]),
            l4(d[0]), l3(d[0]) * l1(d[1]), l2(d[0]) * l2(d[1]), l1(d[0]) * l3(d[1]), l4(d[1]),
            l5(d[0]), l4(d[0]) * l1(d[1]), l3(d[0]) * l2(d[1]), l2(d[0]) * l3(d[1]), l1(d[0]) * l4(d[1]), l5(d[1]),
            l6(d[0]), l5(d[0]) * l1(d[1]), l4(d[0]) * l2(d[1]), l3(d[0]) * l3(d[1]), l2(d[0]) * l4(d[1]),
                      l1(d[0]) * l5(d[1]), l6(d[1]),
            l7(d[0]), l6(d[0]) * l1(d[1]), l5(d[0]) * l2(d[1]), l4(d[0]) * l3(d[1]), l3(d[0]) * l4(d[1]),
                      l2(d[0]) * l5(d[1]), l1(d[0]) * l6(d[1]), l7(d[1]),
            l8(d[0]), l7(d[0]) * l1(d[1]), l6(d[0]) * l2(d[1]), l5(d[0]) * l3(d[1]), l4(d[0]) * l4(d[1]),
                      l3(d[0]) * l5(d[1]), l2(d[0]) * l6(d[1]), l1(d[0]) * l7(d[1]), l8(d[1])
        ]
        for d in D
    ]


eval = lambda Yp, Y: (len(Y) - Yp @ Y) / 2  # only counts misclassed

if __name__ == '__main__':
    print(
        "noiseafehigvouwkvjbg\n")  # clion python console has some buffering issue. This pads the first line so the rest displays normally


    # <editor-fold desc="Helpers">
    def eval(Yp, Y):
        return (len(Y) - Yp @ Y) / 2  # only counts misclassed


    def lr(X: np.ndarray, Y: np.ndarray, lam: float):
        aer = lambda X, lam: np.linalg.inv(X.T @ X + lam * np.identity(X.shape[1]))
        hatter = lambda X, lam: aer(X, lam) @ X.T
        H = hatter(X, lam)
        return (H @ Y), H


    def preProcessData():
        def cutDown(train, trainAug):
            for l in train.readlines():
                if l[0] == '1' or l[0] == '5':
                    trainAug.writelines([l])

        train = open('ZipDigits.train', 'r')
        test = open('ZipDigits.test', 'r''')

        trainAug = open('ZipDigits-1-5.train', 'w')
        testAug = open('ZipDigits-1-5.test', 'w')

        cutDown(train, trainAug)
        cutDown(test, testAug)


    def setup():
        np.random.seed(0)

        def c(D: list[np.ndarray]) -> tuple[list[np.ndarray], list[np.ndarray]]:
            cm = lambda i: i @ np_ones_16_16
            # list[std_dev], list[mean]
            return np.power([np.power((x := cm(A)) - x @ np_ones_16_16, 2) @ np.ones(16) for A in D], 0.5), \
                   [cm(A) @ np_ones_16_16 for A in D]

        global DtrX, DtrY, DteX, DteY, DtrZ, DteZ
        trX, trY, teX, teY = readData()
        X, Y = np.array(c(trX + teX)).T, np.concatenate((trY, teY))

        for i in range(len(X.T[0])):
            X[i, 0] /= 1.875  # based on the maximum possible val of the 2nd feature
            X[i, 0] -= .9375

        X /= 0.9  # apparently, hypersaturation is a thing for nnets
        # z space transform
        Z = np.array(transform(X))
        # filter
        np.random.seed(0)
        f = np.random.choice([_ for _ in range(len(trY) + len(teY))], 300, False)
        DtrX, DtrY, DtrZ, DteX, DteY, DteZ = [], [], [], [], [], []

        for i, z in enumerate(Z):
            if i in f:
                DtrZ += [z]
                DtrY += [Y[i]]
                DtrX += [X[i]]
            else:
                DteZ += [z]
                DteY += [Y[i]]
                DteX += [X[i]]
        DtrX, DtrY, DteX, DteY, DtrZ, DteZ = np.array(DtrX), np.array(DtrY), np.array(DteX), np.array(DteY), np.array(
            DtrZ), np.array(DteZ)


    def drop1() -> tuple[list[np.ndarray], list[np.ndarray], list[int]]:
        DtrXs: list[np.ndarray]
        DtrYs: list[np.ndarray]
        iss: list[int]
        DtrXs, DtrYs, iss = [], [], []  # leave1out measures
        for i, d in enumerate(DtrX - 1):
            DtrXs += [np.concatenate((DtrX[:i], DtrX[i + 1:]))]
            DtrYs += [np.concatenate((DtrY[:i], DtrY[i + 1:]))]
            iss += [i]
        return (DtrXs, DtrYs, iss)


    # </editor-fold>

    def kmDebug(X, k):
        kmeans = sklearn.cluster.KMeans(n_clusters=k)

        # predict the labels of clusters.
        label = kmeans.fit_predict(X)

        # Getting unique labels
        u_labels = np.unique(label)
        centroids = kmeans.cluster_centers_

        # plotting the results:
        for i in u_labels:
            plt.scatter(X[label == i, 0], X[label == i, 1], label=i)
        plt.scatter(centroids[:, 0], centroids[:, 1], s=80, color='k')
        plt.legend()
        plt.show()

    setup()

    def pt1():
        nnet = NNet(arch=np.array([2, 2, 1]),
                    params=Params(
                        loss=lambda a, b: cupy.linalg.norm(a - b) / (4 * DtrY.shape[0]),
                        outputFunc=lambda x: x,
                        doutputFunc=Params.didenity,
                        epochs=1
                    )
                    )
        # 2pt to tease out errors
        nnet.fit(np.array([[1, 2], [1, 2]]), [1, 1])  # data vectors are horizontal

    def pt2():
        def aa():
            # also compare with keras.nnet?
            epochs = 100
            nnet = NNet(arch=np.array([2, 10, 1]),
                        params=Params(
                            loss=lambda a, b: cupy.linalg.norm(a - b) / (4 * DtrY.shape[0]),
                            outputFunc=lambda x: x,
                            doutputFunc=Params.didenity,
                            epochs=epochs,
                            lr=0.01
                        ))  # use defaults anyways
            errs = nnet.fit(DtrX, DtrY)
            plt.plot([_ for _ in range(epochs)], np.array(errs))
            plt.show()

        def cc():
            f = np.random.choice([_ for _ in range(300)], 250, False)
            TX, TY, VX, VY = [], [], [], []
            for i, z in enumerate(DtrX):
                if i in f:
                    VY += [DtrY[i]]
                    VX += [DtrX[i]]
                else:
                    TY += [DtrY[i]]
                    TX += [DtrX[i]]
            TX, TY, VX, VY = np.array(TX), np.array(TY), np.array(VX), np.array(VY)

            def nnetThread(epochs, X, VX, Y, VY):
                nnet = NNet(arch=np.array([2, 10, 1]),
                            params=Params(
                                loss=lambda a, b: cupy.linalg.norm(a - b) / (4 * DtrY.shape[0]),
                                outputFunc=lambda x: x,
                                doutputFunc=Params.didenity,
                                epochs=epochs,
                                lr=0.01
                            ))  # use defaults anyways
                nnet.fit(X,Y)
                return eval(nnet.predict(VX).T,VY)
            args = [((i+1)*50,TX, VX,TY, VY) for i in range(10)]  # measure between some vals
            outs = []
            with ThreadPool(mp.cpu_count()) as pool:
                outs = pool.starmap(nnetThread, args)
            print(outs)

        cc()

    def pt3():
        X = np.array([[1,0],[-1,0]])
        y = [1,0]
        transform = lambda a,b: np.array([np.power(a,3)-b,a*b]).T
        def predict(X):
            return transform(X[:,0],X[:,1])@np.array([1,0])  # no bias

        xx, yy = np.meshgrid(np.arange(-1, 1, .01), np.meshgrid(np.arange(-1, 1, .01)))
        r = np.c_[xx.ravel(), yy.ravel()]
        f3 = np.sign(predict(r))
        f3 = f3.reshape(xx.shape)
        plt.figure()
        plt.xlim(-1, 1)
        plt.ylim(-1, 1)
        plt.title("boundary")
        plt.pcolormesh(xx, yy, f3, cmap=ListedColormap(['#FFAAAA', '#AAFFAA']))
        plt.scatter(X[:, 0], X[:, 1], c=y, cmap=ListedColormap(['#cc0000', '#00cc00']))
        plt.show()

    def pt4():
        from sklearn.svm import SVC
        def aa():
            kernel = lambda x, xp: np.power(1 + np.dot(x, xp.T), 8)
            svm = SVC(kernel=kernel,C=0.01)
            svm.fit(DtrX, DtrY)

            xx, yy = np.meshgrid(np.arange(-1, 1, .01), np.meshgrid(np.arange(-1, 1, .01)))
            f3 = np.sign(svm.predict(np.c_[xx.ravel(), yy.ravel()]))
            f3 = f3.reshape(xx.shape)
            plt.figure()
            plt.xlim(-1, 1)
            plt.ylim(-1, 1)
            plt.title("boundary")
            plt.pcolormesh(xx, yy, f3, cmap=ListedColormap(['#FFAAAA', '#AAFFAA']))
            plt.scatter(DteX[:, 0], DteX[:, 1], c=DteY, cmap=ListedColormap(['#cc0000', '#00cc00']))
            plt.show()

            kernel = lambda x, xp: np.power(1 + np.dot(x, xp.T), 8)
            svm = SVC(kernel=kernel,C=10)
            svm.fit(DtrX, DtrY)

            xx, yy = np.meshgrid(np.arange(-1, 1, .01), np.meshgrid(np.arange(-1, 1, .01)))
            f3 = np.sign(svm.predict(np.c_[xx.ravel(), yy.ravel()]))
            f3 = f3.reshape(xx.shape)
            plt.figure()
            plt.xlim(-1, 1)
            plt.ylim(-1, 1)
            plt.title("boundary")
            plt.pcolormesh(xx, yy, f3, cmap=ListedColormap(['#FFAAAA', '#AAFFAA']))
            plt.scatter(DteX[:, 0], DteX[:, 1], c=DteY, cmap=ListedColormap(['#cc0000', '#00cc00']))
            plt.show()
        def bb():
            def packParams(data, ks):
                DtrXs, DtrYs, tmp = data
                knninputs: list[Any] = []
                for k, ll in enumerate(ks):
                    t = []
                    for i, v in enumerate(DtrXs):
                        knnargs = ((k + 1)/10,v, DtrYs[i], i)
                        t += [knnargs]
                    knninputs += [t]
                return knninputs

            def evalParams(args):
                # threadpool since process overhead is big, and there's no gui apps going on
                knnouts = []
                with ThreadPool(mp.cpu_count()) as pool:
                    for i in args:
                        tmp = pool.starmap(svmthread, i)
                        knnouts += [tmp]
                return knnouts

            def crossvalval(data, outs: list[list[tuple[SVC, int]]]):
                DtrXs, DtrYs, tmp = data
                cveval, ineval = [], []
                for i, knnp in enumerate(outs):
                    errs = 0
                    intr = 0
                    # sum up errors per k
                    for j in knnp:
                        # fetch and test missing x
                        ith = j[1]
                        xed = DtrX[ith]
                        yed = DtrY[ith]
                        errs += 1 if j[0].predict(np.reshape(xed, (1, 2)))[0] != yed else 0
                        # in sample error
                        for ii, k in enumerate(DtrXs):
                            # direct comps as a -1 return annihilates a +1 as well.
                            # Was not a problem last time as a score measure
                            intr += int((299 - j[0].predict(k) @ DtrYs[ii]) / 2)

                    cveval += [errs / 300]
                    ineval += [intr / 300 / 299]  # close enough for insample error anyways
                return cveval, ineval

            def plotl(X, X0, name=''):
                plt.title(name)
                plt.plot(X,[_/10 for _ in range(10)], label="Ecv")
                plt.plot(X0, label="Ein")
                plt.legend()
                plt.show()

            def svmthread(c,TX,TY,i):
                kernel = lambda x, xp: np.power(1 + np.dot(x, xp.T), 8)
                svm = SVC(kernel=kernel,C=c)
                svm.fit(TX, TY)
                return svm, i

            lambdas: list[float]
            data: tuple[list[np.ndarray], list[np.ndarray], list[int]]
            data = drop1()

            ks = [_ for _ in range(10)]  # good enough for something close to linear anyways
            knnArgs = packParams(data, ks)

            knnouts = evalParams(knnArgs)

            # run thrugh ls
            ycv, yin = crossvalval(data, knnouts)

            plotl(ycv, yin)
            # return best lamb
            print(ycv)

        def bbb():
            kernel = lambda x, xp: np.power(1 + np.dot(x, xp.T), 8)
            svm = SVC(kernel=kernel,C=0.1)
            svm.fit(DtrX, DtrY)

            xx, yy = np.meshgrid(np.arange(-1, 1, .01), np.meshgrid(np.arange(-1, 1, .01)))
            f3 = np.sign(svm.predict(np.c_[xx.ravel(), yy.ravel()]))
            f3 = f3.reshape(xx.shape)
            plt.figure()
            plt.xlim(-1, 1)
            plt.ylim(-1, 1)
            plt.title("boundary")
            plt.pcolormesh(xx, yy, f3, cmap=ListedColormap(['#FFAAAA', '#AAFFAA']))
            plt.scatter(DteX[:, 0], DteX[:, 1], c=DteY, cmap=ListedColormap(['#cc0000', '#00cc00']))
            plt.show()
        bbb()

    def pt5():
        def multitest(l, kknn, krbf):
            from sklearn.svm import SVC
            from sklearn.neighbors import KNeighborsClassifier
            wH = lr(np.array(transform(DtrX)), DtrY, l)
            f = lambda w: np.sign(np.array(transform(DteX)) @ w)
            lrEtest = eval(f(wH[0]), DteY)

            knn = KNeighborsClassifier(kknn, weights='distance')
            knn.fit(DtrX, DtrY)
            knnEtest = eval(knn.predict(DteX), DteY)

            rbf = RBFNet(DtrX, DtrY, 2, krbf)  # sussy
            rbf.fit()
            rbfEtest = eval(rbf.predict(DteX), DteY)

            nnet = NNet(arch=np.array([2, 10, 1]),
                        params=Params(
                            loss=lambda a, b: cupy.linalg.norm(a - b) / (4 * DtrY.shape[0]),
                            outputFunc=lambda x: x,
                            doutputFunc=Params.didenity,
                            epochs=150,
                            lr=0.001
                        ))  # use defaults anyways
            nnet.fit(DtrX,DtrY)
            nnetEtest = eval(rbf.predict(DteX), DteY)

            kernel = lambda x, xp: np.power(1 + np.dot(x, xp.T), 8)
            svm = SVC(kernel=kernel,C=0.1)
            svm.fit(DtrX, DtrY)
            svmEtest = eval(svm.predict(DteX), DteY)

            print(lrEtest, knnEtest, rbfEtest, nnetEtest, svmEtest)

        # used for comparison. if this does worse, then NNet is just as "bad".
        def bb():
            from sklearn.neural_network import MLPClassifier
            def b():
                sknn = MLPClassifier(activation="tanh",momentum=0, solver="sgd", hidden_layer_sizes=(10,))
                sknn.fit(DtrX, DtrY)

                nnetEtest = eval(sknn.predict(DteX), DteY)
                print(nnetEtest)

                sknn = MLPClassifier(activation="tanh", solver="sgd", hidden_layer_sizes=(10,))
                sknn.fit(DtrX, DtrY)

                nnetEtest = eval(sknn.predict(DteX), DteY)
                print(nnetEtest)

                sknn = MLPClassifier()  # recommended defaults
                sknn.fit(DtrX, DtrY)

                nnetEtest = eval(sknn.predict(DteX), DteY)
                print(nnetEtest)
            b()

        multitest(0.5, 3, 2)
        # bb()
    pt5()


