import multiprocessing as mp
from multiprocessing.dummy import Pool as ThreadPool
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from sklearn import neighbors  # still knn algo, but in C
from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression  # faster than my implementation
from sklearn.neighbors._classification import KNeighborsClassifier

from RBFNet import RBFNet

np_ones_16_16 = np.ones(16) / 16


def readData():
    def process(trainAug, trainX, trainY):
        for l in trainAug.readlines():
            a = [float(i) for i in l[:len(l) - 2].split(' ')]
            trainY += a[:1]
            trainX += [a[1:]]
        return trainX, trainY

    trainAug = open('ZipDigits-1-5.train', 'r')
    testAug = open('ZipDigits-1-5.test', 'r')

    trainX, trainY, testX, testY = [], [], [], []

    trainX, trainY = process(trainAug, trainX, trainY)
    testX, testY = process(testAug, testX, testY)

    return [np.array(a(i)).T for i in trainX], np.array([1 if i == 1 else -1 for i in trainY]), \
           [np.array(a(i)).T for i in testX], np.array([1 if i == 1 else -1 for i in testY])


def a(imgV):
    vM = []

    for i in range(16):
        vM += [imgV[16 * i:16 * i + 16]]

    return vM


def c(D: list[np.ndarray]) -> tuple[list[np.ndarray], list[np.ndarray]]:
    cm = lambda i: i @ np_ones_16_16
    # list[std_dev], list[mean]
    return np.power([np.power((x := cm(A)) - x @ np_ones_16_16, 2) @ np.ones(16) for A in D], 0.5), \
           [cm(A) @ np_ones_16_16 for A in D]


# <editor-fold desc="hardcoded legrence transforms. derived with paper to save on calc time later on">

l = lambda x, p: sum([j * x ** i for i, j in enumerate(p)])
l1 = lambda x: l(x, [0, 1])
l2 = lambda x: l(x, [-.1 / 2, 0, 3 / 2])
l3 = lambda x: l(x, [0, -3 / 2, 0, 5 / 2])
l4 = lambda x: l(x, [.375, 0, -3.75, 0, 4.375])
l5 = lambda x: l(x, [0, 1.875, 0, -8.75, 0, 7.875])
l6 = lambda x: l(x, [-.3125, 0, 6.5625, 0, -19.6875, 0, 14.4375])
l7 = lambda x: l(x, [0, 2.1875, 0, 19.875, 0, -43.3125, 0, 26.8125])
l8 = lambda x: l(x, [35 / 128, 0, 1260 / 128, 0, 6930 / 128, 0, 12012 / 128, 0, 6435 / 128])


# </editor-fold>

def lr(X: np.ndarray, Y: np.ndarray, lam: float):
    H = hatter(X, lam)
    return (H @ Y), H


hatter = lambda X, lam: aer(X, lam) @ X.T

aer = lambda X, lam: np.linalg.inv(X.T @ X + lam * np.identity(X.shape[1]))


def lrthread(X: np.ndarray, Y: np.ndarray, lam: float, i):
    t1, t2 = lr(X, Y, lam)
    return lam, i, t1, t2


def knnthread(X: np.ndarray, Y: np.ndarray, k: int, i):
    knn = neighbors.KNeighborsClassifier(k, weights='distance')
    knn.fit(X, Y)
    return knn, i


def rbfthread(X: np.ndarray, Y: np.ndarray, k: int, i):
    # massauge with kmeans
    rbfn = RBFNet(X, Y,2,k)
    rbfn.fit()
    return rbfn, i


def transform(D):
    return [
        [
            1,
            l1(d[0]), l1(d[1]),
            l2(d[0]), l1(d[0]) * l1(d[1]), l2(d[1]),
            l3(d[0]), l2(d[0]) * l1(d[1]), l2(d[0]) * l3(d[1]), l3(d[1]),
            l4(d[0]), l3(d[0]) * l1(d[1]), l2(d[0]) * l2(d[1]), l1(d[0]) * l3(d[1]), l4(d[1]),
            l5(d[0]), l4(d[0]) * l1(d[1]), l3(d[0]) * l2(d[1]), l2(d[0]) * l3(d[1]), l1(d[0]) * l4(d[1]), l5(d[1]),
            l6(d[0]), l5(d[0]) * l1(d[1]), l4(d[0]) * l2(d[1]), l3(d[0]) * l3(d[1]), l2(d[0]) * l4(d[1]),
                      l1(d[0]) * l5(d[1]), l6(d[1]),
            l7(d[0]), l6(d[0]) * l1(d[1]), l5(d[0]) * l2(d[1]), l4(d[0]) * l3(d[1]), l3(d[0]) * l4(d[1]),
                      l2(d[0]) * l5(d[1]), l1(d[0]) * l6(d[1]), l7(d[1]),
            l8(d[0]), l7(d[0]) * l1(d[1]), l6(d[0]) * l2(d[1]), l5(d[0]) * l3(d[1]), l4(d[0]) * l4(d[1]),
                      l3(d[0]) * l5(d[1]), l2(d[0]) * l6(d[1]), l1(d[0]) * l7(d[1]), l8(d[1])
        ]
        for d in D
    ]


def fff(a, w):
    x, y = a
    z = transform(x)
    return sum(z * w)


def split(X, Y):
    pos, neg = [], []
    for i, v in enumerate(Y):
        if v > 0:
            pos += [X[i]]
        else:
            neg += [X[i]]
    return np.array(pos), np.array(neg)


def plot(wH, X, Y, name=''):
    w = wH[0]
    x = np.arange(-1.0, 1.0, 0.1)
    y = np.arange(-1.0, 1.0, 0.1)
    ff = fff(np.meshgrid(x, y), w)
    ones, fives = split(X, Y)
    plt.title(name)
    plt.contour(x, y, ff, [0])
    plt.scatter(ones.T[1], ones.T[2], label="1")
    plt.scatter(fives.T[1], fives.T[2], label="5")
    plt.legend()
    plt.show()


def knnplot(knn, X, Y, name=''):
    from matplotlib.colors import ListedColormap
    # pic of decision boundary along with test pts
    xx, yy = np.meshgrid(np.arange(-1, 1, .01),
                         np.meshgrid(np.arange(-1, 1, .01)))

    f3 = knn.predict(np.c_[xx.ravel(), yy.ravel()])
    f3 = f3.reshape(xx.shape)

    plt.figure()
    plt.xlim(-1, 1)
    plt.ylim(-1, 1)
    plt.title(name)
    plt.pcolormesh(xx, yy, f3, cmap=ListedColormap(['#FFAAAA', '#AAFFAA']))
    plt.scatter(X[:, 0], X[:, 1], c=Y, cmap=ListedColormap(['#cc0000', '#00cc00']))
    plt.show()


def eval(Yp, Y):
    return (len(Y) - Yp @ Y) / 2  # only counts misclassed


if __name__ == '__main__':
    np.random.seed(0)


    def preProcessData():
        def cutDown(train, trainAug):
            for l in train.readlines():
                if l[0] == '1' or l[0] == '5':
                    trainAug.writelines([l])

        train = open('ZipDigits.train', 'r')
        test = open('ZipDigits.test', 'r''')

        trainAug = open('ZipDigits-1-5.train', 'w')
        testAug = open('ZipDigits-1-5.test', 'w')

        cutDown(train, trainAug)
        cutDown(test, testAug)


    def setup():
        global DtrX, DtrY, DteX, DteY, DtrZ, DteZ
        trX, trY, teX, teY = readData()
        X, Y = np.array(c(trX + teX)).T, np.concatenate((trY, teY))
        # rescale (2nd feature doesn't need rescale due to the dataset, as pixel vals themselves range from -1 to 1. Lengg transform is senstive to domain oversteps
        max0 = max(X.T[0])
        min0 = min(X.T[0])
        max1 = max(X.T[1])
        min1 = min(X.T[1])
        for i in range(len(X.T[0])):
            X[i, 0] /= 1.875  # based on the maximum possible val of the 2nd feature
            X[i, 0] -= .9375
        # z space transform
        Z = np.array(transform(X))
        # filter
        np.random.seed(0)
        f = np.random.choice([_ for _ in range(len(trY) + len(teY))], 300, False)
        DtrX, DtrY, DtrZ, DteX, DteY, DteZ = [], [], [], [], [], []

        for i, z in enumerate(Z):
            if i in f:
                DtrZ += [z]
                DtrY += [Y[i]]
                DtrX += [X[i]]
            else:
                DteZ += [z]
                DteY += [Y[i]]
                DteX += [X[i]]
        DtrX, DtrY, DteX, DteY, DtrZ, DteZ = np.array(DtrX), np.array(DtrY), np.array(DteX), np.array(DteY), np.array(
            DtrZ), np.array(DteZ)


    def drop1() -> tuple[list[np.ndarray], list[np.ndarray], list[int]]:

        DtrXs: list[np.ndarray]
        DtrYs: list[np.ndarray]
        iss: list[int]
        DtrXs, DtrYs, iss = [], [], []  # leave1out measures
        for i, d in enumerate(DtrX - 1):
            DtrXs += [np.concatenate((DtrX[:i], DtrX[i + 1:]))]
            DtrYs += [np.concatenate((DtrY[:i], DtrY[i + 1:]))]
            iss += [i]
        return (DtrXs, DtrYs, iss)


    def lrCrossVal():
        # increment in 0.01 as a rough tuning measure, as it was taking far too long, even with parallelism
        cap = .5
        lambdas = [_ / 100 for _ in range(int(cap * 100))]

        # note that vals such as Etest were derived within the PyCharm IDE debugger, which acts a bit like Jupiter notebooks
        def packParams(data, ls):
            DtrXs, DtrYs, tmp = data
            lrinputs: list[Any] = []
            for lama, ll in enumerate(ls):
                t = []
                for i, v in enumerate(DtrXs):
                    lrargs = (v, DtrYs[i], ll, i)
                    t += [lrargs]
                lrinputs += [t]

            return lrinputs

        def evalParams(lrinputs):
            # threadpool since process overhead is big, and there's no gui apps going on
            lrouts = []
            with ThreadPool(mp.cpu_count()) as pool:
                for i in lrinputs:
                    tmp = pool.starmap(lrthread, i)
                    lrouts += [tmp]
            return lrouts

        def crossvalval(data, outs):
            cveval, ineval, cvAval, tval = [], [], [], []
            for i, lp in enumerate(outs):
                errs = 0
                intr = 0
                aerrs = 0
                A = aer(DtrX, i / 100)
                # sum up errors per lam
                for j in lp:
                    lam = j[0]
                    ith = j[1]
                    w = j[2]

                    # fetch corresponding trainer
                    xtr = data[0][ith]
                    ytr = data[1][ith]
                    for i, x in enumerate(xtr):
                        intr += 1 if x @ w * ytr[i] < 0 else 0
                    # fetch and test missing x
                    xed = DtrX[ith]
                    yed = DtrY[ith]
                    # scale err inc by a Hmm, defined by problem 4.26
                    errs += 1 if xed @ w * yed < 0 else 0
                    aerrs += 1 / (1 - xed @ np.linalg.inv(A) @ xed) if xed @ w * yed < 0 else 0

                cveval += [errs / 300]
                ineval += [intr / 300 / 299]
                cvAval += [np.abs(aerrs)]
            return cveval, ineval, cvAval

        def plotl(X, Xaug, name=''):
            plt.title(name)
            plt.plot(X, label="Ecv")
            plt.plot(Xaug, label="Ecv predicted")
            plt.legend()
            plt.show()

        lambdas: list[float]
        data: tuple[list[np.ndarray], list[np.ndarray], list[int]]
        data = drop1()

        inputs = packParams(data, lambdas)

        lrArgs = evalParams(inputs)

        # run thrugh ls
        ycv, yin, ycvaug = crossvalval(data, lrArgs)

        plotl(ycv, ycvaug)
        # return best lamb


    def knnCrossVal():
        # note that vals such as Etest were derived within the PyCharm IDE debugger, which acts a bit like Jupiter notebooks
        def packParams(data, ks):
            DtrXs, DtrYs, tmp = data
            knninputs: list[Any] = []
            for k, ll in enumerate(ks):
                t = []
                for i, v in enumerate(DtrXs):
                    knnargs = (v, DtrYs[i], k + 1, i)
                    t += [knnargs]
                knninputs += [t]
            return knninputs

        def evalParams(knninputs):
            # threadpool since process overhead is big, and there's no gui apps going on
            knnouts = []
            with ThreadPool(mp.cpu_count()) as pool:
                for i in knninputs:
                    tmp = pool.starmap(knnthread, i)
                    knnouts += [tmp]
            return knnouts

        def crossvalval(data, outs: list[list[tuple[KNeighborsClassifier, int]]]):
            DtrXs, DtrYs, tmp = data
            cveval, ineval = [], []
            for i, knnp in enumerate(outs):
                errs = 0
                intr = 0
                # sum up errors per k
                for j in knnp:
                    # fetch and test missing x
                    ith = j[1]
                    xed = DtrX[ith]
                    yed = DtrY[ith]
                    errs += 1 if j[0].predict(np.reshape(xed, (1, 2)))[0] != yed else 0
                    # in sample error
                    for ii, k in enumerate(DtrXs):
                        # direct comps as a -1 return annihilates a +1 as well.
                        # Was not a problem last time as a score measure
                        intr += int((299 - j[0].predict(k) @ DtrYs[ii]) / 2)

                cveval += [errs / 300]
                ineval += [intr / 300 / 299]  # close enough for insample error anyways
            return cveval, ineval

        def plotl(X, X0, name=''):
            plt.title(name)
            plt.plot(X, label="Ecv")
            plt.plot(X0, label="Ein")
            plt.legend()
            plt.show()

        lambdas: list[float]
        data: tuple[list[np.ndarray], list[np.ndarray], list[int]]
        data = drop1()

        ks = [_ for _ in range(5)]  # good enough for something close to linear anyways
        knnArgs = packParams(data, ks)

        knnouts = evalParams(knnArgs)

        # run thrugh ls
        ycv, yin = crossvalval(data, knnouts)

        plotl([0] + ycv, [0] + yin)
        # return best lamb


    def rbfCrossVal():
        # note that vals such as Etest were derived within the PyCharm IDE debugger, which acts a bit like Jupiter notebooks
        def packParams(data, ks):
            DtrXs, DtrYs, tmp = data
            rbfinputs: list[Any] = []
            for k, ll in enumerate(ks):
                t = []
                for i, v in enumerate(DtrXs):
                    rbfargs = (v, DtrYs[i], k + 2, i)  # what is k = 1 cluster anyways?
                    t += [rbfargs]
                rbfinputs += [t]
            return rbfinputs

        def evalParams(rbfinputs):
            # threadpool since process overhead is big, and there's no gui apps going on
            rbfouts = []
            with ThreadPool(mp.cpu_count()) as pool:
                for i in rbfinputs:
                    tmp = pool.starmap(rbfthread, i)
                    rbfouts += [tmp]
            return rbfouts

        def crossvalval(data, outs: list[list[tuple[RBFNet, int]]]):
            DtrXs, DtrYs, tmp = data
            cveval, ineval = [], []
            for i, rbfp in enumerate(outs):
                errs = 0
                intr = 0
                # sum up errors per k
                for j in rbfp:
                    # fetch and test missing x
                    ith = j[1]
                    xed = DtrX[ith]
                    yed = DtrY[ith]
                    errs += 1 if j[0].predict(np.reshape(xed, (1, 2)))[0] != yed else 0
                    # in sample error
                    for ii, k in enumerate(DtrXs):
                        # direct comps as a -1 return annihilates a +1 as well.
                        # Was not a problem last time as a score measure
                        intr += int((299 - j[0].predict(k) @ DtrYs[ii]) / 2)

                cveval += [errs / 300]
                ineval += [intr / 300 / 299]  # close enough for insample error anyways
            return cveval, ineval

        def plotl(X, X0, name=''):
            plt.title(name)
            y = np.array([_ for _ in range(len(X))]) + 2
            plt.plot(X, y, label="Ecv")
            plt.plot(X0, y, label="Ein")
            plt.legend()
            plt.show()

        lambdas: list[float]
        data: tuple[list[np.ndarray], list[np.ndarray], list[int]]
        data = drop1()

        ks = [_ for _ in range(4)]  # takes far too long with cross val, even with threading
        rbfArgs = packParams(data, ks)

        rbfouts = evalParams(rbfArgs)

        # run thrugh ls
        ycv, yin = crossvalval(data, rbfouts)

        plotl(ycv, yin)
        # return best lamb


    def lrTest(l):
        wH = lr(np.array(transform(DtrX)), DtrY, l)
        f = lambda w: np.sign(np.array(transform(DtrX)) @ w)
        Etest = eval(f(wH[0]), DteY)
        print(Etest)
        p0 = mp.Process(target=plot, args=(wH, DteX, DteY, 'l=0'))
        p0.start()
        p0.join()


    def knnTest(k):
        knn = neighbors.KNeighborsClassifier(k, weights='distance')
        knn.fit(DtrX, DtrY)
        Etest = eval(knn.predict(DteX), DteY)
        print(Etest)
        p0 = mp.Process(target=knnplot, args=(knn, DteX, DteY, 'k=3'))
        p0.start()
        p0.join()


    def rbfnTest(k):
        rbf = RBFNet(DtrX, DtrY,2,k)
        rbf.fit()
        Etest = eval(rbf.predict(DteX), DteY)
        print(Etest)

        knnplot(rbf, DteX, DteY, f'{k}')


    def multitest(l, kknn, krbf):
        lrr = LinearRegression(fit_intercept=False, n_jobs=-1)
        lrr.fit(transform(DtrX), DtrY)
        lrEtest = eval(np.sign(lrr.predict(transform(DteX))), DteY)

        knn = neighbors.KNeighborsClassifier(kknn, weights='distance')
        knn.fit(DtrX, DtrY)
        knnEtest = eval(knn.predict(DteX), DteY)

        rbf = RBFNet(DtrX, DtrY,2,krbf)
        rbf.fit()
        rbfEtest = eval(rbf.predict(DteX), DteY)

        print("noiseafehigvouwkvjbg\n")  # clion python console has some buffering issue
        print(lrEtest, knnEtest, rbfEtest)


    def kmDebug(X, k):
        kmeans = KMeans(n_clusters=k)

        # predict the labels of clusters.
        label = kmeans.fit_predict(X)

        # Getting unique labels
        u_labels = np.unique(label)
        centroids = kmeans.cluster_centers_

        # plotting the results:
        for i in u_labels:
            plt.scatter(X[label == i, 0], X[label == i, 1], label=i)
        plt.scatter(centroids[:,0] , centroids[:,1] , s = 80, color = 'k')
        plt.legend()
        plt.show()


    setup()

    # kmDebug(DtrX,2)

    rbfCrossVal()

    # rbfnTest(2)
    # vals from last time
    # multitest(0.5, 3, 2)
