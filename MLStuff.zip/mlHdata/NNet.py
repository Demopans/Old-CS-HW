"""
import numpy as np
# drop in replace numpy, I'm not spending 5 hours on training + cv alone.
# To install from pip, make sure you use the cupy that matches your cuda version
# or just use numpy
"""
import cupy as np
import typing


# <editor-fold desc="internal functions">
class Layer:
    def __init__(self, d: int,
                 n: int,
                 activFunc: typing.Callable[[object], np.ndarray],
                 activFuncGrad: typing.Callable[[object], np.ndarray],
                 ):
        self.activFunc: typing.Callable[[np.ndarray], np.ndarray] = activFunc
        self.activFuncGrad: typing.Callable[[np.ndarray], np.ndarray] = activFuncGrad
        self.Z = lambda X: X @ self.W + self.b  # linear node

        self.W = np.random.rand(d, n)  # np.zeros(...) + .25
        self.b = np.random.rand(1, n)

    def __str__(self):
        return \
            f"""W: {self.W}
b: {self.b}
"""

    def u(self, Wp, bp, lr):
        self.W -= lr * Wp
        self.b -= lr * bp


class Params:  # notta struct
    # accepts np numeric methods for now. you can drop in your own, but I cannot guarantee anything
    # <editor-fold desc="derivatives. for other custom functions, supply your own">
    @staticmethod
    def dnpSign(x):  # der of np.sign
        return 1 if x > 0 else -1

    @staticmethod
    def didenity(x):
        return np.ones(x.shape)

    @staticmethod
    def dreLu(x):
        return 1 if x > 0 else 0

    # </editor-fold>

    def __init__(self,
                 outputFunc: np.ufunc = np.tanh,
                 doutputFunc=lambda x: (1 - np.square(np.tanh(x))),
                 activFunc: np.ufunc = np.tanh,
                 dactivFunc=lambda x: (1 - np.square(np.tanh(x))),
                 epochs=100,
                 loss=lambda ye, y, w, lamb: (1 / (4 * len(y)) * np.square(ye - y)) + 1 / len(y) *
                 np.dot(w, w),  # per example loss
                 dloss=lambda a, y: 1 / (2 * len(y)) * (a - y),
                 lr=0.01,
                 lamb=0):  # R most likely uses *args
        """
        :param outputFunc:
        :param doutputFunc: must operate on np arrays
        :param activFunc:
        :param dactivFunc:
        :param epochs:
        :param loss:
        :param dloss:
        :param lr:
        :param lamb:
        """
        # general model params
        self.epochs = epochs
        self.lr = lr
        self.lamb = lamb

        # nnet params
        self.outputFunc = outputFunc
        self.doutputFunc = doutputFunc
        self.activFunc = activFunc
        self.dactivFunc = dactivFunc
        self.loss = loss
        self.dloss = dloss

        # idk, random forest?


# </editor-fold>


class NNet:  # arch allows for expansion with custom layers. In-API bindings for that not implemented
    debug = False

    def __init__(self, arch: np.ndarray, params=Params()):  # R-style api
        if arch[len(arch) - 1] > 1:
            raise Exception("multiclass not supported")
        else:
            np.random.seed(0)
            self.layers = [Layer(arch[i], arch[i + 1], params.activFunc, params.dactivFunc) for i in
                           range(0, arch.size - 1)]
            t = (Layer(arch[arch.size - 1], arch[arch.size - 1], params.outputFunc, params.doutputFunc))
            # self.layers.append(t)
            self.layers[arch.size - 2].activFunc = params.outputFunc
            self.layers[arch.size - 2].activFuncGrad = params.doutputFunc

            self.epochs = params.epochs
            self.loss = params.loss
            self.dloss = params.dloss
            self.lr = params.lr
            self.lamb = params.lamb

    def __fullforward(self, X: np.ndarray):
        forward0 = lambda X, l: l.Z(X)

        A1 = X
        cache = []
        for i, l in enumerate(self.layers):
            A0 = A1
            Z = forward0(A0, l)  # note: algo uses row data vectors instead of column data vectors
            A1 = l.activFunc(Z)

            cache.append(Z)  # Z: pretransform, A can be retransformed later
        return A1, cache

    # no functional difference
    def __forward(self, x: np.ndarray):
        forward0 = lambda X, l: l.Z(X)

        A1 = x
        cache = []
        for i, l in enumerate(self.layers):
            A0 = A1
            Z = forward0(A0, l)  # note: algo uses row data vectors instead of column data vectors
            A1 = l.activFunc(Z)

            cache.append(Z)  # Z: pretransform, A can be retransformed later
        return A1, cache

    def __backProp(self, yp, y, ct, mem):
        # init dL/dA
        dL = []
        grads = []
        for ii, l in enumerate(reversed(self.layers)):
            i = len(self.layers) - ii - 1
            if ii == 0:
                dL = self.dloss(yp, y) * self.layers[i].activFuncGrad(mem[i])
            else:
                dL = np.dot(self.layers[i + 1].W, dL) * self.layers[i].activFuncGrad(mem[i]).T
            dW = np.multiply(dL, mem[i - 1]).T + self.lamb*self.layers[i].W
            db = dL.T
            # online update weights. doing it loses all the benefits of numpy C kernel
            # blocky variant later
            self.layers[i].u(dW, db, self.lr)  # self varying. gradient is not normalized

            if self.debug : print(f"{i}:\n {self.layers[i]}")
            grads.append([dW, db])

        return grads  # gradient

    def predict(self, X: np.ndarray):
        return np.asnumpy(self.__fullforward(np.array(X))[0])

    def fit(self, X, y):
        # re-transform cuz cupy
        X: np.ndarray = np.array(X)  # data terms must be per row
        y: np.ndarray = np.array(y)
        # reshape due to numpy and cupy bugs
        X = np.atleast_2d(X)
        X = np.reshape(X, (-1, X.shape[1]))
        y = np.reshape(y, (len(y), 1))
        ct = len(y)

        error = []
        order = np.array([_ for _ in range(ct)])
        # assume data is already transformed and normalized
        for e in range(self.epochs):
            xs, ys = [], []
            for i in order:
                x = X[i]
                yy = y[i]

                yp, mem = self.__forward(x)
                xs.append(yp)
                ys.append(yy)
                # loopy backprop
                g = self.__backProp(yp, yy, ct, mem)

            err = self.loss(np.array(xs), np.array(ys)).item()
            error += [err]
            np.random.shuffle(order)
        return error
