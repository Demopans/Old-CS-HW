import numpy as np
import multiprocessing as mp

np_ones_16_16 = np.ones(16) / 16


def preProcessData():
    def cutDown(train, trainAug):
        for l in train.readlines():
            if l[0] == '1' or l[0] == '5':
                trainAug.writelines([l])

    train = open('ZipDigits.train', 'r')
    test = open('ZipDigits.test', 'r''')

    trainAug = open('ZipDigits-1-5.train', 'w')
    testAug = open('ZipDigits-1-5.test', 'w')

    cutDown(train, trainAug)
    cutDown(test, testAug)


def readData():
    def process(trainAug, trainX, trainY):
        for l in trainAug.readlines():
            a = [float(i) for i in l[:len(l) - 2].split(' ')]
            trainY += a[:1]
            trainX += [a[1:]]
        return trainX, trainY

    trainAug = open('ZipDigits-1-5.train', 'r')
    testAug = open('ZipDigits-1-5.test', 'r')

    trainX, trainY, testX, testY = [], [], [], []

    trainX, trainY = process(trainAug, trainX, trainY)
    testX, testY = process(testAug, testX, testY)

    return [np.array(a(i)).T for i in trainX], np.array([1 if i == 1 else -1 for i in trainY]), \
           [np.array(a(i)).T for i in testX], np.array([1 if i == 1 else -1 for i in testY])


def a(imgV):
    vM = []

    for i in range(16):
        vM += [imgV[16 * i:16 * i + 16]]

    return vM


def cheapImgDisplay(img):
    for i in img:
        print(['8' if j > 0.5 else '.' for j in i])


def b():
    i1, i2 = trX[0], trX[94]
    print('\n')
    cheapImgDisplay(a(i1))
    print('\n')
    cheapImgDisplay(a(i2))


def c(D: list[np.ndarray]) -> tuple[list[np.ndarray], list[np.ndarray]]:
    cm = lambda i: i @ np_ones_16_16
    return np.power([np.power((x := cm(A)) - x @ np_ones_16_16, 2) @ np.ones(16) for A in D], 0.5), [
        cm(A) @ np_ones_16_16 for A in D]


def d(D: list[np.ndarray]) -> tuple[
    list[np.ndarray], list[np.ndarray], np.ndarray, list[np.ndarray], np.ndarray, list[np.ndarray], list[np.ndarray],
    list[np.ndarray], list[np.ndarray]]:
    cm = lambda i: i @ np_ones_16_16
    return np.power([np.power((x := cm(A)) - x @ np_ones_16_16, 2) @ np.ones(16) for A in D], 0.5), \
           [cm(A) @ np_ones_16_16 for A in D], \
 \
           np.power([np.power((x := cm(A)) - x @ np_ones_16_16, 2) @ np.ones(16) for A in D], 1), \
           np.power([cm(A) @ np_ones_16_16 for A in D], 2), \
 \
           np.power([np.power((x := cm(A)) - x @ np_ones_16_16, 2) @ np.ones(16) for A in D], 1.5), \
           np.power([cm(A) @ np_ones_16_16 for A in D], 3), \
 \
           np.power([np.power((x := cm(A)) - x @ np_ones_16_16, 2) @ np.ones(16) for A in D], 0.5) * [
               cm(A) @ np_ones_16_16 for A in D], \
           np.power([np.power((x := cm(A)) - x @ np_ones_16_16, 2) @ np.ones(16) for A in D], 1) * [
               cm(A) @ np_ones_16_16 for A in D], \
           np.power([cm(A) @ np_ones_16_16 for A in D], 2) * np.power(
               [np.power((x := cm(A)) - x @ np_ones_16_16, 2) @ np.ones(16) for A in D], 0.5)


def plotpts(a, b):
    import wxmplot as wxmi
    import wx

    app = wx.App()
    frame = wxmi.PlotFrame()
    frame.plot(x=[0], y=[0], delay_draw=False, show_legend=True, legend_loc='ul', viewpad=10, linewidth=0,
               xlabel='f1: σ',
               ylabel='f2: μ', label=' ')
    frame.oplot(x=a[0], y=a[1], label='1', linewidth=0, marker='o', delay_draw=False, color='blue')
    frame.oplot(x=b[0], y=b[1], label='5', linewidth=0, marker='x', delay_draw=False, color='red')

    frame.Show()
    app.MainLoop()


def plotWithSep(g1, g2, wlr, wpla):
    import wxmplot as wxmi
    import wx

    xp = np.linspace(0, 4, 10)

    # pla w to ax+b
    a, b = -1 * wpla[0] / wpla[1], -1 * wpla[2] / wpla[1]
    yp = a * xp + b

    # lr to ax+b
    a, b = -1 * wlr[0] / wlr[1], -1 * wlr[2] / wlr[1]
    yl = a * xp + b

    app = wx.App()
    frame = wxmi.PlotFrame()
    frame.plot(x=[0], y=[0], delay_draw=False, show_legend=True, legend_loc='ul', viewpad=10, linewidth=0,
               xlabel='f1: σ',
               ylabel='f2: μ', label=' ')
    frame.oplot(x=g1[0], y=g1[1], label='1', linewidth=0, marker='o', delay_draw=False, color='blue')
    frame.oplot(x=g2[0], y=g2[1], label='5', linewidth=0, marker='x', delay_draw=False, color='red')

    frame.oplot(x=xp, y=yp, label=f'PLA: {a:.1}x+{b:.1}', linewidth=1, marker=' ', delay_draw=False)
    frame.oplot(x=xp, y=yl, label=f'LR (projection from R3): {wlr[0]:.1}x+{wlr[1]:.1}', linewidth=1, marker=' ',
                delay_draw=False)
    frame.Show()
    app.MainLoop()


def sort(f1, f2, Y):
    ones, fives = [], []
    for i in range(len(Y)):
        if Y[i] == 1:
            ones += [[f1[i], f2[i]]]
        else:
            fives += [[f1[i], f2[i]]]

    return ones, fives


def sort(f11, f21, f12, f22, f13, f23, Y):
    ones, fives = [], []
    for i in range(len(Y)):
        if Y[i] == 1:
            ones += [[f11[i], f21[i], f12[i], f22[i], f13[i], f23[i]]]
        else:
            fives += [[f11[i], f21[i], f12[i], f22[i], f13[i], f23[i]]]

    return ones, fives


def lr(x: np.ndarray, y: np.ndarray):
    return np.linalg.pinv(x) @ y


def ppla(X: np.ndarray, Y: np.ndarray, w0=None):
    wb: np.ndarray = np.zeros(len(X[0]))
    eb: int = len(Y)  # max possible error

    eta = 1
    epochs = eb
    w: np.ndarray = w0 if w0 is not None else np.zeros(len(X[0]))

    for epoch in range(epochs):
        if eb == 0:
            break

        e = 0
        for i, x in enumerate(X):
            if (np.dot(X[i], w) * Y[i]) <= 0:
                w = w + eta * (1 + (epochs - epoch) / epochs) * X[i] * Y[i]
                e += 1

        if e <= eb:
            wb = w
            eb = e

    return wb, eb


def testset(X: np.ndarray, Y: np.ndarray, wpla):
    e = 0
    for i, x in enumerate(X):
        if (np.dot(X[i], wpla) * Y[i]) <= 0:
            e += 1
    return e


def linear(trX, trY, teX, teY):
    f1, f2 = c(trX)

    ones, fives = sort(f1, f2, trY)
    ones = np.array(ones).T
    fives = np.array(fives).T

    trXM = np.array([f1, f2]).T
    wlr = lr(np.vstack((trXM.T, np.ones(trXM.shape[0]))).T, trY)

    wpla0, e = ppla(np.vstack((trXM.T, np.ones(trXM.shape[0]))).T, trY, wlr)

    # plotWithSep(ones, fives, wlr, wpla0)

    f1, f2 = c(teX)
    ones, fives = sort(f1, f2, teY)
    ones = np.array(ones).T
    fives = np.array(fives).T

    teXM = np.array([f1, f2]).T
    plotWithSep(ones, fives, wlr, wpla0)
    print(e)
    print(testset(np.vstack((teXM.T, np.ones(teXM.shape[0]))).T, teY, wpla0))


def thrdear(trX, trY, teX, teY):
    f11, f12, f21, f22, f31, f32, f23, f33, f34 = d(trX)

    trXM = np.array([f11, f12, f21, f22, f31, f32, f23, f33, f34]).T
    wlr = lr(np.vstack((trXM.T, np.ones(trXM.shape[0]))).T, trY)

    wpla0, e = ppla(np.vstack((trXM.T, np.ones(trXM.shape[0]))).T, trY, wlr)

    f11, f12, f21, f22, f31, f32, f23, f33, f34 = d(teX)

    teXM = np.array([f11, f12, f21, f22, f31, f32, f23, f33, f34]).T
    print(e)
    print(testset(np.vstack((teXM.T, np.ones(teXM.shape[0]))).T, teY, wpla0))


if __name__ == '__main__':
    trX, trY, teX, teY = readData()
    # linear(trX, trY, teX, teY)
    thrdear(trX, trY, teX, teY)
