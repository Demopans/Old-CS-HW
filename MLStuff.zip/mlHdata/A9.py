from typing import List, Any

import numpy as np
import matplotlib.pyplot as plt
import multiprocessing as mp
from multiprocessing.dummy import Pool as ThreadPool

np_ones_16_16 = np.ones(16) / 16


def readData():
    def process(trainAug, trainX, trainY):
        for l in trainAug.readlines():
            a = [float(i) for i in l[:len(l) - 2].split(' ')]
            trainY += a[:1]
            trainX += [a[1:]]
        return trainX, trainY

    trainAug = open('ZipDigits-1-5.train', 'r')
    testAug = open('ZipDigits-1-5.test', 'r')

    trainX, trainY, testX, testY = [], [], [], []

    trainX, trainY = process(trainAug, trainX, trainY)
    testX, testY = process(testAug, testX, testY)

    return [np.array(a(i)).T for i in trainX], np.array([1 if i == 1 else -1 for i in trainY]), \
           [np.array(a(i)).T for i in testX], np.array([1 if i == 1 else -1 for i in testY])


def a(imgV):
    vM = []

    for i in range(16):
        vM += [imgV[16 * i:16 * i + 16]]

    return vM


def c(D: list[np.ndarray]) -> tuple[list[np.ndarray], list[np.ndarray]]:
    cm = lambda i: i @ np_ones_16_16
    # list[std_dev], list[mean]
    return np.power([np.power((x := cm(A)) - x @ np_ones_16_16, 2) @ np.ones(16) for A in D], 0.5), \
           [cm(A) @ np_ones_16_16 for A in D]


# hardcoded legrence transforms. derived with paper to save on calc time later on
l = lambda x, p: sum([j * x ** i for i, j in enumerate(p)])
l1 = lambda x: l(x, [0, 1])
l2 = lambda x: l(x, [-.1 / 2, 0, 3 / 2])
l3 = lambda x: l(x, [0, -3 / 2, 0, 5 / 2])
l4 = lambda x: l(x, [.375, 0, -3.75, 0, 4.375])
l5 = lambda x: l(x, [0, 1.875, 0, -8.75, 0, 7.875])
l6 = lambda x: l(x, [-.3125, 0, 6.5625, 0, -19.6875, 0, 14.4375])
l7 = lambda x: l(x, [0, 2.1875, 0, 19.875, 0, -43.3125, 0, 26.8125])
l8 = lambda x: l(x, [35 / 128, 0, 1260 / 128, 0, 6930 / 128, 0, 12012 / 128, 0, 6435 / 128])


def lr(X: np.ndarray, Y: np.ndarray, lam: float):
    H = hatter(X, lam)
    return (H @ Y), H


hatter = lambda X, lam: aer(X, lam) @ X.T

aer = lambda X, lam: np.linalg.inv(X.T @ X + lam * np.identity(X.shape[1]))


def lrthread(X: np.ndarray, Y: np.ndarray, lam: float, i):
    t1, t2 = lr(X, Y, lam)
    return lam, i, t1, t2


def transform(D):
    return [
        [
            1,
            l1(d[0]), l1(d[1]),
            l2(d[0]), l1(d[0]) * l1(d[1]), l2(d[1]),
            l3(d[0]), l2(d[0]) * l1(d[1]), l2(d[0]) * l3(d[1]), l3(d[1]),
            l4(d[0]), l3(d[0]) * l1(d[1]), l2(d[0]) * l2(d[1]), l1(d[0]) * l3(d[1]), l4(d[1]),
            l5(d[0]), l4(d[0]) * l1(d[1]), l3(d[0]) * l2(d[1]), l2(d[0]) * l3(d[1]), l1(d[0]) * l4(d[1]), l5(d[1]),
            l6(d[0]), l5(d[0]) * l1(d[1]), l4(d[0]) * l2(d[1]), l3(d[0]) * l3(d[1]), l2(d[0]) * l4(d[1]),
                      l1(d[0]) * l5(d[1]), l6(d[1]),
            l7(d[0]), l6(d[0]) * l1(d[1]), l5(d[0]) * l2(d[1]), l4(d[0]) * l3(d[1]), l3(d[0]) * l4(d[1]),
                      l2(d[0]) * l5(d[1]), l1(d[0]) * l6(d[1]), l7(d[1]),
            l8(d[0]), l7(d[0]) * l1(d[1]), l6(d[0]) * l2(d[1]), l5(d[0]) * l3(d[1]), l4(d[0]) * l4(d[1]),
                      l3(d[0]) * l5(d[1]), l2(d[0]) * l6(d[1]), l1(d[0]) * l7(d[1]), l8(d[1])
        ]
        for d in D
    ]


def fff(a, w):
    x, y = a
    z = np.array(
        [
            1, l1(x), l1(y),
            l2(x), l1(x) * l1(y), l2(y),
            l3(x), l2(x) * l1(y), l2(x) * l3(y), l3(y),
            l4(x), l3(x) * l1(y), l2(x) * l2(y), l1(x) * l3(y), l4(y),
            l5(x), l4(x) * l1(y), l3(x) * l2(y), l2(x) * l3(y), l1(x) * l4(y), l5(y),
            l6(x), l5(x) * l1(y), l4(x) * l2(y), l3(x) * l3(y), l2(x) * l4(y), l1(x) * l5(y), l6(y),
            l7(x), l6(x) * l1(y), l5(x) * l2(y), l4(x) * l3(y), l3(x) * l4(y), l2(x) * l5(y), l1(x) * l6(y), l7(y),
            l8(x), l7(x) * l1(y), l6(x) * l2(y), l5(x) * l3(y), l4(x) * l4(y), l3(x) * l5(y), l2(x) * l6(y),
                   l1(x) * l7(y), l8(y)
        ], dtype=object)
    return sum(z * w)


def split(X, Y):
    pos, neg = [], []
    for i, v in enumerate(Y):
        if v > 0:
            pos += [X[i]]
        else:
            neg += [X[i]]
    return np.array(pos), np.array(neg)


def plot(wH, X, Y, name=''):
    w = wH[0]
    x = np.arange(-1.0, 1.0, 0.1)
    y = np.arange(-1.0, 1.0, 0.1)
    ff = fff(np.meshgrid(x, y), w)
    ones, fives = split(X, Y)
    plt.title(name)
    plt.contour(x, y, ff, [0])
    plt.scatter(ones.T[1], ones.T[2], label="1")
    plt.scatter(fives.T[1], fives.T[2], label="5")
    plt.legend()
    plt.show()


if __name__ == '__main__':
    def preProcessData():
        def cutDown(train, trainAug):
            for l in train.readlines():
                if l[0] == '1' or l[0] == '5':
                    trainAug.writelines([l])

        train = open('ZipDigits.train', 'r')
        test = open('ZipDigits.test', 'r''')

        trainAug = open('ZipDigits-1-5.train', 'w')
        testAug = open('ZipDigits-1-5.test', 'w')

        cutDown(train, trainAug)
        cutDown(test, testAug)


    def setup():
        global DtrX, DtrY, DteX, DteY
        trX, trY, teX, teY = readData()
        X, Y = np.array(c(trX + teX)).T, np.concatenate((trY, teY))
        # rescale (2nd feature doesn't need rescale due to the dataset, as pixel vals themselves range from -1 to 1. Lengg transform is senstive to domain oversteps
        max0 = max(X.T[0])
        min0 = min(X.T[0])
        max1 = max(X.T[1])
        min1 = min(X.T[1])
        for i in range(len(X.T[0])):
            X[i, 0] /= 3.75 # based on the maximum possible val of the 2nd feature
        # z space transform
        Z = np.array(transform(X))
        # filter
        np.random.seed(0)
        f = np.random.choice([_ for _ in range(len(trY) + len(teY))], 300, False)
        DtrX = []
        DtrY = []
        DteX = []
        DteY = []
        for i, x in enumerate(Z):
            if i in f:
                DtrX += [x]
                DtrY += [Y[i]]
            else:
                DteX += [x]
                DteY += [Y[i]]
        DtrX, DtrY, DteX, DteY = np.array(DtrX), np.array(DtrY), np.array(DteX), np.array(DteY)


    def pt2n3():
        p0 = mp.Process(target=plot, args=(lr(DtrX, DtrY, 0), DtrX, DtrY, 'l=0'))
        p2 = mp.Process(target=plot, args=(lr(DtrX, DtrY, 2), DtrX, DtrY, 'l=2'))
        p0.start()
        p2.start()
        p0.join()
        p2.join()


    def pt4():
        # note that vals such as Etest were derived within the PyCharm IDE debugger, which acts a bit like Jupiter notebooks

        def drop1():
            cap = 1
            # increment in 0.01 as a rough tuning measure, as it was taking far too long, even with parallelism
            ls = [_ / 100 for _ in range(cap * 100)]
            DtrXs, DtrYs, iss = [], [], []  # leave1out measures
            for i, d in enumerate(DtrX - 1):
                DtrXs += [np.concatenate((DtrX[:i], DtrX[i + 1:]))]
                DtrYs += [np.concatenate((DtrY[:i], DtrY[i + 1:]))]
                iss += [i]
            return (DtrXs, DtrYs,
                    iss), ls  # data outputs deficient train sets, with another array showing whic of the main one is dropped

        def packParams(data, ls):
            DtrXs, DtrYs, tmp = data
            inputs: list[Any] = []
            for lama, ll in enumerate(ls):
                t = []
                for i, v in enumerate(DtrXs):
                    args = (v, DtrYs[i], ll, i)
                    t += [args]
                inputs += [t]
            return inputs

        def evalParams(inputs):
            # threadpool since process overhead is big, and there's no gui apps going on
            outs = []
            with ThreadPool(mp.cpu_count()) as pool:
                for i in inputs:
                    tmp = pool.starmap(lrthread, i)
                    outs += [tmp]
            return outs

        def crossvalval(data, outs):
            cveval, ineval, cvAval, tval = [], [],[], []
            for i, lp in enumerate(outs):
                errs = 0
                intr = 0
                aerrs = 0
                A = aer(DtrX, i / 100)
                # sum up errors per lam
                for j in lp:
                    lam = j[0]
                    ith = j[1]
                    w = j[2]

                    # fetch corresponding trainer
                    xtr = data[0][ith]
                    ytr = data[1][ith]
                    for i, x in enumerate(xtr):
                        intr += 1 if x @ w * ytr[i] < 0 else 0
                    # fetch and test missing x
                    xed = DtrX[ith]
                    yed = DtrY[ith]
                    # scale err inc by a Hmm, defined by problem 4.26
                    errs += 1 if xed @ w * yed < 0 else 0
                    aerrs += 1 / (1 - xed @ np.linalg.inv(A) @ xed) if xed @ w * yed < 0 else 0

                cveval += [errs/300]
                ineval += [intr/300/299]
                cvAval += [np.abs(aerrs)]
            return cveval, ineval, cvAval

        def plotl(X, Xaug, name=''):
            plt.title(name)
            plt.plot(X, label="Ecv")
            plt.plot(Xaug, label="Ecv predicted")
            plt.legend()
            plt.show()

        data, ls = drop1()

        inputs = packParams(data, ls)

        outs = evalParams(inputs)

        # run thrugh ls
        ycv, yin, ycvaug = crossvalval(data, outs)

        plotl(ycv,ycvaug)
        # return best lamb


    def pt5(l):
        wH = lr(DtrX, DtrY, l)
        f = lambda w: np.sign(DteX@w)@DteY
        print(f(wH[0])) # correct classed
        p0 = mp.Process(target=plot, args=(wH, DteX, DteY, 'l=0'))
        p0.start()
        p0.join()

    setup()

    # lr
    # pt2n3()

    # cross valididation section
    # pt4()

    lam = 0.05  # hardcoded since I'm not rerunning pt4() again. If you have access to the IDEA Cluster, be my guest
    pt5(lam)


