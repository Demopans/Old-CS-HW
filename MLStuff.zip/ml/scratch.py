import math
import multiprocessing as mp  # me has multicores, me shall use multicores
import numpy as np


class HW1:
    dataset = tuple[list[int], list[int]]
    hw2HisData = list[tuple[float, int]]

    @staticmethod
    def m():
        HW1.drawPoints(d := HW1.generatePoints(10), ([0, 0], [20, -5]), HW1.perception(d))

    @staticmethod
    def generatePoints(n: int) -> tuple[dataset, dataset]:
        if n % 2 != 0: exit(-1)  # even numbers only
        from numpy.random import randint
        a, b, c, d = randint(1, 10, n), randint(1, 10, n), [-i for i in randint(1, 10, n)], randint(1, 10, n)
        g1: HW1.dataset = (a, b)
        g2: HW1.dataset = (c, d)
        return g1, g2

    @staticmethod
    def drawPoints(data: tuple[dataset, dataset], f: dataset, g: dataset):
        g1, g2 = data
        import wxmplot as wxmi
        # technically, this is better done in R, but python is easier to install
        app = wxmi.PlotApp()
        frame = wxmi.PlotFrame()
        frame.plot(x=g1[0], y=g1[1], label='Group 0', linewidth=0, xlabel='x', ylabel='y', marker='x', delay_draw=False,
                   show_legend=True, legend_loc='lr', viewpad=10)
        frame.oplot(x=g2[0], y=g2[1], label='Group 1', linewidth=0, marker='o', delay_draw=False)
        frame.oplot(x=f[0], y=f[1], label='f', delay_draw=False)
        frame.oplot(x=g[0], y=g[1], label='g', delay_draw=False)

        frame.Show()
        app.app.MainLoop()

    @staticmethod
    def step_func(z):
        return 1.0 if (z > 0) else 0.0

    @staticmethod
    def perception(data: tuple[dataset, dataset]) -> dataset:
        import numpy as np

        # config
        r = 0.1
        # bias
        w = np.array([0, 0, 0])
        # construct data and labels
        x = np.append(data[0], data[1], axis=1)
        y = [1 for _ in range(x.shape[1])] + [-1 for _ in range(x.shape[1])]

        # run body, algorithm is highly jank, and can be made better
        for t in range(int(math.pow(x.shape[0] * x.shape[1], 2))):
            for i in range(len(x)):
                if (np.dot([x[0][i], x[1][i], 1], w) * y[i]) <= 0:
                    w = w + 1 * [1, x[0][i], x[1][i]] * y[i]
        # convert
        # y=ax+b
        # 2 end points of g
        return ([1, -1], [-(w[1] / w[0]) * 2 + (-w[2] / w[0]), -(w[1] / w[0]) * -2 + (-w[2] / w[0])]) if w[0] != 0 else \
            ([1, 1], [-1, 1])


class HW2:
    repeats = 1
    N = 10

    @staticmethod
    def m():
        a = HW2.repeatTrials(HW2.repeats, 1000, HW2.N)
        x = mp.Process(target=HW2.drawHistogram, args=[a])
        x.start()
        y = mp.Process(target=HW2.generateBounds, args=[a])
        y.start()

    @staticmethod
    def repeatTrials(a, b, c) -> list:
        from numpy.random import binomial, choice
        return [((i := binomial(c, 0.5, b))[0], choice(i), min(i)) for _ in range(a)]

    @staticmethod
    def drawHistogram(d: list[tuple[int, int, int]]):
        import wxmplot as wxmi
        import wx
        bucket = HW2.lis(d)

        app = wx.App()
        frame = wxmi.PlotFrame()
        frame.plot(x=[0], y=[0], delay_draw=False, show_legend=True, legend_loc='ul', ylog_scale=True, viewpad=10,
                   linewidth=0, xlabel='x', ylabel='log_10(y)', label=' ')
        frame.oplot(x=[_ for _ in range(HW2.N + 1)], y=bucket[0], label='v1', linewidth=0, marker='x', delay_draw=False)
        frame.oplot(x=[_ for _ in range(HW2.N + 1)], y=bucket[1], label='vRand', linewidth=0, marker='o',
                    delay_draw=False)
        frame.oplot(x=[_ for _ in range(HW2.N + 1)], y=bucket[2], label='vMin', linewidth=0, marker='^',
                    delay_draw=False)
        frame.Show()
        app.MainLoop()
        # app.MainLoop()

    @staticmethod
    def lis(d):
        bucket: tuple[list[int], list[int], list[int]] = (
            [0 for _ in range(11)], [0 for _ in range(11)], [0 for _ in range(11)]
        )
        for x, y, z in d:
            bucket[0][x] += 1
            bucket[1][y] += 1
            bucket[2][z] += 1
        return bucket

    @staticmethod
    def generateBounds(d):
        import wxmplot as wxmi
        import wx

        bucket = HW2.lis(d)[0]

        def determineP(e):
            import numpy as np
            return np.dot([(1 if abs(i - 3.33) > e else 0) for i in range(HW2.N + 1)], bucket) / HW2.repeats

        def hoff(e): return 2 * math.e ** (-2 * e ** 2 * HW2.repeats)

        x, y = [determineP(i) for i in range(HW2.N + 1)], [hoff(i) for i in range(HW2.N + 1)]

        app = wx.App()
        frame = wxmi.PlotFrame()
        frame.plot(x=[0], y=[0], delay_draw=False, show_legend=True, legend_loc='ul', viewpad=10,
                   linewidth=0, xlabel='x', ylabel='y', label=' ')
        frame.oplot(x=[_ for _ in range(HW2.N + 1)], y=x, label='P[|v-u|>e]', linewidth=1, marker='x', delay_draw=False)
        frame.oplot(x=[_ for _ in range(HW2.N + 1)], y=y, label='Hoff(e)', linewidth=1, marker='o', delay_draw=False)
        frame.Show()
        app.MainLoop()


class HW5:
    gbar = 1 / 3
    x = [i / 1000.0 for i in range(-1000, 1001, 1)]

    @staticmethod
    def genCombo():
        g0, g1 = [], []
        for i in range(0, len(HW5.x) - 1):
            for j in range(i + 1, len(HW5.x)):
                p0 = HW5.x[i], HW5.x[i] * HW5.x[i]
                p1 = HW5.x[j], HW5.x[j] * HW5.x[j]
                g0 += [(p0, p1)]
        for i in g0:
            m = (i[1][1] - i[0][1]) / (i[1][0] - i[0][0])
            b = -1 * m * i[0][0] + i[0][1]
            g1 += [(m, b)]
        return g1

    @staticmethod
    def m():
        a = HW5.genCombo()
        s = 0
        for i in a:
            for x in HW5.x:
                s += i[0] * x + i[1]
        gbar = s / len(a)
        for x in HW5.x:
            s += pow((HW5.gbar - x * x), 2)
        bias = s / len(a)
        var = 0
        for i in a:
            v = 0
            for x in HW5.x:
                d = i[0] * x + i[1]
                v += pow((d - x * x), 2)
            var += v / len(HW5.x)
        var /= len(a)
        print(gbar, bias, var)


class HW6:
    @staticmethod
    def pla(w, d, y):
        wpla = np.reshape(np.frombuffer(w, dtype=np.float64), -1)
        Xt = np.vstack((d.T, np.array(2000 * [1.]))).T

        eta = 1
        epochs = 0
        wpla.fill(.0)
        flag = lambda i: 1 if ((np.dot(Xt[i], wpla[:3]) * y[i]) <= 0) else 0
        # lambda: (Xt @ w) @ y
        p = None
        while c := sum([flag(i) for i in range(len(y))]):
            p = (wpla, c) if p is None or p[1] > c else p
            for i, g in enumerate(y):
                if flag(i) != 0:
                    wpla[:3] = wpla[:3] + eta * Xt[i] * g
                    epochs += 1

        wpla[3] = epochs
        print(epochs)

    @staticmethod
    def svm(w, d, y):
        wpla = np.reshape(np.frombuffer(w, dtype=np.float64), -1)
        wpla.fill(0.0)
        eta = 1
        epochs = 100000
        Xt = d

        for epoch in range(1, epochs):
            for i, x in enumerate(Xt):
                if (y[i] * np.dot(Xt[i], w)) < 1:
                    w = w + eta * ((Xt[i] * Xt[i]) + (-2 * (1 / epoch) * w))
                else:
                    w = w + eta * (-2 * (1 / epoch) * w)

        wlr = np.reshape(np.frombuffer(w, dtype=np.float64), -1)
        wlr[0], wlr[1] = w[0], w[1]

    @staticmethod
    def lr(w, d, y):
        wlr = np.reshape(np.frombuffer(w, dtype=np.float64), -1)
        t = np.linalg.pinv(d) @ y  # Xt y
        wlr[0], wlr[1] = t[0], t[1]

    @staticmethod
    def m():
        rad = 10
        thk = 5
        sep = 5

        def init():
            from numpy.random import rand
            d0 = [(thk * rand() + rad, np.pi * rand()) for _ in range(1000)]  # polar x,r
            d1 = [(thk * rand() + rad, -1 * np.pi * rand()) for _ in range(1000)]
            d0 = [(a * np.cos(b), a * np.sin(b)) for a, b in d0]
            d1 = [(a * np.cos(b) + (rad + thk / 2.0), a * np.sin(b) - sep) for a, b in d1]

            return np.array(d0 + d1)

        def plot(wpla, wlr, wlr2, dataset):
            import wxmplot as wxmi
            import wx

            dataset0 = dataset[:1000]
            dataset1 = dataset[1000:]

            app = wx.App()
            frame = wxmi.PlotFrame()
            frame.plot(x=[0], y=[0], delay_draw=False, show_legend=True, legend_loc='ul', viewpad=10,
                       linewidth=0, xlabel='x', ylabel='y', label=' ')
            frame.oplot(x=dataset0.T[0], y=dataset0.T[1], label='-1', linewidth=0, marker='x', delay_draw=False)
            frame.oplot(x=dataset1.T[0], y=dataset1.T[1], label='+1', linewidth=0, marker='o', delay_draw=False)

            # pla w to ax+b
            xp = np.linspace(-30, 30, 100)
            a, b = wpla[0] / wpla[1], wpla[2] / wpla[1]
            yp = a * xp + b
            frame.oplot(x=xp, y=yp, label=f'PLA: {a:.1}x+{b:.1}', linewidth=1,
                        marker=' ', delay_draw=False)

            # lr
            yl = wlr[0] * xp + wlr[1]
            frame.oplot(x=xp, y=yl, label=f'LR (projection from R3): {wlr[0]:.1}x+{wlr[1]:.1}', linewidth=1, marker=' ',
                        delay_draw=False)

            yl2 = wlr2[0] * xp + wlr2[1]
            frame.oplot(x=xp, y=yl2, label=f'LR (R2): {wlr[0]:.1}x+{wlr[1]:.1}', linewidth=1, marker=' ',
                        delay_draw=False)

            frame.Show()
            app.MainLoop()

        y = 1000 * [-1] + 1000 * [1]
        dataset = init()

        w1, w2, w3 = mp.RawArray('d', 2), mp.RawArray('d', 4), mp.RawArray('d', 2)
        p1 = mp.Process(target=HW6.lr, args=(w1, dataset, y))
        p2 = mp.Process(target=HW6.pla, args=(w2, dataset, y))
        p3 = mp.Process(target=HW6.lr, args=(w3, np.vstack([dataset.T[0], np.ones(2000)]).T,
                                             dataset.T[1][:, np.newaxis]))

        p2.start()
        p1.start()
        p3.start()

        p1.join()
        p2.join()
        p3.join()

        wlr = np.reshape(np.frombuffer(w1, dtype=np.float64), -1)
        wpla, epla = (x := np.reshape(np.frombuffer(w2, dtype=np.float64), -1))[:3], x[3]
        wlr2 = np.reshape(np.frombuffer(w3, dtype=np.float64), -1)

        plot(wpla, wlr, wlr2, dataset)

    @staticmethod
    def m2():
        rad = 10
        thk = 5
        max = 26

        def init(s):
            from numpy.random import rand
            dataset0 = [(thk * rand() + rad, np.pi * rand()) for _ in range(1000)]  # polar x,r
            dataset1 = [(thk * rand() + rad, -1 * np.pi * rand()) for _ in range(1000)]
            dataset = [(a * np.cos(b), a * np.sin(b)) for a, b in dataset0] + [
                (a * np.cos(b) + (rad + thk / 2.0), a * np.sin(b) - s) for a, b in dataset1]

            return np.array(dataset)

        def plot(es):
            import wxmplot as wxmi
            import wx

            app = wx.App()
            frame = wxmi.PlotFrame()
            frame.plot(x=[0], y=[0], delay_draw=False, show_legend=True, legend_loc='ul', viewpad=10,
                       linewidth=0, xlabel='sep', ylabel='Epochs', label=' ')
            frame.oplot(x=[i * 2 / 10. for i in range(max)], y=es, label='Epochs', linewidth=0, marker='x',
                        delay_draw=False)

            frame.Show()
            app.MainLoop()

        y = 1000 * [-1] + 1000 * [1]
        d1 = init(0.1)

        ws = [mp.RawArray('d', 4) for _ in range(max)]
        ps = [mp.Process(target=HW6.pla, args=(w, init(i * 2 / 10.), y)) for i, w in enumerate(ws)]
        for p in ps: p.start()
        for p in ps: p.join()
        wplas, eplas = np.transpose([((x := np.reshape(np.frombuffer(w, dtype=np.float64), -1))[:3], x[3]) for w in ws])
        plot(eplas)

if __name__ == '__main__':
    HW6.m()
    HW6.m2()
