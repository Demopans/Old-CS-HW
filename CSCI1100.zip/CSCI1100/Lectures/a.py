#  Copyright (c)  lololol

from tkinter import *
a = Tk()
mainFrame = Frame(a)
mainFrame.pack()

topFrame = Frame(mainFrame)
topFrame.pack(side=TOP)



a.mainloop()