def recursive_add_impl(L, ind):
    if len(L)-1 == ind:
        return L[0]
    else:
        a = [L[ind]+L[ind+1]]+(L[ind+2:])
        return recursive_add_impl(a, 0)


def recursive_add(L):
    if len(L) == 0:
        return 0
    else:
        return recursive_add_impl(L, 0)


if __name__ == "__main__":
    L1 = [5]
    print(recursive_add(L1))
    L2 = [24, 23.1, 12, 15, 1]
    print(recursive_add(L2))
    print(recursive_add([]))
