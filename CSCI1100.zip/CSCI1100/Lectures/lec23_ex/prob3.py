def fib(n):
    i0 = 0
    i1 = 1
    for i in range(n):
        i2 = i1+i0
        i0 = i1
        i1 = i2
    return i0


if __name__ == "__main__":
    print(fib(0))
    print(fib(1))
    print(fib(2))
    print(fib(5))
    print(fib(10))
