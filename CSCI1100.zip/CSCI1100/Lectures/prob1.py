import math

if __name__ == '__main__':
    values = [-12, 0, 15, -16, -17.3, 8, 4, -5]
    new_values = list(map(abs,values))  ## Solution code goes here
    print(new_values)
