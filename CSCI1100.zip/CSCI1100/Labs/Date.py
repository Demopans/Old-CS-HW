"""
Start to the Date class for Lab 9.  This code will not run in Python
until three methods are added:
    __init__,
    __str__
    same_day_in_year
"""

days_in_month = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
month_names = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October',
               'November', 'December']


class Date(object):
    dd = 1
    mm = 1
    yyyy = 1900

    def __init__(self, yyyy=1900, mm=1, dd=1):
        """
        :param dd: Date
        :param mm: Month
        :param yyyy: Year
        """
        self.dd = dd
        self.mm = mm
        self.yyyy = yyyy

    def __str__(self):
        return str(self.yyyy) + "/" + str(self.mm).rjust(2, "0") + "/" + str(self.dd).rjust(2, "0")

    def same_day_in_year(self, dt):
        return (self.mm == dt.mm) and (self.mm == dt.mm)

    def isLeapYear(self):
        """
        :return: bool
        """
        if self.yyyy % 400 == 0:
            return True
        elif self.yyyy % 4 == 0 and self.yyyy % 100 != 0:
            return True
        return False

    def __lt__(self, dt):
        """
        :param dt: Date instance
        :return: bool
        """
        if self.yyyy < dt.yyyy:
            return True
        elif self.mm < dt.mm and self.yyyy == dt.yyyy:
            return True
        elif self.dd < dt.dd and self.mm == dt.mm and self.yyyy == dt.yyyy:
            return True
        return False

    def __gt__(self, dt):
        """
        :param dt: Date instance
        :return: bool
        """
        if self.yyyy > dt.yyyy:
            return True
        elif self.mm > dt.mm and self.yyyy == dt.yyyy:
            return True
        elif self.dd > dt.dd and self.mm == dt.mm and self.yyyy == dt.yyyy:
            return True
        return False

    def getYear(self):
        return self.yyyy

    def getMonth(self):
        return self.mm

    def getDay(self):
        return self.dd


if __name__ == "__main__":
    d1 = Date(1972, 3, 27)
    d2 = Date(1998, 4, 13)
    d3 = Date(1996, 4, 13)
    d4 = Date(2004)
    print("d1: " + str(d1))
    print("d2: " + str(d2))
    print("d3: " + str(d3))
    print("d1.same_day_in_year(d2)", d1.same_day_in_year(d2))
    print("d2.same_day_in_year(d3)", d2.same_day_in_year(d3))
    print("d4.isLeapYear()", d4.isLeapYear())
    print(d2 < d3)
