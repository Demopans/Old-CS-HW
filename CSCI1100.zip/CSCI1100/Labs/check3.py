#  Copyright (c)  lololol
import random

from Labs.check1 import *
from tkinter import *


if __name__ == '__main__':
    balls = []
    colorList = ["blue", "red", "green", "yellow", "magenta", "orange"]

    root = Tk()
    root.title("Tkinter: Lab 11")
    sim = Frame(root)
    sim.pack()


    while not sim.get:
        for i in balls:
            i.draw_ball()
    root.mainloop()
