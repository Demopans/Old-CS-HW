#  Copyright (c)  lololol

def add(num, n):
    if n == 0:
        return num
    else:
        return add(num, n - 1) + 1


def multi(num, n):
    if n == 1:
        return num
    elif n == 0:
        return 0
    elif n == -1:
        return -num
    else:
        return add(num, multi(num, n - 1))


def exp(num, n):
    if n == 1:
        return num
    elif n == 0:
        return 1
    else:
        return multi(num, exp(num, n - 1))


if __name__ == '__main__':
    print(add(5, 3))
    print(multi(8, 3))
    print(exp(6, 9))
