#  Copyright (c)  lololol

class ItemDraw(object):
    def __init__(self, x, y, dx, dy, xx, yy):
        """
        #:param parent: tkinter class
        :param x: xPos (float)
        :param y: yPos (float)
        :param dx: xVelocity (float)
        :param dy: yVelocity (float)
        :param xx: xWidth (tuple)
        :param yy: yWidth (tuple)
        """

        # inital data
        self.x = x
        self.y = y
        self.dx = dx
        self.dy = dy
        self.xDiff = xx
        self.yDiff = yy

        # ========DATA NEEDED FOR ANIMATION=========
        #  Here is the time in milliseconds between consecutive instances
        #  of drawing the ball.  If this time is too small the ball will
        #  zip across the canvas in a blur.
        self.wait_time = 100

        # this will allow us to stop moving the ball when the program quits
        self.isstopped = False

        self.maxx = 400  # canvas width, in pixels
        self.maxy = 400  # canvas height, in pixels

        # =============CREATE THE NEEDED GUI ELEMENTS===========
        ##  Create a frame, attach a canvas and 4 buttons to this frame
        ##  Buttons are used to cleanly exit the program;
        ##  to speed up or slow down the animation, and to restart
        ##  the animation.
        ##  Canvas, like an image, is an object that we can draw objects on.
        ##  This canvas is called chart_1.
        ##  Parent = root window, contains a frame
        ##  The frame contains the canvas and the 4 buttons.
        ##  We only care about the canvas in our animation
        """self.parent = parent
        self.frame = Frame(parent)
        self.frame.pack()
        self.top_frame = Frame(self.frame)
        self.top_frame.pack(side=TOP)
        self.canvas = Canvas(self.top_frame, background="white", width=self.maxx, height=self.maxy)
        self.canvas.pack()
        self.bottom_frame = Frame(self.frame)
        self.bottom_frame.pack(side=BOTTOM)
        self.restart = Button(self.bottom_frame, text="Restart", command=self.restart)
        self.restart.pack(side=LEFT)
        self.slow = Button(self.bottom_frame, text="Slower", command=self.slower)
        self.slow.pack(side=LEFT)
        self.fast = Button(self.bottom_frame, text="Faster", command=self.faster)
        self.fast.pack(side=LEFT)
        self.quit = Button(self.bottom_frame, text="Quit", command=self.quit)
        self.quit.pack(side=RIGHT)"""

    def faster(self):
        if self.wait_time > 2:
            self.wait_time //= 2

    def slower(self):
        self.wait_time *= 2

    """def quit(self):
        self.isstopped = True
        self.parent.destroy()"""

    def getPos(self):
        return self.x, self.y

    def getVel(self):
        return self.dx, self.dy

    def insideField(self):
        condition = 0 < self.x + self.xDiff[0] and self.x - self.xDiff[1] < self.maxx and 0 < self.y + self.yDiff[
            0] and self.y - self.yDiff[1] < self.maxy
        return condition

    def someInside(self, maxx, maxy):
        condition = 0 < self.x + self.xDiff[0] and self.x - self.xDiff[1] < maxx and 0 < self.y + self.yDiff[
            0] and self.y - self.yDiff[1] < maxy
        return condition

    def boundingBox(self):
        x0 = self.x - self.xDiff[0]
        x1 = self.x + self.xDiff[1]
        y0 = self.y - self.yDiff[0]
        y1 = self.y + self.yDiff[1]
        return x0, y0, x1, y1

    def bounce(self):
        obj = self.boundingBox()
        if obj[0] <= 0 or obj[2] >= self.maxx:
            self.dx = -1 * self.dx
        if obj[1] <= 0 or obj[3] >= self.maxy:
            self.dy = -1 * self.dy


class Ball(ItemDraw):
    def __init__(self, x, y, dx, dy, radius, color):
        self.x, self.y = x, y  # initial location
        self.ball_radius = radius
        self.dx, self.dy = dx, dy  # the movement of the ball object
        self.ball_color = color
        super().__init__(self.x, self.y,
                         self.dx, self.dy,
                         (self.ball_radius, self.ball_radius), (self.ball_radius, self.ball_radius))

    """def draw_ball(self):
        #  Remove all the previously-drawn balls
        self.canvas.delete("all")

        # Draw an oval on the canvas within the bounding box
        oval = (self.x - self.ball_radius,
                self.y - self.ball_radius,
                self.x + self.ball_radius,
                self.y + self.ball_radius)
        self.canvas.create_oval(oval, fill=self.ball_color)
        self.canvas.update()  # Actually refresh the drawing on the canvas.

        # Pause execution.  This allows the eye to catch up
        self.canvas.after(self.wait_time)"""

    def move(self):
        ##  Loop until the ball runs off the screen.

        while super().insideField() and not self.isstopped:
            # Move the ball
            # self.draw_ball()
            self.x += self.dx
            self.y += self.dy
            self.bounce()

    def restart(self):
        self.isstopped = False
        self.x, self.y = 80, 200
        self.move()

    def getColor(self):
        return self.ball_color
