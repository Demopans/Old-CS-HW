#  Copyright (c)  lololol
import random
from tkinter import *


class Frame(object):
    def __init__(self, parent):
        """
        :param parent: tkinter class
        """

        # ========DATA NEEDED FOR ANIMATION=========
        #  Here is the time in milliseconds between consecutive instances
        #  of drawing the ball.  If this time is too small the ball will
        #  zip across the canvas in a blur.
        self.wait_time = 100

        # this will allow us to stop moving the ball when the program quits
        self.isstopped = False

        self.maxx = 400  # canvas width, in pixels
        self.maxy = 400  # canvas height, in pixels

        # =============CREATE THE NEEDED GUI ELEMENTS===========
        ##  Create a frame, attach a canvas and 4 buttons to this frame
        ##  Buttons are used to cleanly exit the program;
        ##  to speed up or slow down the animation, and to restart the animation.
        ##  Canvas, like an image, is an object that we can draw objects on.
        ##  This canvas is called chart_1.
        ##  Parent = root window, contains a frame
        ##  The frame contains the canvas and the 4 buttons.
        ##  We only care about the canvas in our animation
        self.parent = parent
        self.frame = Frame(parent)
        self.frame.pack()
        self.top_frame = Frame(self.frame)
        self.top_frame.pack(side=TOP)
        self.canvas = Canvas(self.top_frame, background="white", width=self.maxx, height=self.maxy)
        self.canvas.pack()
        self.bottom_frame = Frame(self.frame)
        self.bottom_frame.pack(side=BOTTOM)
        self.restart = Button(self.bottom_frame, text="Restart", command=self.restart)
        self.restart.pack(side=LEFT)
        self.slow = Button(self.bottom_frame, text="Slower", command=self.slower)
        self.slow.pack(side=LEFT)
        self.fast = Button(self.bottom_frame, text="Faster", command=self.faster)
        self.fast.pack(side=LEFT)
        self.quit = Button(self.bottom_frame, text="Quit", command=self.quit)
        self.quit.pack(side=RIGHT)

    # Buttons
    def faster(self):
        if self.wait_time > 2:
            self.wait_time //= 2

    def slower(self):
        self.wait_time *= 2

    def quit(self):
        self.isstopped = True
        self.parent.destroy()

    def restart(self):
        self.isstopped = False
        for i in self.items.keys():
            data = self.items[i]["data"]
            self.items[i]["Ball"] = Ball(data[0], data[1], data[2], data[3], data[4], data[5], self.parent)

    def getIsStoppedState(self):
        return self.isstopped

    def getBounds(self):
        return self.maxx, self.maxy

    @staticmethod
    def getData():
        pass

    def createItems(self, type="1.b", mode="random"):
        """
        :param n: Number of items
        :param type: shape of item (currently balls). format: (num).(type)|... , num is a int, type {b:ball,}
        :param mode: default:"random"-entirely randomized
                     otherwise, input tuple of data in format ()

        """

        self.items = dict()
        n = int(type.split(".")[0])
        if mode == "random":
            colorList = ["blue", "red", "green", "yellow", "magenta", "orange"]
            if "b" in type:
                for i in range(n):
                    data = (random.randint(10, 390), random.randint(10, 390), random.randint(-8, 8),
                            random.randint(-8, 8), random.randint(5, 10), random.choice(colorList))
                    self.items[i]["Ball"] = Ball(data[0], data[1], data[2], data[3], data[4], data[5], self.parent)
                    self.items[i]["data"] = data

    def runSim(self):
        while not self.isstopped:
            for i in self.items.keys():
                self.items[i]["Ball"].move()

class Item(object):
    def __init__(self, x, y, dx, dy, xDiff, yDiff, frame):
        self.x, self.x0 = x, x
        self.y, self.y0 = y, y
        self.dx, self.dx0 = dx, dx
        self.dy, self.dy0 = dy, dy
        self.xDiff, self.yDiff = xDiff, yDiff
        self.frame = frame
        self.bounds = self.frame.getBounds()

    def getPos(self):
        return self.x, self.y

    def getVel(self):
        return self.dx, self.dy

    def move(self):
        #while self.insideField() and not self.frame.getIsStoppedState():
            # Move the ball
        self.bounce()
        self.x += self.dx
        self.y += self.dy

    def insideField(self):
        condition = 0 < self.x + self.xDiff[0] and self.x - self.xDiff[1] < self.bounds[0] and 0 < self.y + \
                    self.yDiff[0] and self.y - self.yDiff[1] < self.bounds[1]
        return condition

    def someInside(self, sub, maxx, maxy):
        condition = 0 < self.x + self.xDiff[0] and self.x - self.xDiff[1] < maxx and 0 < self.y + self.yDiff[
            0] and self.y - self.yDiff[1] < maxy
        return condition

    def boundingBox(self):
        x0 = self.x - self.xDiff[0]
        x1 = self.x + self.xDiff[1]
        y0 = self.y - self.yDiff[0]
        y1 = self.y + self.yDiff[1]
        return x0, y0, x1, y1

    def bounce(self):
        obj = self.boundingBox()
        if obj[0] <= 0 or obj[2] >= self.bounds[0]:
            self.dx = -1 * self.dx
        if obj[1] <= 0 or obj[3] >= self.bounds[1]:
            self.dy = -1 * self.dy


class Ball(Item):
    def __init__(self, x, y, dx, dy, radius, color, frame):
        self.ball_radius = radius  # the radius of the ball object
        self.ball_color = color
        # inital data
        self.xDiff = self.ball_radius, self.ball_radius
        self.xDiff = self.ball_radius, self.ball_radius
        super().__init__(x, y, dx, dy, self.xDiff, self.xDiff, frame)

    def draw_ball(self):
        #  Remove all the previously-drawn balls
        self.frame.canvas.delete("all")

        # Draw an oval on the canvas within the bounding box
        oval = (self.x - self.ball_radius,
                self.y - self.ball_radius,
                self.x + self.ball_radius,
                self.y + self.ball_radius)
        self.frame.canvas.create_oval(oval, fill=self.ball_color)
        self.frame.canvas.update()  # Actually refresh the drawing on the canvas.

        # Pause execution.  This allows the eye to catch up
        self.frame.canvas.after(self.frame.wait_time)

    def getColor(self):
        return self.ball_color


if __name__ == "__main__":
    pass
    ##  We will create a root object, which will contain all
    ##  our user interface elements
    ##
