#  Copyright (c)  lololol
import math

from Labs.Date import Date


def conFile(file):
    bDays = open(file).read().split("\n")
    bDays0 = []
    for i in bDays:
        if len(i) > 0:
            a = i.split(" ")
            bDays0.append(a)

    bDays1 = []
    for i in bDays0:
        bDays1.append(Date(int(i[0]), int(i[1]), int(i[2])))
    return bDays1


def findSmall(data):
    dt = Date(99999999, 12, 31)
    for i in data:
        case = dt > i
        if case:
            dt = i
    return dt


def findBig(data):
    dt = Date(0, 0, 0)
    for i in data:
        case = dt < i
        if case:
            dt = i
    return dt


def findMode(data):
    m = dict()
    for i in data:
        if i.getMonth() not in m.keys():
            m[i.getMonth()] = [i]
        else:
            m[i.getMonth()].append(i)
    a = 0
    key = ""
    for i in m.keys():
        if len(m[i]) > a:
            a = len(m[i])
            key = i
    b = m[key]
    return b


if __name__ == '__main__':
    file = "birthdays.txt"
    birthdays = conFile(file)

    print("earliest " + str(findSmall(birthdays)))
    print("latest " + str(findBig(birthdays)))

    for i in findMode(birthdays):
        a = str(i).split("/")
        if a[1] == "01":
            print("{} {} {}".format("January", a[2], a[0]))
        elif a[1] == "02":
            print("{} {} {}".format("February", a[2], a[0]))
        elif a[1] == "03":
            print("{} {} {}".format("March", a[2], a[0]))
        elif a[1] == "04":
            print("{} {} {}".format("April", a[2], a[0]))
        elif a[1] == "05":
            print("{} {} {}".format("May", a[2], a[0]))
        elif a[1] == "06":
            print("{} {} {}".format("June", a[2], a[0]))
        elif a[1] == "07":
            print("{} {} {}".format("July", a[2], a[0]))
        elif a[1] == "08":
            print("{} {} {}".format("Augesest", a[2], a[0]))
        elif a[1] == "09":
            print("{} {} {}".format("September", a[2], a[0]))
        elif a[1] == "10":
            print("{} {} {}".format("October", a[2], a[0]))
        elif a[1] == "11":
            print("{} {} {}".format("November", a[2], a[0]))
        elif a[1] == "12":
            print("{} {} {}".format("December", a[2], a[0]))
