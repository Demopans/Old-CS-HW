base10size = input("Disk size in GB => ")
print(base10size)
base2size = int(base10size) * pow(10, 9) / pow(2, 30)
lost_size = int(base10size) - base2size + 1
print(str(base10size) + " GB in base 10 is actually " + str(int(base2size)) + " GB in base 2, " + str(
    int(lost_size)) + " GB less than advertised.")
Input = int(base10size) * "*"
Actual = int(base2size) * "*"
print("Input:  " + Input + "\nActual: " + Actual)
