from __future__ import print_function

import PIL
from PIL import Image

imgs = [Image.open("lab03files/lab03files/1.jpg"), Image.open("lab03files/lab03files/2.jpg"),
        Image.open("lab03files/lab03files/3.jpg"), Image.open("lab03files/lab03files/4.jpg"),
        Image.open("lab03files/lab03files/5.jpg"), Image.open("lab03files/lab03files/6.jpg")]
im = Image.new("RGB", (1000, 360))
imgg = Image.open("Ythreflag.jpg")
imgg = imgg.resize((1000, 360))
for i in range(len(imgs)):
    imgs[i] = imgs[i].resize((148, 256))
for i in range(len(imgs)):
    if i % 2 == 0:
        imgg.paste(imgs[i], (36 + 156 * i, 20))
    else:
        imgg.paste(imgs[i], (36 + 156 * i, 60))
imgg.show()
