#  Copyright (c)  lololol

from HW.Mob import Mob

class Bear(Mob):
    def __init__(self, x, y, bearing, active):
        """
        :param x: x value (int)
        :param y: y value (int)
        :param bearing: direction (str)
        :param active: onField (bool)
        """
        super().__init__(x, y, bearing, active)
        self.bCount = 0
        self.sleep = 0

    @staticmethod
    def getType():
        return "Bear"

    def eatTourist(self, tList):
        """
        We knew what really happened
        :param tList: Tourist List
        """
        for i in tList:
            if self.getPos() == i.getPos():
                i.isEaten()
                self.sleep = 2

    def decreaseSleep(self):
        if self.sleep != 0:
            self.sleep -= 1

    def eatBerry(self, field):
        if field[self.x][self.y] + self.bCount <= 30:
            self.bCount += field[self.x][self.y]
            field[self.x][self.y] = 0
        else:
            var = 30 - self.bCount
            field[self.x][self.y] -= var
            self.bCount = 30

    def getInfo(self):
        return self.getPos()

    def move(self):
        if self.sleep == 0:
            if "N" in self.bearing:
                self.x -= 1
            elif "S" in self.bearing:
                self.x += 1
            if "E" in self.bearing:
                self.y += 1
            elif "W" in self.bearing:
                self.y -= 1

    def __str__(self):
        return "{} {}".format(self.getPos(), self.bearing)
