#  Copyright (c)  lololol

class BerryField:
    def __init__(self, field, tList, bList):
        """
        :param field: field data
        :param tList: tourist list
        :param bList: bear list
        """
        self.field = field
        self.tList, self.bList = tList, bList

    def spread(self):
        # grows
        for i in range(len(self.field)):
            for j in range(len(self.field[i])):
                if 0 < self.field[i][j] < 10:
                    self.field[i][j] += 1
        # spreads
        for i in range(len(self.field)):
            for j in range(len(self.field[i])):
                if self.field[i][j] == 0:
                    # corner
                    if i > 0 and j > 0 and self.field[i - 1][j - 1] == 10:
                        self.field[i][j] += 1
                    elif i < len(self.field) - 1 and j < len(self.field[i]) - 1 and self.field[i + 1][j + 1] == 10:
                        self.field[i][j] += 1
                    elif i < len(self.field) - 1 and j > 0 and self.field[i + 1][j - 1] == 10:
                        self.field[i][j] += 1
                    elif i > 0 and j < len(self.field[i]) - 1 and self.field[i - 1][j + 1] == 10:
                        self.field[i][j] += 1
                    # sides
                    elif i > 0 and self.field[i - 1][j] == 10:
                        self.field[i][j] += 1
                    elif j > 0 and self.field[i][j - 1] == 10:
                        self.field[i][j] += 1
                    elif i < len(self.field) - 1 and self.field[i + 1][j] == 10:
                        self.field[i][j] += 1
                    elif j < len(self.field[i]) - 1 and self.field[i][j + 1] == 10:
                        self.field[i][j] += 1

    def display(self):
        for i in range(len(self.field)):
            for j in range(len(self.field[i])):
                spotData = str(self.field[i][j])
                tLen, bLen = len(self.tList), len(self.bList)
                t, b = 0, 0
                # multi array searching complex
                while t < tLen or b < bLen:
                    # multi list search
                    # tourist
                    if t < tLen:
                        if self.tList[t].active and self.tList[t].getPos() == (i, j):
                            spotData = spotData + "T"
                        t += 1
                    # bear
                    if b < bLen:
                        if self.bList[b].active and self.bList[b].getPos() == (i, j):
                            spotData = spotData + "B"
                        b += 1

                if "T" in spotData and "B" in spotData:  # spotData parser
                    spotData = "X"
                elif "T" in spotData:
                    spotData = "T"
                elif "B" in spotData:
                    spotData = "B"

                print("{:>4}".format(str(spotData)), end="")
            print()

    def bCount(self):
        sigma = 0
        for i in self.field:
            sigma += sum(i)
        return sigma

    def bounds(self):
        return len(self.field), len(self.field[0])
