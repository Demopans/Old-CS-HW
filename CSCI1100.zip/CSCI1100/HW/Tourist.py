#  Copyright (c)  lololol

from HW.Mob import Mob

class Tourist(Mob):
    def __init__(self, x, y, active):
        """
        :param x: x position
        :param y: y position
        """
        super().__init__(x, y, "0", active)
        self.isDed = False
        self.turns = 0

    @staticmethod
    def getType():
        return "Tourist"

    def seenBear(self, bList):
        sig = 0
        for i in bList:
            bPos = i.getPos()
            tPos = self.getPos()
            if ((bPos[0] - tPos[0]) ** 2 + (bPos[1] - tPos[1]) ** 2) <= 4 ** 2 and i.active:
                sig += 1
        return sig

    def turnsNoBear(self, info):
        if self.turns == 3:
            self.isEaten()  # By the earth
        elif info == 0:
            self.turns += 1
        else:
            self.turns = 0

    def bail(self, info):
        if info >= 3:
            self.isEaten()

    def isEaten(self):
        print("Tourist at ({},{}), {} turns without seeing a bear. - Left the Field".format(self.x, self.y, self.turns))
        self.x, self.y = (999, 999)  # yeets it to limbo, not ded in certain cases but considered as such
        self.isDed = True
        self.active = False

    def __str__(self):
        return "{}".format(self.getPos())

