#  Copyright (c)  lololol
class Mob:
    """
    Superclass to Bear and Tourist. Handles basic functionality
    """

    def __init__(self, x, y, bearing, active):
        """
        :param x: x position
        :param y: y position
        """
        self.x, self.y = x, y
        self.bearing = bearing
        self.active = active

    def getPos(self):
        return self.x, self.y

    def markPos(self, field, ty):
        field[self.x][self.y] = ty

    # deprecated
    def removePos(self, field):
        field[self.x][self.y] = "."

    def inBounds(self, field):
        pos = self.getPos()
        xCon = 0 <= pos[0] < field.bounds()[0]
        yCon = 0 <= pos[1] < field.bounds()[1]
        return xCon and yCon

    def changePos(self, pos):
        self.x, self.y = pos


class Tourist(Mob):
    """
    Holds functions specific to the Tourist class.
    """

    def __init__(self, x, y, active):
        """
        :param x: x position
        :param y: y position
        """
        super().__init__(x, y, "0", active)
        self.isDed = False
        self.turns = 0

    @staticmethod
    def getType():
        return "Tourist"

    def seenBear(self, bList):
        sig = 0
        for i in bList:
            bPos = i.getPos()
            tPos = self.getPos()
            if ((bPos[0] - tPos[0]) ** 2 + (bPos[1] - tPos[1]) ** 2) <= 16 and i.active:
                sig += 1
        return sig

    def turnsNoBear(self, info):
        if self.turns == 2:
            self.leave()  # By the earth
        elif info == 0:
            self.turns += 1
        else:
            self.turns = 0

    def bail(self, info):
        if info >= 3:
            self.isEaten()

    def leave(self):
        print("Tourist at ({},{}), 3 turns without seeing a bear. - Left the Field".format(self.x, self.y))
        self.isDed = True
        self.active = False

    def isEaten(self):
        print("Tourist at ({},{}), {} turns without seeing a bear. - Left the Field".format(self.x, self.y, self.turns))
        self.x, self.y = (999, 999)  # yeets it to limbo, not ded in certain cases but considered as such
        self.isDed = True
        self.active = False

    def __str__(self):
        return "{}".format(self.getPos())


class Bear(Mob):
    """
        Holds functions specific to the Bear class.
    """

    def __init__(self, x, y, bearing, active):
        """
        :param x: x value (int)
        :param y: y value (int)
        :param bearing: direction (str)
        :param active: onField (bool)
        """
        super().__init__(x, y, bearing, active)
        self.bCount = 0
        self.sleep = 0

    @staticmethod
    def getType():
        return "Bear"

    def eatTourist(self, tList):
        """
        We knew what really happened
        :param tList: Tourist List
        """
        for i in tList:
            if self.getPos() == i.getPos() and i.active:
                i.isEaten()
                self.sleep = 2

    def decreaseSleep(self):
        if self.sleep != 0:
            self.sleep -= 1

    def eatBerry(self, field):
        if field[self.x][self.y] + self.bCount <= 30:
            self.bCount += field[self.x][self.y]
            field[self.x][self.y] = 0
        else:
            var = 30 - self.bCount
            field[self.x][self.y] -= var
            self.bCount = 30

    def getInfo(self):
        return self.getPos()

    def move(self):
        if self.sleep == 0:
            if "N" in self.bearing:
                self.x -= 1
            elif "S" in self.bearing:
                self.x += 1
            if "E" in self.bearing:
                self.y += 1
            elif "W" in self.bearing:
                self.y -= 1

    def __str__(self):
        return "{} {} {}".format(self.getPos(), self.bearing, self.active)


class BerryField:
    """
    Contains the field and related operations the Tourists and Bears play in. Maintains a specific list of MoB references
    """

    def __init__(self, field, tList, bList):
        """
        :param field: field data
        :param tList: tourist list
        :param bList: bear list
        """
        self.field = field
        self.tList, self.bList = tList, bList

    def spread(self):
        # grows
        for i in range(len(self.field)):
            for j in range(len(self.field[i])):
                if 0 < self.field[i][j] < 10:
                    self.field[i][j] += 1
        # spreads
        for i in range(len(self.field)):
            for j in range(len(self.field[i])):
                if self.field[i][j] == 0:
                    # corner
                    if i > 0 and j > 0 and self.field[i - 1][j - 1] == 10:
                        self.field[i][j] += 1
                    elif i < len(self.field) - 1 and j < len(self.field[i]) - 1 and self.field[i + 1][j + 1] == 10:
                        self.field[i][j] += 1
                    elif i < len(self.field) - 1 and j > 0 and self.field[i + 1][j - 1] == 10:
                        self.field[i][j] += 1
                    elif i > 0 and j < len(self.field[i]) - 1 and self.field[i - 1][j + 1] == 10:
                        self.field[i][j] += 1
                    # sides
                    elif i > 0 and self.field[i - 1][j] == 10:
                        self.field[i][j] += 1
                    elif j > 0 and self.field[i][j - 1] == 10:
                        self.field[i][j] += 1
                    elif i < len(self.field) - 1 and self.field[i + 1][j] == 10:
                        self.field[i][j] += 1
                    elif j < len(self.field[i]) - 1 and self.field[i][j + 1] == 10:
                        self.field[i][j] += 1

    def display(self):
        for i in range(len(self.field)):
            for j in range(len(self.field[i])):
                spotData = str(self.field[i][j])
                tLen, bLen = len(self.tList), len(self.bList)
                t, b = 0, 0
                # multi array searching complex
                while t < tLen or b < bLen:
                    # multi list search
                    # tourist
                    if t < tLen:
                        if self.tList[t].active and self.tList[t].getPos() == (i, j):
                            spotData = spotData + "T"
                        t += 1
                    # bear
                    if b < bLen:
                        if self.bList[b].active and self.bList[b].getPos() == (i, j):
                            spotData = spotData + "B"
                        b += 1

                if "T" in spotData and "B" in spotData:  # spotData parser
                    spotData = "X"
                elif "T" in spotData:
                    spotData = "T"
                elif "B" in spotData:
                    spotData = "B"

                print("{:>4}".format(str(spotData)), end="")
            print()

    def bCount(self):
        sigma = 0
        for i in self.field:
            sigma += sum(i)
        return sigma

    def bounds(self):
        return len(self.field), len(self.field[0])
