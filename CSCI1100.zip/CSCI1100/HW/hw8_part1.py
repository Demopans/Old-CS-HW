#  Copyright (c)  lololol
import json
from HW.hw8_classes import *
"""
Fair warning. Due to how the classes are structured, It is infeasible to place them in separate files. All classes are in hw_8classes.py
Also, you may see previous sections of code commented out from the process of iterative development

"""


# test function
def makeBulkMob(param="1|1|1"):
    """
    :param param: string of parameter, format bear|tourist
    :return: dict of Mob
    """
    a = param.split("|")
    mobList = []
    for i in range(int(a[0])):
        mobList.append(Bear(0, 0, "S", True))
    for i in range(int(a[1])):
        mobList.append(Tourist(0, 0, True))
    return mobList


if __name__ == '__main__':
    mobs = makeBulkMob()

    file = input("Enter the json file name for the simulation => ")
    print(file)
    # parses json
    data = json.load(open(file))

    tourist = [data["active_tourists"], data["reserve_tourists"]]
    bear = [data["active_bears"], data["reserve_bears"]]

    tourists = []
    bears = []
    for i in tourist[0]:
        tourists.append(Tourist(i[0], i[1], True))
    for i in tourist[1]:
        tourists.append(Tourist(i[0], i[1], False))
    for i in bear[0]:
        bears.append(Bear(i[0], i[1], i[2], True))
    for i in bear[1]:
        bears.append(Bear(i[0], i[1], i[2], False))

    field = BerryField(data["berry_field"], tourists, bears)
    # rumentarly field testing

    print("\nField has {} berries.".format(field.bCount()))
    field.display()
    # a.spread()
    # print(a.bCount())
    # field.display()
    print("\nActive Bears:")
    for i in bears:
        if i.active:
            print("Bear at ({},{}) moving {}".format(i.getPos()[0],i.getPos()[1], i.bearing))
    print("\nActive Tourists:")
    for i in tourists:
        if i.active:
            print("Tourist at ({},{}), 0 turns without seeing a bear.".format(i.getPos()[0],i.getPos()[1]))

    # runs the simulation
    """
    while True:
        # condition in ready access
        condition = True
        if condition:
            break
        for i in mobs:
            # patented array deborker

            i.markPos(field, i.getType())
            try:
                i.eatTourist(mobs)
                i.increaseActive()
            finally:
                pass

        print(field)
    """
