#  Copyright (c)  lololol
"""
Fair warning. Due to how the classes are structured, It is infeasible to place them in separate files. All classes are in hw_8classes.py
Also, you may see previous sections of code commented out from the process of iterative development

"""
import json
from HW.hw8_classes import *

if __name__ == '__main__':
    file = input("Enter the json file name for the simulation => ")
    print(file + "\n")
    # parses json
    data = json.load(open(file))

    tourist = [data["active_tourists"], data["reserve_tourists"]]
    bear = [data["active_bears"], data["reserve_bears"]]

    tourists = []
    bears = []
    for i in tourist[0]:
        tourists.append(Tourist(i[0], i[1], True))
    for i in tourist[1]:
        tourists.append(Tourist(i[0], i[1], False))
    for i in bear[0]:
        bears.append(Bear(i[0], i[1], i[2], True))
    for i in bear[1]:
        bears.append(Bear(i[0], i[1], i[2], False))

    field = BerryField(data["berry_field"], tourists, bears)
    print("Starting Configuration")
    print("Field has {} berries.".format(field.bCount()))
    # a.spread()
    # print(a.bCount())
    field.display()
    print("\nActive Bears:")
    for i in bears:
        if i.active:
            print("Bear at ({},{}) moving {}".format(i.getPos()[0], i.getPos()[1], i.bearing))
    print("\nActive Tourists:",end="")
    for i in tourists:
        if i.active and not i.isDed:
            print()
            print("Tourist at ({},{}), {} turns without seeing a bear.".format(i.getPos()[0], i.getPos()[1], i.turns),end="")

    # runs the simulation
    runs = 1
    while runs <= 5:  # condition
        tIndex, bIndex = 0, 0

        print("\n\nTurn: " + str(runs))
        field.spread()

        # old engine
        """# actions construct
        while tIndex < len(tourists) or bIndex < len(bears):
            # bear command
            if bIndex != len(bears):
                bear0 = bears[bIndex]
                if bear0.inBounds(field) and bear0.active and bear0.sleep == 0:
                    bear0.bCount = 0
                    while bear0.inBounds(field) and bear0.bCount < 30 and bear0.sleep == 0:
                        bear0.eatTourist(tourists)
                        if bear0.sleep == 0:
                            bear0.eatBerry(field.field)
                            if bear0.bCount < 30:
                                bear0.move()
                            if not bear0.inBounds(field):
                                print("Bear at ({},{}) moving {} - Left the Field".format(bear0.getPos()[0],
                                                                                          bear0.getPos()[1],
                                                                                          bear0.bearing))
                else:
                    bear0.decreaseSleep()

                bIndex += 1
                # tourist command
                if tIndex != len(tourists):
                    tourist0 = tourists[tIndex]
                    if tourist0.active:
                        bCount = tourist0.seenBear(bears)
                        tourist0.bail(bCount)
                        tourist0.turnsNoBear(bCount)
                    tIndex += 1"""

        # bear command
        for bear0 in bears:
            if bear0.inBounds(field) and bear0.active and bear0.sleep == 0:
                bear0.bCount = 0
                while bear0.inBounds(field) and bear0.bCount < 30 and bear0.sleep == 0:
                    bear0.eatTourist(tourists)
                    if bear0.sleep == 0:
                        bear0.eatBerry(field.field)
                        if bear0.bCount < 30:
                            bear0.move()
                        if not bear0.inBounds(field):
                            print("Bear at ({},{}) moving {} - Left the Field".format(bear0.x,
                                                                                      bear0.y,
                                                                                      bear0.bearing))
                            bear0.active = False
            else:
                bear0.decreaseSleep()

        # tourist command
        for tourist0 in tourists:
            if tourist0.active:
                bCount = tourist0.seenBear(bears)
                tourist0.bail(bCount)
                tourist0.turnsNoBear(bCount)

        runs += 1

        print("Field has {} berries.".format(field.bCount()))
        field.display()

        print("\nActive Bears:")
        for i in bears:
            if i.active and i.inBounds(field):
                print("Bear at ({},{}) moving {}{}".format(i.getPos()[0], i.getPos()[1], i.bearing,
                                                           " - Asleep for {} more turns".format(
                                                               i.sleep) if i.sleep > 0 else ""))  # python be darned
        print("\nActive Tourists:")
        for i in tourists:
            if i.active and not i.isDed:
                print(
                    "Tourist at ({},{}), {} turns without seeing a bear. {}".format(i.getPos()[0], i.getPos()[1],
                                                                                    i.turns, " - Left the Field" if i.isDed else ""))
