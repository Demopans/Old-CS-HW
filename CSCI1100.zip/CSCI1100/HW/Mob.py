#  Copyright (c)  lololol

class Mob:
    def __init__(self, x, y, bearing, active):
        """
        :param x: x position
        :param y: y position
        """
        self.x, self.y = x, y
        self.bearing = bearing
        self.active = active

    def getPos(self):
        return self.x, self.y

    def markPos(self, field, ty):
        field[self.x][self.y] = ty

    def removePos(self, field):
        field[self.x][self.y] = "."

    def inBounds(self, field):
        pos = self.getPos()
        xCon = 0 <= pos[0] < field.bounds()[0]
        yCon = 0 <= pos[1] < field.bounds()[1]
        return xCon and yCon

