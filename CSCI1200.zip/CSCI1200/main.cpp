#include <iostream>

int main() {
    std::string statement = "Hello, World!";
    std::cout << statement << std::endl;
    char *p = NULL;
    {
        char c;
        p = &c;
    }// Now p is dangling
    *p='A';
}