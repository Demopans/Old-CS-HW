//
// Created by gaoje on 1/22/2020.
//

#include "Time.h"

Time::Time(int hr, int min, int sec) : hr(hr), min(min), sec(sec) {
    setTime(hr,min,sec);
}
void Time::setTime(int hr, int min, int sec){
    this->hr = hr;
    this->min = min;
    this->sec = sec;
}
int Time::getHour() {
    return hr;
}

int Time::getMinute() {
    return min;
}

int Time::getSecond()  {
    return sec;
}

void Time::setHour(int hr) {
    this->hr = hr;
}

void Time::setMinute(int min) {
    this->min = min;
}

void Time::setSecond(int sec) {
    this->sec = sec;
}

std::string Time::PrintAMPM() {
    if (Time::hr>12){
        std::string a = std::to_string(Time::hr-12);
        std::string b = std::to_string(Time::min);
        std::string c = std::to_string(Time::sec);
        return a+":"+b+":"+c+"PM";
    } else{
        std::string a = std::to_string(Time::hr);
        std::string b = std::to_string(Time::min);
        std::string c = std::to_string(Time::sec);
        return a+":"+b+":"+c+"AM";
    }
}



