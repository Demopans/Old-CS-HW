//
// Created by gaoje on 1/22/2020.
//

#ifndef LAB2_TIME_H
#define LAB2_TIME_H


#include <iostream>

class Time {
private:
    int hr;
    int min;
    int sec;
public:
    explicit Time(int hr = 0, int min = 0, int sec = 0);

    void setTime(int hr, int min, int sec);

    int getHour();
    int getMinute();
    int getSecond();
    void setHour(int hr);
    void setMinute(int min);
    void setSecond(int sec);
    std::string PrintAMPM();
};


#endif //LAB2_TIME_H
