#include <iostream>
#include <string>


// Note: It's ok that all the member variables are public for this
// tiny class.  We'll build up to a more robust and complete linked
// list implementation in lecture 11.
template <class T>
class Node {
public:
  T value;
  Node<T> *nPtr;
};



template <class T>
void print(Node<T> *&data, const std::string &label) {
  std::cout << label;
  Node<T> *tmp = data;
  while (tmp != nullptr) {
    std::cout << " " << tmp->value;
    tmp = tmp->nPtr;
  }
  std::cout << std::endl;
}


//would be easier as a doubly linked list prob
template <class T>
void reverse(Node<T> *&input) {
    //specfic case, since nodes arent abstracted
    int ct = 0;
    Node<T> *tmp0 = input, *tmp1 = input;
    while (tmp0 != nullptr) {//gets len
        tmp0 = tmp0->nPtr;
        ct++;
    }
    if(ct == 0){
        return;
    }
    Node<T> a[ct];
    for (int i = 0; i < ct; ++i) {
        a[i] = *tmp1;
        tmp1 = tmp1->nPtr;
    }
    for (int i = ct-1; i >= 0; i--) {
        if(i == 0){
            a[i].nPtr = nullptr;
            delete input;
            input = &a[ct-1];
            break;
        }
        a[i].nPtr = &a[i-1];
    }
}
int main() {

  // manually create a linked list of notes with 4 elements
  Node<int>* my_list = new Node<int>;
  //val 1
  my_list->value = 1;
  my_list->nPtr = new Node<int>;
  //val2
  my_list->nPtr->value = 2;
  my_list->nPtr->nPtr = new Node<int>;
  //val3
  my_list->nPtr->nPtr->value = 3;
  my_list->nPtr->nPtr->nPtr = new Node<int>;
  //val4
  my_list->nPtr->nPtr->nPtr->value = 4;
  my_list->nPtr->nPtr->nPtr->nPtr = nullptr;


  print(my_list,"my_list before");
  reverse(my_list);
  print(my_list,"my_list after ");


  // Note: We are not deleting any of the Nodes we created...  so this
  // program has memory leaks!  More on this in lecture 11.

}

// ===========================================================================