#include <iostream>
#include <fstream>

int main(int argc, char *argv[]){

    /*std::ifstream in_str(argv[3]);
    if (!in_str.good()) {
        std::cerr << "Can't open " << argv[3] << " to read.\n";
        exit(1);
    }*/
    for(int i=1; i <= argc; i++){ // i=1, assuming files arguments are right after the executable
        std::string fn = argv[i]; //filename
        std::cout << fn;
        std::fstream f;
        f.open(fn);
        //your logic here
        f.close();
    }

	file.close();
	int a = min();
	int b = mean();
	return 0;
}

int min(int arr[]){
    int x = 1000;
    for(int i = 0; i < arr.length; i++){
        if (arr[i] < x){
            arr[i] = x;
        }
    }
    return x;
}

int mean(int arr[]){
    int x = 0;
    for(int i = 0; i < arr.length; i++){
        x += arr[i];
    }
    x = x/arr.length;
    return x;
}