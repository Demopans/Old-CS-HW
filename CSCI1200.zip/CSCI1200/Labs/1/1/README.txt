LAB 1: GETTING STARTED

NAME: Jeff Gao

COLLABORATORS AND OTHER RESOURCES:

NAMES OF YOUR TA & MENTORS

Who is your graduate lab TA? 

Who are the undergraduate programming mentors assigned to your lab?















