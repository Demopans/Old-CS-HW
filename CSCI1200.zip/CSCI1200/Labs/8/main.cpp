// Starting code for Checkpoints 2 and 3.  This includes
// functions to read the grid and to output it.

#include <fstream>
#include <iostream>
#include <list>
#include <vector>
#include <cmath>

using namespace std;


// A simple class to represent a point location.  It only has a
// constructor and a two public member variables.  This is one of the
// few times that you are allowed to use non-private member variables.

class Point {
public:
    Point(int x0, int y0) : x(x0), y(y0) {}
    int x, y;
    static bool isEqual(const Point &a, const Point &b){
        return a.x == b.x && a.y == b.y;
    }

};
bool operator==(const Point &a, const Point &b){
    return Point::isEqual(a,b);
}
bool operator!=(const Point &a, const Point &b){
    return !Point::isEqual(a,b);
}
// Input the grid and the start location.  The input is a sequence of
// x y locations, terminated by x==0 and y==0.  The last input, which
// follows 0 0 input, is the start location.
//
// The grid is represented as a 2d vector of bools, with each location
// that is blocked --- meaning that no path can go through --- being
// represented by the value "true".  The grid is large enough to
// include all blocked points and include the starting location.  The
// first coordinate of the vector of vectors is the x coordinate, and
// the second is the y coordinate.  The format of the input is
// specified in the lab handout.

void read_grid(istream &istr, vector<vector<bool> > &blocked_grid,
               int &start_x, int &start_y) {

    // Read the x y locations into a list of Points.  Keep track of the
    // max x and max y values so that the size of the grid can be
    // determined.
    int x, y;
    int max_x = 0, max_y = 0;  // keep track of the max coordinate values
    list<Point> blocked_points;
    while ((istr >> x >> y) && !(x == 0 && y == 0)) {
        blocked_points.push_back(Point(x, y));
        if (x > max_x) max_x = x;
        if (y > max_y) max_y = y;
    }

    // Now that a 0 0 location has been read, read the start location.
    // If this is beyond the max x or y value then update these values.
    istr >> start_x >> start_y;
    if (start_x > max_x) max_x = start_x;
    if (start_y > max_y) max_y = start_y;

    // Make a vector of vectors with all entries marked false.
    vector<bool> one_row_of_ys(max_y + 1, false);
    vector<vector<bool> > empty_grid(max_x + 1, one_row_of_ys);
    blocked_grid = empty_grid;

    // For Point in the list, mark the location in the list as blocked.
    list<Point>::iterator p;
    for (p = blocked_points.begin(); p != blocked_points.end(); ++p) {
        blocked_grid[p->x][p->y] = true;
    }
}


// Output the grid to cout.  The form of the output is explained in
// the cout statement below.

void print_grid(vector<vector<bool> > const &blocked_grid, int start_x, int start_y) {

    cout << "Here is the grid with the origin in the upper left corner, x increasing \n"
         << "horizontally and y increasing down the screen.  An 'X' represents a blocked\n"
         << "location and the 'S' represents the starting location.\n\n";

    for (int y = 0; y < blocked_grid[0].size(); ++y) {
        for (int x = 0; x < blocked_grid.size(); ++x) {
            if (x == start_x && y == start_y)
                cout << " S";
            else if (blocked_grid[x][y])
                cout << " X";
            else
                cout << " .";
        }
        cout << '\n';
    }
}

int getDistance(const Point &a, const Point &b) {
    return std::floor(std::sqrt(std::pow((a.x - b.x), 2) + std::pow((a.y - b.y), 2)));
}

bool checkBounds(const Point &a,const std::vector<Point> &barrier, int lBound, int rBound, int tBound, int bBound){
    bool cond ((lBound <= a.x <= rBound) && (bBound <= a.y <= tBound));
    if(cond){
        for (Point i : barrier) {
            if(i == a){
                return false;
            }
        }
    }else{return false;}
    return true;
}
/**
 * @brief
 * @param currPoint
 * @param prevPoint
 * @param target
 * @param paths
 * @param mode: assigns index
 * @return
 */
bool getPathsToPoint(const Point &currPoint, const Point &prevPoint, const Point &target, std::vector<std::vector<Point>> &paths,
        int mode) {
    if(currPoint == target){
        paths[mode].push_back(currPoint);
        return true;
    }

    double currD = getDistance(currPoint, target);
    int ctr = 0;

    if (currPoint.x != prevPoint.x && currPoint.y - 1 != prevPoint.y) {
        Point a(currPoint.x, currPoint.y - 1);
        double aD = getDistance(a, target);
        if(currD>=aD){
            bool cond = getPathsToPoint(a,currPoint,target,paths,mode);
            if(cond){
                paths[mode + ctr] = paths[mode];
                paths[mode + ctr].push_back(a);
                ctr++;
            }
        }
    }

    if (currPoint.x != prevPoint.x && currPoint.y + 1 != prevPoint.y) {
        Point a(currPoint.x, currPoint.y + 1);
        double aD = getDistance(a, target);
        if(currD>=aD){
            bool cond = getPathsToPoint(a,currPoint,target,paths,mode);
            if(cond){
                paths[mode + ctr] = paths[mode];
                paths[mode + ctr].push_back(a);
                ctr++;
            }
        }
    }

    if (currPoint.x - 1 != prevPoint.x && currPoint.y != prevPoint.y) {
        Point a(currPoint.x - 1, currPoint.y);
        double aD = getDistance(a, target);
        if(currD>=aD){
            bool cond = getPathsToPoint(a,currPoint,target,paths,mode);
            if(cond){
                paths[mode + ctr] = paths[mode];
                paths[mode + ctr].push_back(a);
                ctr++;
            }
        }
    }

    if (currPoint.x + 1 != prevPoint.x && currPoint.y != prevPoint.y) {
        Point a(currPoint.x + 1, currPoint.y - 1);
        double aD = getDistance(a, target);
        if(currD>=aD){
            bool cond = getPathsToPoint(a,currPoint,target,paths,mode);
            if(cond){
                paths[mode + ctr] = paths[mode];
                paths[mode + ctr].push_back(a);
                ctr++;
            }
        }
    }

    //failed to find a path
    paths.erase(paths.begin()+mode);
    return false;
}
bool getPathsToPoint(const Point &currPoint, const Point &target, std::vector<std::vector<Point>> &paths,
                     int mode){
    if(currPoint == target){
        paths[mode].push_back(currPoint);
        return true;
    }

    double currD = getDistance(currPoint, target);
    int ctr = 0;

    if (true) {
        Point a(currPoint.x, currPoint.y - 1);
        double aD = getDistance(a, target);
        if(currD>=aD){
            bool cond = getPathsToPoint(a,currPoint,target,paths,mode);
            if(cond){
                paths[mode + ctr] = paths[mode];
                paths[mode + ctr].push_back(a);
                ctr++;
            }
        }
    }

    if (true) {
        Point a(currPoint.x, currPoint.y + 1);
        double aD = getDistance(a, target);
        if(currD>=aD){
            bool cond = getPathsToPoint(a,currPoint,target,paths,mode);
            if(cond){
                paths[mode + ctr] = paths[mode];
                paths[mode + ctr].push_back(a);
                ctr++;
            }
        }
    }

    if (true) {
        Point a(currPoint.x - 1, currPoint.y);
        double aD = getDistance(a, target);
        if(currD>=aD){
            bool cond = getPathsToPoint(a,currPoint,target,paths,mode);
            if(cond){
                paths[mode + ctr] = paths[mode];
                paths[mode + ctr].push_back(a);
                ctr++;
            }
        }
    }

    if (true) {
        Point a(currPoint.x + 1, currPoint.y - 1);
        double aD = getDistance(a, target);
        if(currD>=aD){
            bool cond = getPathsToPoint(a,currPoint,target,paths,mode);
            if(cond){
                paths[mode + ctr] = paths[mode];
                paths[mode + ctr].push_back(a);
                ctr++;
            }
        }
    }

    //failed to find a path
    paths.erase(paths.begin()+mode);
    return false;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " grid-file\n";
        return 1;
    }
    ifstream istr(argv[1]);
    if (!istr) {
        cerr << "Could not open " << argv[1] << endl;
        return 1;
    }

    vector<vector<bool> > blocked_grid;
    int start_x, start_y;
    read_grid(istr, blocked_grid, start_x, start_y);
    print_grid(blocked_grid, start_x, start_y);

    // Start here with your code...
    std::vector<std::vector<Point>> pathList;
    bool a = getPathsToPoint(Point(start_x,start_y),Point(0,0),pathList,0);
    std::cout<<"a"<<std::endl;
    return 0;
}
      