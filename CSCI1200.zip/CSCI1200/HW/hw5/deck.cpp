// ==================================================================================
// Implement all functions that you listed by prototype in deck.h
// You may include additional helper functions as necessary
// All of your code must be in deck.h and deck.cpp
//
// NOTE: These are standalone functions, not part of a class.
// ==================================================================================

#include <iostream>
#include <cassert>
#include <cmath>
#include <random>
#include "playing_card.h"
#include "node.h"
#include "deck.h"

// ==================================================================================
//The Not-a-Destructor
void DeleteAllCards(Node *pNode) {
    if (pNode != nullptr) {
        while (pNode != nullptr) {
            Node *temp = pNode;
            pNode = pNode->after;
            delete temp;
        }
    }
}
bool ReversePrimaryOrder(Node *&head, Node *&pNode) {
    Node *temp0 = head, *temp1 = pNode;
    //brings to rear
    while (temp0->after != nullptr) {
        temp0 = temp0->after;
    }
    while (temp0->before != nullptr && temp1->after != nullptr) {
        temp0 = temp0->before;
        temp1 = temp1->after;
        if (temp0 != temp1) {
            return false;
        }
    }
    return true;
}
bool SamePrimaryOrder(Node *&head, Node *&pNode) {
    Node *temp0 = head, *temp1 = pNode;
    while (temp0->after != nullptr && nullptr != temp1->after) {
        temp0 = temp0->after;
        temp1 = temp1->after;
        if (temp0->getCard() != temp1->getCard()) {
            return false;
        }
    }
    return true;
}
void PrintDeckSorted(const std::string &key, Node *deck) {
    std::cout << key;
    Node *tmp = deck;
    while (tmp != nullptr) {
        std::cout << " " << tmp->getCard().getString();
        tmp = tmp->sorted_next;
    }
    std::cout << std::endl;
}
Node *CopyDeck(Node *pNode) {
    Node *out = new Node(pNode->getCard());
    while (pNode->after != nullptr) {
        Node *a = new Node(pNode->after->getCard());
        out->after = a;
        a->before = out;
        pNode = pNode->after;
        out = out->after;
    }
    //moves out back
    while (out->before != nullptr) {
        out = out->before;
    }
    return out;
}
void Deal(Node *&deck, Node *hands[], int numPlayers, const std::string &mode, int maxCardCt) {
    int length = 0;
    Node *ptr = deck;
    while (ptr != nullptr) {
        length++;
        ptr = ptr->after;
    }
    assert(maxCardCt*numPlayers <= length);
    if (mode == "one-at-a-time") {
        int i = 0;
        //inits first ptrs
        Node *data[numPlayers][maxCardCt];
        while (deck != nullptr && i / numPlayers < maxCardCt) {
            data[i % numPlayers][i / numPlayers] = deck;
            deck = deck->after;
            i++;
        }
        for (int j = 0; j < numPlayers; ++j) {
            int itr = 0;
            hands[j] = data[j][0];
            data[j][0]->before = nullptr;
            for (int k = 0; k < maxCardCt - 1; ++k) {
                data[j][k]->after = data[j][k + 1];
                data[j][k + 1]->before = data[j][k];
                itr++;
            }
            data[j][maxCardCt - 1]->after = nullptr;
        }
        if(deck == nullptr){return;}
        while(deck->before->after!= nullptr){
            deck = deck->before;
        }
        deck->before = nullptr;
    } else if (mode == "dou-dizhu" || mode == "斗地主") {
        bool cond = maxCardCt == 17 || maxCardCt == 25;
        bool cond2 = length == 108 || length == 54;
        if (!cond || !cond2) {
            std::cout << "Please change your decks";
            exit(1337);
        }
        int i = 0;
        //inits first ptrs
        Node *data[numPlayers][maxCardCt];
        while (deck != nullptr && i / numPlayers < maxCardCt) {
            data[i % numPlayers][i / numPlayers] = deck;
            deck = deck->after;
            i++;
        }
        for (int j = 0; j < numPlayers; ++j) {
            int itr = 0;
            hands[j] = data[j][0];
            data[j][0]->before = nullptr;
            for (int k = 0; k < maxCardCt - 1; ++k) {
                data[j][k]->after = data[j][k + 1];
                data[j][k + 1]->before = data[j][k];
                itr++;
            }
            data[j][maxCardCt - 1]->after = nullptr;
        }
        if(deck == nullptr){return;}
        while(deck->before->after!= nullptr){
            deck = deck->before;
        }
        //assumes hand[0] is the landlord
        deck->before = data[0][maxCardCt-1];
        data[0][maxCardCt-1]->after = deck;
    }
}
void CutDeck(Node *&deck, Node *&top, Node *&bot, const std::string &mode = "perfect") {
    //gets to the end of deck first dur to a lack of a back ptr and [] operators
    Node *rear = deck, *a = deck;
    int ct = 0;
    Node *fCheckp, *bCheckp;
    top = a;//they point to the same stuff. Deck is ded
    bot = rear;
    //gets length and pushes rear to back
    while (rear->after != nullptr) {
        rear = rear->after;
        ct++;
    }
    if (mode == "perfect") {
        while (true) {
            //driver code
            fCheckp = a;
            bCheckp = rear;
            a = a->after;
            rear = rear->before;

            bool cond1 = a == rear; //hopefully won't come to this
            bool cond2 = (a == bCheckp) && (rear == fCheckp);
            if (cond1) {
                //Placeholder, Way switch to bCheckp
                fCheckp = fCheckp->after;
                //splits the deck
                fCheckp->after = nullptr;
                bCheckp->before = nullptr;
                //drags bot to bCheckp
                bot = bCheckp;
                break;

            } else if (cond2) {
                //splits the deck
                fCheckp->after = nullptr;
                bCheckp->before = nullptr;
                //drags bot to bCheckp
                bot = bCheckp;
                break;
            }
        }
    } else if (mode == "random") {
        //The bigger the deck, the less likely you get a even distro
        int mod = std::floor(std::log(ct));
        //randomizer
        std::random_device rdev{};
        std::default_random_engine generator(rdev());
        std::uniform_int_distribution<int> distribution(-mod, mod);
        int rng = distribution(generator);
        //bias
        if (rng > 0) {
            for (int i = 0; i < rng; ++i) {
                a = a->after;
            }
        } else if (rng < 0) {
            for (int i = rng; i < 0; ++i) {
                rear = rear->before;
            }
        }
        while (true) {
            //driver code
            fCheckp = a;
            bCheckp = rear;
            a = a->after;
            rear = rear->before;

            bool cond1 = a == rear; //hopefully won't come to this
            bool cond2 = (a == bCheckp) && (rear == fCheckp);
            if (cond1) {
                //Placeholder, Way switch to bCheckp
                fCheckp = fCheckp->after;
                //splits the deck
                fCheckp->after = nullptr;
                bCheckp->before = nullptr;
                //drags bot to bCheckp
                bot = bCheckp;
                break;

            } else if (cond2) {
                //splits the deck
                fCheckp->after = nullptr;
                bCheckp->before = nullptr;
                //drags bot to bCheckp
                bot = bCheckp;
                break;
            }
        }
    }
    //destorys deck
    deck = nullptr;
}
Node *Shuffle(Node *&top, Node *&bot, const std::string &type = "perfect") {
    //tops
    Node *tDriver = top;
    Node *newD = top;//to jam cards in later
    //bots
    Node *bDriver = bot;
    Node *bTemp = bot;
    if (type == "perfect") {
        while (tDriver->after != nullptr || bDriver->after != nullptr) {//may be dangerous
            //drivers
            tDriver = tDriver->after;
            bDriver = bDriver->after;

            //reassignment
            newD->after = bTemp;
            bTemp->before = newD;

            if (tDriver == nullptr) {
                break;
            }

            tDriver->before = bTemp;
            bTemp->after = tDriver;

            //bDriver->before = tDriver;
            //onwards
            newD = tDriver;
            bTemp = bDriver;
        }
        //links the final nodes not covereed by the loop
        newD->after = bTemp;
        bTemp->before = newD;

    } else if (type == "random") {
        while (tDriver->after != nullptr || bDriver->after != nullptr) {//may be dangerous
            //randomizer
            std::random_device rdev{};
            std::default_random_engine generator(rdev());
            std::uniform_int_distribution<int> distribution(1, 3);
            int rng = distribution(generator);

            //drivers
            for (int i = 0; i < rng; ++i) {
                if(tDriver->after != nullptr){
                    tDriver = tDriver->after;
                } else{break;}

            }
            rng = distribution(generator);
            for (int i = 0; i < rng; ++i) {
                if(bDriver->after!= nullptr){
                    bDriver = bDriver->after;
                } else{break;}
            }

            //reassignment
            tDriver->before->after = bTemp;
            bTemp->before = tDriver->before;

            bDriver->before->after = tDriver;
            tDriver->before = bDriver->before;

            bDriver->before = nullptr;

            //onwards
            newD = tDriver;
            bTemp = bDriver;
        }
        //links the final nodes not covereed by the loop
        newD->after = bTemp;
        bTemp->before = newD;
    }
    return top;//still assigned to the beginning :)
}
/**
 * @brief: Seperate merging function cuz c++
 * @param a: List of sorted
 * @param b: Other list of sorted
 * @param start: first index
 * @param mid: midpoint
 * @param end: end index
 * @return
 */
void SHand1(Node *a[], Node *b[], int start, int mid, int end) {
    int al = start, i = start, ar = mid + 1;
    //
    while ((al <= mid) && (ar <= end)) {
        if (a[al]->getCard() < a[ar]->getCard()) {
            b[i] = a[al];
            al++;
        } else {
            b[i] = a[ar];
            ar++;
        }
        i++;
    }
    int ittr;
    //combines remaining pointers yet to be sorted
    if (al > mid) {
        for (ittr = ar; ittr <= end; ittr++) {
            b[i] = a[ittr];
            i++;
        }
    } else {
        for (ittr = al; ittr <= mid; ittr++) {
            b[i] = a[ittr];
            i++;
        }
    }
    for (ittr = start; ittr <= end; ittr++) { a[ittr] = b[ittr]; }
}
/**
 * @brief: Incredibly janky mergesort algo. %th rewrite after multiple crashes using pointer based logic.
 * This version uses array logic. At least its cleaner than a bubble sort(or so I'm told)
 * @param ptrs: array of pointers
 * @param b: temp array of pointers to store data
 * @param start: determines starting boundaries to sort
 * @param end: determines ending boundaries to sort
 */
void SHand0(Node *ptrs[], Node *b[], int start, int end) {
    if (start < end) {
        //split
        int mid = (start + end) / 2;
        //sort
        SHand0(ptrs, b, start, mid);
        SHand0(ptrs, b, mid + 1, end);
        //merge
        SHand1(ptrs, b, start, mid, end);
    } else {
        return;
    }
}
Node *SortHand(Node *hands) {
    Node *out = hands;//clones first ptr
    PlayingCard tempBig("hearts", 13);//temporary biggest card assigned for comparision. Hopefully

    int ct = 0;
    //length
    while (out != nullptr) {
        ct++;
        out = out->after;
    }
    //empty case
    if (ct == 0) {
        return hands;
    }
    out = hands;//sends out back to start
    //builds array for sorting
    Node *ptrArray[ct];
    int i = 0;
    while (out != nullptr) {
        ptrArray[i] = out;
        out = out->after;
        i++;
    }
    Node *b[ct];
    SHand0(ptrArray, b, 0, ct - 1);
    //connects the sorted pointers with each other
    for (int j = 0; j < ct - 1; ++j) {
        ptrArray[j]->sorted_next = ptrArray[j + 1];
        ptrArray[j + 1]->sorted_prev = ptrArray[j];
    }
    return ptrArray[0];
}
int DeckSize(Node *&head) {
    int ct = 0;
    Node *temp = head;
    while (temp != nullptr) {
        temp = temp->after;
        ct++;
    }
    return ct;
}
