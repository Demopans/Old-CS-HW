HOMEWORK 5: LINKED PLAYING CARDS


NAME:  Jeff


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

Alac

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  40



DESCRIPTION OF RANDOMNESS IMPLEMENTATION AND ANALYSIS OF RANDOMNESS
FOR EXTRA CREDIT:
Use of the newer c++11 random libaries that become apparent only with very large decks



MISC. COMMENTS TO GRADER:  
Optional, please be concise!


