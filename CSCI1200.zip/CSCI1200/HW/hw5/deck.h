#include "playing_card.h"
#include "node.h"

// ==================================================================================
// prototypes for provided functions (implemented in main.cpp)
// ==================================================================================

bool SanityCheckPrimary(Node* top);
bool SanityCheckSorted(Node* first);
Node* CreateDeck(int numCards);
void DeckPushBackCard(Node* &deck, const std::string& suit, int num);
void PrintDeckPrimary(const std::string &description, Node* deck);


// ==================================================================================
//
// Write all the prototypes for the your functions here
// (they will be implemented in deck.cpp)
//
// NOTE: These are standalone functions, not part of a class.
//
// You may include additional helper functions as necessary
// All of your code must be in deck.h and deck.cpp
//
// ==================================================================================
class deck{
};
//outer class functions
/**
 * @brief
 * @param head
 * @return
 */
int DeckSize(Node *&head);
bool SamePrimaryOrder(Node *&head, Node *&pNode);
bool ReversePrimaryOrder(Node *&head, Node *&pNode);

void DeleteAllCards(Node *pNode);
/**
 * @brief: deals a set amount of cards out.
 * @param deck: list of card Node
 * @param hands: array of players
 * @param numPlayers: size of array of players
 * @param mode: one-at-a-time,dou-dizhu/斗地主
 * @param maxCardCt: maximum amount of cards a player is allowed to have implemented for games such as blackjack
 */
void Deal(Node *&deck, Node **hands, int numPlayers, const std::string& mode, int maxCardCt);
/**
 * @brief Copys: deck to a new Node list
 * @param pNode: pointer to the first node in list
 * @return
 */
Node *CopyDeck(Node *pNode);
/**
 * @brief Same as PrintDeck, but uses the secondary pointer system
 * @param key
 * @param deck
 */
void PrintDeckSorted(const std::string &key, Node *deck);
/**
 * @brief: splits the deck in 2ish
 * @param deck: Input deck
 * @param top: first half
 * @param bot: second half
 * @param mode: set to perfect as default,
 */
void CutDeck(Node *&deck, Node *&top, Node *&bot, const std::string &mode);
/**
 * @brief: shuffles the ordering of the cards
 * @param top: first half
 * @param bot: second half
 * @param type: set to perfect as default,
 * @return: A new possibly randomized node ;)
 */
Node *Shuffle(Node *&top, Node *&bot, const std::string &type);
/**
 * @brief
 * @param hands: list of cards
 * @return
 */
Node *SortHand(Node *hands);