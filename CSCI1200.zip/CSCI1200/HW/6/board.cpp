
#include <iomanip>
#include <cstdlib>
#include <cmath>
#include <utility>

#include "board.h"

// ==================================================================
// ==================================================================
// Implementation of the Position class
std::string backWay(const std::string& a) {
    if(a == "north"){
        return "south";
    } else if (a=="east"){
        return "west";
    } else if (a=="south"){
        return "north";
    } else if (a=="west"){
        return "east";
    } else{
        return "";
    }
}

Position Position::voraus(const std::string& dir) {
    if(dir == "north"){
        return n();
    } else if (dir == "east"){
        return e();
    } else if (dir == "south"){
        return s();
    } else if (dir == "west"){
        return w();
    } else{
        return {row,col};
    }
}

// allows a position to be output to a stream
std::ostream &operator<<(std::ostream &ostr, const Position &p) {
    ostr << '(' << p.row << "," << p.col << ')';
    return ostr;
}

// equality and inequality comparision of positions
bool operator==(const Position &a, const Position &b) { return (a.row == b.row && a.col == b.col); }

bool operator!=(const Position &a, const Position &b) { return !(a == b); }

/**
 * @brief Contains a few elements required for optimized robot processes
 */

void Robot::runRadar(Board a) {
    radar.clear();
    //gets n data
    Position n = pos.n();
    if(a.inBounds(n)){
        //determine if empty
        char data = a.getspot(n);
        //finds if a wall is in the way
        bool wall = a.getHorizontalWall(pos.row-.5,pos.col);
        if(wall){
            radar.emplace_back(pos.n(),2);
        } else if(data==' '){
            radar.emplace_back(pos.n(),0);
        } else{
            radar.emplace_back(pos.n(),1);
        }
    } else{
        radar.emplace_back(pos.n(),-1);
    }
    //gets e data
    Position e = pos.e();
    if(a.inBounds(e)){
        //determine if empty
        char data = a.getspot(e);
        //finds if a wall is in the way
        bool wall = a.getVerticalWall(pos.row,pos.col+.5);
        if(wall){
            radar.emplace_back(pos.e(),2);
        } else if(data==' '){
            radar.emplace_back(pos.e(),0);
        } else{
            radar.emplace_back(pos.e(),1);
        }
    } else{
        radar.emplace_back(pos.e(),-1);
    }
    //gets s data
    Position s = pos.s();
    if(a.inBounds(s)){
        //determine if empty
        char data = a.getspot(s);
        //finds if a wall is in the way
        bool wall = a.getHorizontalWall(pos.row+.5,pos.col);
        if(wall){
            radar.emplace_back(pos.s(),2);
        } else if(data==' '){
            radar.emplace_back(pos.s(),0);
        } else{
            radar.emplace_back(pos.s(),1);
        }
    } else{
        radar.emplace_back(pos.s(),-1);
    }
    //gets w data
    Position w = pos.w();
    if(a.inBounds(w)){
        //determine if empty
        char data = a.getspot(w);
        //finds if a wall is in the way
        bool wall = a.getVerticalWall(pos.row,pos.col-.5);
        if(wall){
            radar.emplace_back(pos.w(),2);
        } else if(data==' '){
            radar.emplace_back(pos.w(),0);
        } else{
            radar.emplace_back(pos.w(),1);
        }
    } else{
        radar.emplace_back(pos.w(),-1);
    }
}

std::vector<std::string> Robot::findClearPath(Board a) {
    std::vector<std::string> out;
    for (int i = 0; i < 4; ++i) {
        //add clear spots into return data
        std::pair<Position, int> data = radar[i];
        if(data.second == 0){
            std::string direction = a.getDir(pos,data.first);
            out.push_back(direction);
        }
    }
    return out;
}

std::vector<int> Robot::blockingRobots(Board a) {
    std::vector<int> out;
    for (int i = 0; i < 4; ++i) {
        //add clear spots into return data
        std::pair<Position, int> data = radar[i];
        if(data.second == 1){
            char bot = a.getspot(data.first);
            if(bot != '?'){
                int robot = a.getRobotIndex(bot);
                out.push_back(robot);
            }
        }
    }
    return out;
}

int Robot::dirData(Board a, const std::string& dir) {
    Position next = pos.voraus(dir);
    if(!a.inBounds(next)){ return -1;}
    bool wall= false;
    if(dir == "north"){
        wall = a.getHorizontalWall(pos.row-.5,pos.col);
    } else if (dir == "east"){
        wall = a.getVerticalWall(pos.row,pos.col+.5);
    } else if (dir == "south"){
        wall = a.getHorizontalWall(pos.row+.5,pos.col);
    } else if (dir == "west"){
        wall = a.getVerticalWall(pos.row,pos.col-.5);
    }
    if(wall){
        return 3;
    }
    char data = a.getspot(next);
    if(data == ' '){return 0;} else if(data!='?'){ return 1;} else{ return 2;}
}




// ==================================================================
// ==================================================================
// Implementation of the Board class

// ===================
// CONSTRUCTOR
// ===================
Board::Board(int r, int c) {
    // initialize the dimensions
    rows = r;
    cols = c;

    // allocate space for the contents of each grid cell
    board = std::vector<std::vector<char> >(rows, std::vector<char>(cols, ' '));

    /*
     * allocate space for booleans indicating the presence of each wall
     * by default, these are false == no wall
     * (note that there must be an extra column of vertical walls
     * and an extra row of horizontal walls)
     */
    vertical_walls = std::vector<std::vector<bool> >(rows, std::vector<bool>(cols + 1, false));
    horizontal_walls = std::vector<std::vector<bool> >(rows + 1, std::vector<bool>(cols, false));

    // initialize the outermost edges of the grid to have walls
    for (int i = 0; i < rows; i++) {
        vertical_walls[i][0] = vertical_walls[i][cols] = true;
    }
    for (int i = 0; i < cols; i++) {
        horizontal_walls[0][i] = horizontal_walls[rows][i] = true;
    }
}

// ===================
// ACCESSORS related to board geometry
// ===================

// Query the existence of a horizontal wall
bool Board::getHorizontalWall(double r, int c) const {
    // verify that the requested wall is valid
    // the row coordinate must be a half unit
    assert (fabs((r - floor(r)) - 0.5) < 0.005);
    assert (r >= 0.4 && r <= rows + 0.6);
    assert (c >= 1 && c <= cols);
    // subtract one and round down because the corner is (0,0) not (1,1)
    return horizontal_walls[floor(r)][c - 1];
}

// Query the existence of a vertical wall
bool Board::getVerticalWall(int r, double c) const {
    // verify that the requested wall is valid
    // the column coordinate must be a half unit
    assert (fabs((c - floor(c)) - 0.5) < 0.005);
    assert (r >= 1 && r <= rows);
    assert (c >= 0.4 && c <= cols + 0.6);
    // subtract one and round down because the corner is (0,0) not (1,1)
    return vertical_walls[r - 1][floor(c)];
}


// ===================
// MODIFIERS related to board geometry
// ===================

// Add an interior horizontal wall
void Board::addHorizontalWall(double r, int c) {
    // verify that the requested wall is valid
    // the row coordinate must be a half unit
    assert (fabs((r - floor(r)) - 0.5) < 0.005);
    assert (r >= 0 && r <= rows);
    assert (c >= 1 && c <= cols);
    // verify that the wall does not already exist
    assert (horizontal_walls[floor(r)][c - 1] == false);
    // subtract one and round down because the corner is (0,0) not (1,1)
    horizontal_walls[floor(r)][c - 1] = true;
}

// Add an interior vertical wall
void Board::addVerticalWall(int r, double c) {
    // verify that the requested wall is valid
    // the column coordinate must be a half unit
    assert (fabs((c - floor(c)) - 0.5) < 0.005);
    assert (r >= 1 && r <= rows);
    assert (c >= 0 && c <= cols);
    // verify that the wall does not already exist
    assert (vertical_walls[r - 1][floor(c)] == false);
    // subtract one and round down because the corner is (0,0) not (1,1)
    vertical_walls[r - 1][floor(c)] = true;
}


// ===================
// PRIVATE HELPER FUNCTIONS related to board geometry
// ===================

char Board::getspot(const Position &p) const {
    // verify that the requested coordinate is valid
    assert (p.row >= 1 && p.row <= rows);
    assert (p.col >= 1 && p.col <= cols);
    // subtract one from each coordinate because the corner is (0,0) not (1,1)
    return board[p.row - 1][p.col - 1];
}


void Board::setspot(const Position &p, char a) {
    // verify that the requested coordinate is valid
    assert (p.row >= 1 && p.row <= rows);
    assert (p.col >= 1 && p.col <= cols);
    // subtract one from each coordinate because the corner is (0,0) not (1,1)
    board[p.row - 1][p.col - 1] = a;
}

char Board::isGoal(const Position &p) const {
    // verify that the requested coordinate is valid
    assert (p.row >= 1 && p.row <= rows);
    assert (p.col >= 1 && p.col <= cols);
    // loop over the goals, see if any match this spot
    for (Goal goal : goals) {
        if (p == goal.pos) { return goal.which; }
    }
    // else return space indicating that no goal is at this location
    return ' ';
}

bool Board::inBounds(const Position &p) {
    return (p.row >= 1 && p.row <= rows) && (p.col >= 1 && p.col <= cols);
}

// ===================
// MODIFIERS related to robots
// ===================

// for initial placement of a new robot
void Board::placeRobot(const Position &p, char a) {

    // check that input data is reasonable
    assert (p.row >= 1 && p.row <= rows);
    assert (p.col >= 1 && p.col <= cols);
    assert (getspot(p) == ' ');

    // robots must be represented by a capital letter
    assert (isalpha(a) && isupper(a));

    // make sure we don't already have a robot with the same name
    for (Robot & robot : robots) {
        assert (robot.which != a);
    }

    // add the robot and its position to the vector of robots
    robots.emplace_back(p, a);

    // mark the robot on the board
    setspot(p, a);
}

//Directly modifies the robot instead
void Board::moveRobot(int i, const std::string &direction) {
    //is a reference
    Robot *a = &robots[i];
    if (direction == "north") {
        //checks for boundaries;
        bool cond = !getHorizontalWall(a->pos.row - 0.5, a->pos.col);
        bool cond2 = 0 <= a->pos.row < rows;
        if (cond && cond2 && getspot(a->pos.n()) == ' ') {//with sanity gate
            setspot(a->pos, ' ');
            a->pos.row = a->pos.row - 1;
            setspot(a->pos, a->which);
            moveRobot(i, direction);
        } else {
            return;
        }
    } else if (direction == "east") {
        //checks for bounderies;
        bool cond = !getVerticalWall(a->pos.row, a->pos.col + 0.5);
        bool cond2 = 0 <= a->pos.col < cols;
        if (cond && cond2 && getspot(a->pos.e()) == ' ') {
            setspot(a->pos, ' ');
            a->pos.col = a->pos.col + 1;
            setspot(a->pos, a->which);
            return moveRobot(i, direction);
        } else {
            return;
        }
    } else if (direction == "south") {
        //checks for bounderies;
        bool cond = !getHorizontalWall(a->pos.row + 0.5, a->pos.col);
        bool cond2 = 0 <= a->pos.row <= rows;
        if (cond && cond2 && getspot(a->pos.s()) == ' ') {
            setspot(a->pos, ' ');
            a->pos.row = a->pos.row + 1;
            setspot(a->pos, a->which);
            return moveRobot(i, direction);
        } else {
            return;
        }
    } else if (direction == "west") {
        //checks for bounderies;
        bool cond = !getVerticalWall(a->pos.row, a->pos.col - 0.5);
        bool cond2 = 0 <= a->pos.col < cols;
        if (cond && cond2 && getspot(a->pos.w()) == ' ') {
            setspot(a->pos, ' ');
            a->pos.col = a->pos.col - 1;
            setspot(a->pos, a->which);
            moveRobot(i, direction);
        } else {
            return;
        }
    } else {
        return;
    }

    //prepares sensory data for further use
    a->runRadar(*this);
}


// ===================
// MODIFIER related to the puzzle goal
// ===================

void Board::addGoal(const std::string &gr, const Position &p) {

    // check that input data is reasonable
    assert (p.row >= 1 && p.row <= rows);
    assert (p.col >= 1 && p.col <= cols);

    char goal_robot;
    if (gr == "any") {
        goal_robot = '?';
    } else {
        assert (gr.size() == 1);
        goal_robot = gr[0];
        assert (isalpha(goal_robot) && isupper(goal_robot));
    }

    // verify that a robot of this name exists for this puzzle
    if (goal_robot != '?') {
        int robot_exists = false;
        for (int i = 0; i < robots.size(); i++) {
            if (getRobot(i) == goal_robot)
                robot_exists = true;
        }
        assert (robot_exists);
    }

    // make sure we don't already have a robot at that location
    assert (isGoal(p) == ' ');

    // add this goal label and position to the vector of goals
    goals.emplace_back(p, goal_robot);
}


// ==================================================================
// PRINT THE BOARD
// ==================================================================

void Board::print() {

    // print the column headings
    std::cout << " ";
    for (int j = 1; j <= cols; j++) {
        std::cout << std::setw(5) << j;
    }
    std::cout << "\n";

    // for each row
    for (int i = 0; i <= rows; i++) {

        // don't print row 0 (it doesnt exist, the first real row is row 1)
        if (i > 0) {

            // Note that each grid rows is printed as 3 rows of text, plus
            // the separator.  The first and third rows are blank except for
            // vertical walls.  The middle row has the row heading, the
            // robot positions, and the goals.  Robots are always uppercase,
            // goals are always lowercase (or '?' for any).
            std::string first = "  ";
            std::string middle;
            for (int j = 0; j <= cols; j++) {

                if (j > 0) {
                    // determine if a robot is current located in this cell
                    // and/or if this is the goal
                    Position p(i, j);
                    char c = getspot(p);
                    char g = isGoal(p);
                    if (g != '?') g = tolower(g);
                    first += "    ";
                    middle += " ";
                    middle += c;
                    middle += g;
                    middle += " ";
                }

                // the vertical walls
                if (getVerticalWall(i, j + 0.5)) {
                    first += "|";
                    middle += "|";
                } else {
                    first += " ";
                    middle += " ";
                }
            }

            // output the three rows
            std::cout << first << std::endl;
            std::cout << std::setw(2) << i << middle << std::endl;
            std::cout << first << std::endl;
        }

        // print the horizontal walls between rows
        std::cout << "  +";
        for (int j = 1; j <= cols; j++) {
            (getHorizontalWall(i + 0.5, j)) ? std::cout << "----" : std::cout << "    ";
            std::cout << "+";
        }
        std::cout << "\n";
    }
}

std::vector<std::vector<int>> Board::getReachHeader(int movedBot, int moves, int maxMoves) {
    std::vector<std::vector<int>> data(rows,std::vector<int>(cols,-1));
    //inits return data
    Position startPos = getRobotPosition(movedBot);
    data[startPos.row-1][startPos.col-1] = 0;

    //goes though every robot
    //initalizes the recursion
    for (int robot = 0; robot < robots.size(); robot++) {
        //inits necessary recursive storage for specific robot
        std::vector<Position> visited;
        visited.push_back(startPos);

        Robot cp = robots[robot];
        Robot *tracker = &robots[robot];
        tracker->runRadar(*this);//get surroundings

        //try every direction
        for (const std::string &j : dir) {
            int forwards = tracker->dirData(*this,j);
            if(forwards == 0){//case: no obstructions in dir
                moveRobot(robot, j);

                //debug
                print();

                getReach(movedBot, robot, data, moves + 1, maxMoves, j, visited);

                //resets pos after mega recursion
                setspot(tracker->pos,' ');
                tracker->pos = cp.pos;
                setspot(tracker->pos,getRobot(movedBot));
            } else if (forwards == 1){//case: obstructions in dir is a bot
                //get offending blocker
                Position a = tracker->pos.voraus(j);
                char b = getspot(a);
                assert(b != '?' && b != ' ');
                int c = getRobotIndex(b);
                //chackpoint
                Robot *cTracker = &robots[c];
                Robot cCP = robots[c];
                //get clear paths
                cTracker->runRadar(*this);
                std::vector<std::string> d = cTracker->findClearPath(*this);
                if(d.empty()){continue;}

                //move in the first possible path
                moveRobot(c,d[0]);
                moveRobot(robot, j);
                getReach(movedBot, robot, data, moves + 2, maxMoves, j, visited);

                //resets poses after mega recursion
                setspot(tracker->pos,' ');
                setspot(cTracker->pos,' ');
                tracker->pos = cp.pos;
                cTracker->pos = cCP.pos;
                setspot(tracker->pos,getRobot(movedBot));
                setspot(cTracker->pos,getRobot(c));
            }
        }
    }
    return data;
}
/**
 * @brief
 * @param movedBot
 * @param data
 * @param moves
 * @param maxMoves
 * @param start
 * @param direction north, south, east, west.
 * @param visitedPos
 */
void Board::getReach(int movedBot, int otherBot, std::vector<std::vector<int>> &data, int moves, int maxMoves,
                     const std::string &direction, std::vector<Position> &visitedPos) {
    Robot cp = robots[otherBot];
    Robot *tracker = &robots[otherBot];
    //terminating cases
    if(moves > maxMoves){return;}
    //checks if curr pos is visited
    for (Position i : visitedPos) {if(cp.pos == i){return;}}
    //adds curr pos
    visitedPos.push_back(cp.pos);

    //modifly spot data given a condition
    if(movedBot == otherBot){
        int *dt = &data[cp.pos.row-1][cp.pos.col-1];
        if(*dt==-1 || moves < *dt){*dt = moves;}
    }
    //run radar
    tracker->runRadar(*this);
    //parse sensory data
    std::vector<std::string> validDirections = tracker->findClearPath(*this);

    //moves various robots
    for (int robot = 0; robot < robots.size(); ++robot) {
        //keeps track with which bots are moved
         cp = robots[robot];
         tracker = &robots[robot];

        tracker->runRadar(*this);//get surroundings
        for (const std::string & j : dir) {
            //should not consider backtracking
            if(j==backWay(direction) && robot == otherBot){ continue;}

            //get directional data
            int forwards = tracker->dirData(*this,j);
            //parse directional data
            if(forwards == 0){//case: no obstructions in dir
                moveRobot(robot, j);

                //debug
                print();

                getReach(movedBot, robot, data, moves + 1, maxMoves, j, visitedPos);

                //resets pos after mega recursion
                setspot(tracker->pos,' ');
                tracker->pos = cp.pos;
                setspot(tracker->pos,getRobot(movedBot));
            } else if (forwards == 1){//case: obstructions in dir is a bot
                //get offending blocker
                Position a = tracker->pos.voraus(j);
                char b = getspot(a);
                assert(b != '?' && b != ' ');
                int c = getRobotIndex(b);
                //checkpoint
                Robot *cTracker = &robots[c];
                Robot cCP = robots[c];
                //get clear paths
                cTracker->runRadar(*this);
                std::vector<std::string> d = cTracker->findClearPath(*this);
                if(d.empty()){continue;}

                //move in the first possible path
                moveRobot(c,d[0]);
                moveRobot(robot, j);
                getReach(movedBot, robot, data, moves + 2, maxMoves, j, visitedPos);

                //resets poses after mega recursion
                setspot(tracker->pos,' ');
                setspot(cTracker->pos,' ');
                tracker->pos = cp.pos;
                cTracker->pos = cCP.pos;
                setspot(tracker->pos,getRobot(movedBot));
                setspot(cTracker->pos,getRobot(c));
            }
        }
    }
    //only updates correct robots

}

/**
 * @brief header function that starts the path lookup
 * @return
 */
std::vector<Path> Board::driveRobots(int &moves, const int &maxMoves) {
    std::vector<Path> weg;//id correspond to robot
    for (int i = 0; i < robots.size(); ++i) {
        //inits paths
        weg.emplace_back(Path(i));
    }
    //moves all robots
    driveRobotsEngine(weg,moves,maxMoves);
    return weg; //info to to audited by another function later
}
/**
 * @brief Engine handling all path searching
 * @param dirList List of paths to examine, with additional poses to examine
 * @param moves
 * @param maxMoves
 * @return
 */
bool Board::driveRobotsEngine(std::vector<Path> &dirList, int moves, const int &maxMoves) {
    //terminating cases
    if(moves > maxMoves){
        return false;
    }
    //moves a bunch of robots
    for (int i = 0; i < robots.size(); ++i) {
        for (int j = 0; j < dir.size(); ++j) {
            bool cond = true;
        }
    }
    return false;
}
/**
 * @brief drives a single robot on a adventure. Resulting data may need to be cleaned
 * @param start
 * @param robot
 * @param direction from which the bot traveled
 * @param trackPoses terminating positions
 * @return
 */
void
Board::driveRobot(int robot, const std::string &direction, std::vector<Position> &trackPoses, int moves, int maxMoves) {
    //terminating case
    if(moves > maxMoves){
        return;
    }

    Robot a = robots[robot];
    Robot *tracker = &robots[robot];

    if (direction == "north") {
        moveRobot(robot,direction);
        for (int i = 0; i < 4; ++i) {
            if (dir[i] != "south") {
                if(tracker->pos != a.pos){
                    trackPoses.push_back(tracker->pos);
                    driveRobot(robot, dir[i], trackPoses, moves+1, maxMoves);
                    *tracker = a;
                }
            }
        }
    } else if (direction == "east") {
        for (int i = 0; i < 4; ++i) {
            if (dir[i] != "west") {
                moveRobot(robot, dir[i]);
                if(tracker->pos != a.pos){
                    trackPoses.push_back(tracker->pos);
                    *tracker = a;
                }
            }
        }
    }else if (direction == "south") {
        for (int i = 0; i < 4; ++i) {
            if (dir[i] != "north") {
                moveRobot(robot, dir[i]);
                if(tracker->pos != a.pos){
                    trackPoses.push_back(tracker->pos);
                    *tracker = a;
                }
            }
        }
    }else if (direction == "west") {
        for (int i = 0; i < 4; ++i) {
            if (dir[i] != "east") {
                moveRobot(robot, dir[i]);
                if(tracker->pos != a.pos){
                    trackPoses.push_back(tracker->pos);
                    *tracker = a;
                }
            }
        }
    } else{
        for (int i = 0; i < 4; ++i) {
            moveRobot(robot, dir[i]);
            if(tracker->pos != a.pos){
                trackPoses.push_back(tracker->pos);
                *tracker = a;
            }
        }
    }
}
/**
 * @brief Determines direction after pos changes.
 * @param a
 * @param b
 * @return traveled direction
 */
std::string Board::getDir(Position a, Position b) {
    int colD = b.col - a.col;
    int rowD = b.row - a.row;
    if(colD > 0){
        return "east";
    } else if (colD < 0){
        return "west";
    }else if(rowD > 0){
        return "south";
    } else if (rowD < 0){
        return "north";
    } else{
        return "";
    }
}
// ==================================================================
// Solver functions
// ==================================================================
std::vector<std::vector<int>> Board::solveWrapper() {
    std::vector<std::vector<int>> gridData;

    return gridData;
}

bool Board::solveMover(int moves, int max) {
    return false;
}

void Path::addDir(const std::string& dir,Position pos) {path.emplace_back(std::tuple<std::string,Position>(dir,pos));}

int Path::getId() const {return id;}

const std::vector<std::tuple<std::string,Position>> &Path::getPath() const {return path;}



