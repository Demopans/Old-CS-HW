//
// Created by gaoje on 2/14/2020.
//

#ifndef PART2_KITCHEN_H
#define PART2_KITCHEN_H


#include <fstream>
#include <list>
#include "Recipe.h"
#include "item.h"

class Kitchen {

public:
    void addIngredient(const std::string& name,int units);
    void printIngredients(std::ostream &ostream);
    void runRecipe(const std::string &name, int units);
    void checkIngredient(const std::string &name, int units, std::list<std::string> &lis);
private:
    std::list<item> ingredients;//tuples promising as data storage std::list<std::tuple<std::string,int>>

};
//helper functions
int splitInger(const std::string& a);
bool sortCond(const item &a, const item &b);

#endif //PART2_KITCHEN_H
