
#include <iostream>
#include "item.h"

item::item(const std::basic_string<char> &name, int qt) : name(name), qt(qt) {}

const std::string &item::getName() const {
    return name;
}

void item::setName(const std::string &name) {
    item::name = name;
}

int item::getQt() const {
    return qt;
}

void item::setQt(int qt) {
    item::qt = qt;
}
