//
// Created by gaoje on 2/14/2020.
//

#include <sstream>
#include "Kitchen.h"


//helper functions
//wrapper for sort
//bool operator<(const std::string& a, const std::string& b){return sortCond(a, b);}
/**
 * @param a: ingredient a
 * @param b: ingredient b
 * @return True if a meets conditions as specified in pdf
 */
bool sortCond(const item &a, const item &b){
    std::string aName,bName;
    int aQ, bQ;
    aName = a.getName();aQ = a.getQt();
    bName = b.getName();bQ = b.getQt();
    if(aQ == bQ){
        return aName < bName;
    }
    return aQ<bQ;

}
/**
 * @brief: separate function that handles the glued ingredient string
 * @param a: the not-a-tuple
 * @return
 */
int splitInger(const std::string& a){
    std::string name0;
    //splits ingre
    for (int j = 0; j < a.length(); ++j) {
        if(isdigit(a[j])){ return j;}
    }
}

//class functions
void Kitchen::printIngredients(std::ostream &ostream) {
    ostream<<"In the kitchen:"<<std::endl;
    ingredients.sort(sortCond);
    for (std::list<item>::iterator i = ingredients.begin(); i != ingredients.end(); i++) {
        item data = *i;//easier to work with
        std::string name0;int quant;
        name0 = data.getName();
        quant = data.getQt();
        if (quant > 1) {
            ostream << "  " << quant << " units of " << name0 << std::endl;
        } else {
            ostream << "  " << quant << " unit of " << name0 << std::endl;
        }
    }

}
/**
 * @param name: ingredient name
 * @param units
 */
void Kitchen::addIngredient(const std::string& name, int units) {
    bool flag = false;
    for (std::list<item>::iterator i = ingredients.begin(); i != ingredients.end(); ++i) {
        item data = *i;//easier to work with
        std::string name0;int quant;
        name0 = data.getName();
        quant = data.getQt();
        //found ing
        if(name0 == name){
            flag = true;
            *i = item(name0,units+quant);
        }
    }
    if(!flag){
        ingredients.push_back(item(name,units));
    }

}

/**
 * @param name:
 * @param units: to subtract
 * @param lis: reference to missing ingredients(if there is any)
 * @return codes: true - Managed to subtract qualities and deleted inger if 0
 *                false - failed to do the above
 */
void Kitchen::checkIngredient(const std::string &name, int units, std::list<std::string> &lis) {
    //searches for ing
    for (std::list<item>::iterator i = ingredients.begin(); i != ingredients.end(); i++) {
        item data = *i;//easier to work with
        std::string name0 = data.getName();

        //ing found
        if(name0 == name){
            int quant = data.getQt();
            //checks for adequate units
            if(units > quant){
                std::string a = name0;
                a+=std::to_string(units-quant);
                lis.push_back(a);
            }
            //ingredient found and checked
            return;
        }
    }
    //ingredient not found
    lis.push_back(name+std::to_string(units));
}

/**
 * @brief called only after recipe has been verified
 * @param name:
 * @param units:
 */
void Kitchen::runRecipe(const std::string &name, int units) {
    for (std::list<item>::iterator i = ingredients.begin(),pI = ingredients.begin(); i != ingredients.end(); i++) {
        item data = *i;//easier to work with
        std::string name0 = data.getName();
        //ing found
        if (name0 == name) {
            int quant = data.getQt();
            int newQuant = quant - units;
            if(newQuant == 0){
                ingredients.erase(i);
                i = pI;
                continue;
            } else{
                *i = item(name ,newQuant);
                //sets prev i in case of multiple deletes.
                //Lists apparently are unable to safely handle multiple deletes :P
                pI = i;
            }
        }
    }
}