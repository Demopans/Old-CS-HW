//
// Created by gaoje on 2/19/2020.
//

#ifndef PART2_ITEM_H
#define PART2_ITEM_H


#include <string>

class item {
private:
    std::string name;
    int qt;
public:
    const std::string &getName() const;

    void setName(const std::string &name);

    int getQt() const;

    void setQt(int qt);

    item(const std::string &name, int qt);
};


#endif //PART2_ITEM_H
