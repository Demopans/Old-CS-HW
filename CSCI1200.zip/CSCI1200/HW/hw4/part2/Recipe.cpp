//
// Created by gaoje on 2/14/2020.
//

#include "Recipe.h"
/**
 * @param ingName: ingredient name
 * @param quant: quantity
 */
void Recipe::addIngredient(std::string ingName, int quant) {
    std::string intMod = ingName;intMod += std::to_string(quant);
    ingredients.push_back(item(ingName,quant));
}


