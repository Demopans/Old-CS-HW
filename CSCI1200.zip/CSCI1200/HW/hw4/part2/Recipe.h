//
// Created by gaoje on 2/14/2020.
//

#ifndef PART2_RECIPE_H
#define PART2_RECIPE_H


#include <string>
#include <list>
#include "item.h"

class Recipe {
public:
    Recipe(const std::string& name):name(name){};

    void addIngredient(std::string ingName, int quant);
    const std::list<item> getIngredients() const { return ingredients;}
    const std::string &getName() const{return name;}

private:
    std::string name;
    std::list<item> ingredients;
};


#endif //PART2_RECIPE_H
