HOMEWORK 8: ROPES


NAME:  Jeff Gao


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

alac

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  10

BALANCED/WORST CASE RUNNIG TIME ANALYSIS:
n = characters in the string of the current Rope (*this)
a = Nodes in Rope
i = length of string in a specfic node
m = characters in the string of the Rope passed in (for functions that take
    a second rope)
v = longest "value" of a leaf
p = longest path from root to a leaf
Using these variables, state and explain the big-O running time of each 
of the following operations two ways: 1) with a balanced Rope, 2) with an 
extremely unbalanced Rope. Explain what you considered an extremely 
unbalanced rope for the string "Hello my name is Simon".

For current considerations, there is no difference between a std::list and an incredubably unbalanced Rope. 
All operations with a Not-A-List can be considered to take between o(a) and O(an) time

Copy Constructor: Default case O(an) in order to copy every single element

Construct from Node*: O(1) for every case, as it simply links the root to the Node

Index: Best Case, O(log2(a)i) running time, Worst case O(ai) running time

Report: O(log2(a)i) running time for each individual i

iterator operator++: O(1) to O(log2(n)) due to the large decision tree 

Split: O(log2(a)^2) for cases that don't split a Node, O((log2(a)^2)i) for cases that do. The function also adjusts the new weights of the Nodes in order to compensate for such destruction

Concat: O(an) as it copies the Rope to be glued first. 


TESTING & DEBUGGING STRATEGY: 
Briefly describe the tests in your StudentTests() function.
How did you test the "corner cases" of your implementation?
All corner cases are descrided in StudentTests() seperated by header comments


MISC. COMMENTS TO GRADER:  
(optional, please be concise!)

