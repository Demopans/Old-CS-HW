/*
Write your Rope implementation in this file. 
You do not have to keep any of the code that is already in this file.
Functions that are required that you have not implemented have an assert 0
meaning they will always crash. This should help you make sure you implement
everything.
*/

#include <cassert>
#include <sstream>
#include "Rope.h"
#include <list>

/**
 * @brief Node stuff
 */

bool Node::operator==(const Node &a) { return weight == a.weight && value == a.value; }

/**
 * @brief traverses p to as left as possible
 */
void lTraverse(Node *&p) {while (p->left != nullptr) {p = p->left;}}

bool Rope::sanity(int i) const{
    return 0<=i<size_;
}

/**
 * @brief helper function
 * @param iter
 */
void iterHelper(Node *&pt) {
    //query existence of parent and roots
    bool cond0 = pt->parent == nullptr, cond1 = pt->left == nullptr, cond2 = pt->right == nullptr;
    bool rootCheck = pt->parent== nullptr && pt->left != nullptr;
    if(rootCheck){pt = nullptr;return;}
    //right child exists
    if(!cond2){pt = pt->right;lTraverse(pt);return;}
    else {//no right children, checks for parent
        if (!cond0) {//parent exists, check for other conditions
            //check data of parent
            Node *pp = pt->parent;
            //verify which child
            bool lpc = pp->left == pt, rpc = pp->right == pt;
            if (lpc) {
                pt = pp;
                //tries going right
                cond0 = pt->right !=nullptr;
                if(cond0){
                    pt = pt->right;
                    while (pt->left!=nullptr){pt = pt->left;}
                }
                return;
            }//is left child,
            if (rpc) {//is right child
                //loop until enter a Node from the left or hit the root
                //would like a small goto here though
                while (pp->parent != nullptr) {
                    pt = pp;
                    pp = pp->parent;
                    lpc = pp->left == pt, rpc = pp->right == pt;
                    if (lpc) {
                        //check if right of pp exist
                        if (pp->right == nullptr) {pt = pp;return;}
                        //exists, directly points pt to right of pp
                        pt = pp->right;
                        //to the far left
                        lTraverse(pt);
                        return;
                    }
                }
                //somehow got to the root
                pt = nullptr;return;
            }
        } else{
            //check if alone
            if(cond1){pt = nullptr;return;}
        }
    }
}
void addLeavesToQueue(Node *n,std::list<Node*> &queue){
    //add underlying nodes to queue
    if(n->right != nullptr){
        if(is_leaf(n->right)){queue.push_back(n->right);}
        addLeavesToQueue(n->right,queue);
    }
    if(n->left != nullptr){
        if(is_leaf(n->left)){queue.push_back(n->left);}
        addLeavesToQueue(n->left,queue);
    }

}
void fixWeights(Node *n){
    //add underlying nodes to queue
    std::list<Node*> leaves,parents;
    addLeavesToQueue(n,leaves);
    //work from the leaves and go up
    for (Node *leaf : leaves) {
        leaf->weight = leaf->value.size();
        //add first layer of parents
        Node *p = leaf->parent;
        if(p!=nullptr && *parents.rbegin() != p){
            parents.push_back(p);
        }
    }
    for (Node *parent : parents) {
        if(parent->left != nullptr){
            parent->weight=parent->left->weight;
            if(parent->left->right!= nullptr){
                parent->weight+=parent->left->right->weight;
            }
        }
        //adds more parents
        Node *p = parent->parent;
        if(p!=nullptr && *parents.rbegin() != p){
            parents.push_back(p);
        }
    }
}

//Should advance to the next Node using in-order traversal
//It can point at any Node, not just leaves
rope_iterator &rope_iterator::operator++() {
    iterHelper(this->ptr_);//wrapped
    return *this;
    //assert(0 && "rope_iterator operator++ not implemented!");
}

//Point to the first Node for in-order traversal
rope_iterator Rope::begin() const {
    Node *a = this->root;
    while (a->left != nullptr) { a = a->left; }
    return a;
    //assert(0 && "rope_iterator begin() not implemented!");
}

rope_iterator Rope::rbegin() const {
    Node *a = this->root;
    if(a->left== nullptr){ return nullptr;}
    a = a->left;
    while (a->right != nullptr) { a = a->right; }
    return a;
    //assert(0 && "rope_iterator begin() not implemented!");
}

Rope::Rope() {this->root = nullptr;this->size_ = 0;}

//Should make the root = p and adjust any member variables
//This should not make a copy of the rope with root at p,
//it should just "steal" the Node*
int findSize(Node *n){
    int i = 0;
    while(n!= nullptr){
        i+=n->weight;
        n = n->right;
    }
    return i;
}
Rope::Rope(Node *p) {
    //p must be a root
    if(p->parent!= nullptr){
        //attempt to clear p
        try {
            destory(p);
        }catch(std::errc e){}

        *this = Rope();
    }//defaults to blank
    this->root = p;
    this->size_ = findSize(p);
    //assert(0 && "Rope constructor from Node not implemented!");
}

void Rope::destory(Node *p) {
    if(p == nullptr){ return;}
    if (p->left != nullptr) { destory(p->left); }
    if (p->right != nullptr) { destory(p->right); }
    delete p;
}

Rope::~Rope() {destory(this->root);}

void cHelper(Node *p, Node *r) {
    if (is_leaf(r)) { return; }

    if (r->left != nullptr) {
        Node *a = new Node;
        a->value = r->left->value;
        a->weight = r->left->weight;

        //linker
        a->parent = p;
        p->left = a;

        cHelper(p->left, r->left);
    }
    if (r->right != nullptr) {
        Node *a = new Node;
        a->value = r->right->value;
        a->weight = r->right->weight;

        //linker
        a->parent = p;
        p->right = a;

        cHelper(p->right, r->right);
    }
    p->value = r->value;
    p->weight = r->weight;
}

Rope::Rope(const Rope &r) {
    Node *n = new Node, *rr = r.root;
    cHelper(n, rr);
    this->root = n;
    this->size_ = r.size_;
}

Rope &Rope::operator=(const Rope &r) {
    //checks for self assignment
    Node *a = this->root, *b = r.root;
    if (a == b) { return *this; }//equal mem address
    //clears current
    destory(root);
    //constructs new

    Node *n = new Node, *rr = r.root;
    cHelper(n, rr);

    this->root = n;
    this->size_ = r.size_;
    return *this;
    //assert(0 && "Rope assignment not implemented!");
}

//MUST BE ITERATIVE
//Get a single character at index i
bool Rope::index(int i, char &c) const{
    //sanity checks
    if(!sanity(i)){ c = 0;return false;}
    //traverse the tree
    Node *a = this->root;
    if(i>=size_){ c = 0;return false;}
    while (!is_leaf(a)) {
        int w = a->weight;
        //decides which path
        if (i >= w) {
            i = i - w;
            a = a->right;
            if (a == nullptr) { return false; }
        } else {
            a = a->left;
        }
    }
    //succeeds
    c = a->value[i];
    return true;
    //assert(0 && "Rope index() not implemented!");
}

//Add the other rope (r)'s string to the end of my string
void Rope::concat(const Rope &r) {
    Node *rr = new Node, *nn = r.root;//copies nodes directly
    cHelper(rr, nn);

    //check if root of base has a free slot and is empty
    if(this->root->right == nullptr && this->root->value.empty()){
        this->root->right = rr;
        Node *tr = rr;
        while (tr!= nullptr){
            this->size_ +=tr->weight;
            tr = tr->right;
        }
    } else{//creates a new root
        //reserves new root
        Node *n = new Node;
        n->left = this->root;
        this->root->parent = n;
        n->right = rr;
        rr->parent = n;
        //adds root weights
        n->weight = this->root->left->weight;
        if(this->root->right!= nullptr){
            n->weight += this->root->right->weight;
        }

        this->root = n;
        Node *tr = rr;
        while (tr!= nullptr){
            this->size_ +=tr->weight;
            tr = tr->right;
        }
    }

    //assert(0 && "Rope concat() not implemented!");
}
/**
 * @brief same function as Rope::concat, but with nodes
 * @param a
 * @return
 */
Node *glue(Node *l,Node *r){
    //check for equality
    if(l == r){ return l;}
    if(l->right == nullptr && l->value.empty()){
        l->right = r;
    } else{//creates a new root
        //reserves new root
        Node *n = new Node;
        n->left = l;l->parent = n;
        n->right = r;r->parent = n;

        l = n;
    }
    return l;
}
//Get a substring from index i to index j.
//Includes both the characters at index i and at index j.
//String can be one character if i and j match
//Returns true if a string was returned, and false otherwise
//Function should be written with efficient running time.
bool Rope::report(int I, int J, std::string &s) {
    //clears s
    s.clear();
    //sanity checks
    if(!sanity(I)){ return false;}
    if(!sanity(J)){ return false;}

    for (int k = I; k <= J; ++k) {
        int i = k;
        //custom traverser
        Node *a = this->root;
        while (!is_leaf(a)) {
            int w = a->weight;
            //decides which path
            if (i >= w) {
                i = i - w;
                a = a->right;
            } else {
                a = a->left;
            }
        }
        //succeeds
        std::string ss = a->value;
        //from reasonable start to reasonable end of ss
        for (int j = i; j < ss.size() && k <= J; ++j, k++) {
            s += ss[j];
        }
        k--;
    }
    return !s.empty();
}

Node* glueNodes(const std::list<Node *>& n){
    Node *a = *n.begin();
    for (Node *b : n) {
        a = glue(a,b);
    }
    return a;
}
/**
 * @brief returns 2 roots
 * @param n Node to disconnect along with other Nodes
 * @return
 */
std::pair<Node*,Node*> Rope::cleaveTree(Node* n){
    std::list<Node*> s;//store Node*s in order to eventually glue
    Node* a = n->parent;
    //disconnect nodes
    while (a->parent!= nullptr){
        if(a->right != nullptr){
            a->right = nullptr;
            n->parent = nullptr;
            //to queue
            s.push_back(n);
            //break if a enters from the right
            if(a->parent->right != nullptr && a->parent->right == a){ break;}
            a = a->parent;
            n = a->right;
        }
    }
    //glues together s
    Node *r = glueNodes(s);
    return {this->root,r};
}
/**
 * @brief returns 2 roots
 * @param n Node to disconnect along with other Nodes
 * @param i index to split the string
 * @return
 */
//std::pair<Node*,Node*> cleaveTree(Node* n,int i){}

//The first i characters should stay in the current rope, while a new
//Rope (rhs) should contain the remaining size_-i characters.
//A valid split should always result in two ropes of non-zero length.
//If the split would not be valid, this rope should not be changed,
//and the rhs rope should be an empty rope.
//The return value should be this rope (the "left") part of the string
//This function should move the nodes to the rhs instead of making new copies.
Rope &Rope::split(int i, Rope &rhs) {
    if (!sanity(i)) {return *this;}//invalid cases
    rhs.size_ = this->size_ - i;
    this->size_ = i;
    //begin the splitering

    //find splitting char to audit against
    int I = i;
    //traverse the tree
    Node *aa = this->root;
    while (!is_leaf(aa)) {
        int w = aa->weight;
        //decides which path
        if (I >= w) {I = I - w;aa = aa->right;}
        else {aa = aa->left;}

        //splits the tree without splitting a node
        if (I == 0){
            std::pair<Node*,Node*> data = cleaveTree(aa);

            //assign node to tree
            this->root = data.first;
            rhs.root = data.second;
            //determine size
            rhs.size_ = findSize(rhs.root);
            this->size_ -= rhs.size_;

            fixWeights(this->root);
            fixWeights(rhs.root);

            //determine size
            rhs.size_ = findSize(rhs.root);
            this->size_ = findSize(this->root);

            //returns lhs
            return *this;
        }
    }
    //split the Node string
    std::string val = aa->value;
    std::string rVal,lVal;
    for (int j = 0; j < val.size(); ++j) {
        if(j<=I){rVal+=val[j];} else{lVal+=val[j];}
    }
    Node *bb = new Node;
    bb->value = rVal;aa->value = lVal;//aa goes to the splitted Rope
    //split the tree
    std::pair<Node*,Node*> data = cleaveTree(aa);
    //assign node to tree
    this->root = data.first;
    rhs.root = data.second;
    //glue missing node
    this->root = glue(this->root,bb);

    fixWeights(this->root);
    fixWeights(rhs.root);

    //determine size
    rhs.size_ = findSize(rhs.root);
    this->size_ = findSize(this->root);

    //returns lhs
    return *this;
}
