//
// Created by gaoje on 1/25/2020.
//

#include "event.h"
#include <iostream>

event::event(const std::vector<TestSubject> &participants):participants(participants) {}

const std::vector<TestSubject> &event::getParticipants() const {return participants;}

void event::setParticipants(const std::vector<TestSubject> &participants) {this->participants = participants;}

void event::addParticipants(const TestSubject& a) {this->participants.push_back(a);}

event::~event() = default;
