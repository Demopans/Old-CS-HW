//
// Created by gaoje on 4/20/2020.
//

#include <iostream>
#include <fstream>
#include <cmath>
#include <sstream>
#include "TestSubject.h"
#include "event.h"
#include <iomanip>
#include <algorithm>
#include <iterator>


double timeCov(const std::string &a);

std::vector<TestSubject> compress(const std::vector<event> &a);

TestSubject scoreCalc(const TestSubject &a);

void printStuff(const TestSubject &testData, std::ofstream &file);

void printStuffHandler(std::vector<TestSubject> &scores, std::vector<TestSubject> &points, std::ofstream &file,
                       const std::string &mode);

std::vector<std::string> split(const std::string &a, const char &b = ' ');

std::vector<event> parseFile(std::ifstream &file);

int main(int argl, char *args[]) {
    //Input checking
    if (argl != 4) { exit(1); }

    std::ifstream input(args[1]);
    if (!input.good()) {
        std::cerr << "Can't open " << args[1] << " to read.\n";
        exit(1);
    }

    std::ofstream output;
    output.open(args[2]);
    if (!output.good()) {
        std::cerr << "Can't open " << args[2] << " to write\n";
        exit(1);
    }

    std::string mode = args[3];

    std::string line;
    // Gets names and inits TestSubjects
    std::vector<event> events = parseFile(input);//<poleVault,javelin,1500,shot,highJump,400,110,discus>

    //converts events
    std::vector<TestSubject> testSubjects = compress(events);
    //calculates the scores
    std::vector<TestSubject> scoreTable;
    for (int i = 0; i < testSubjects.size(); i++) {
        scoreTable.push_back(scoreCalc(testSubjects[i]));
    }

    printStuffHandler(scoreTable, testSubjects, output, mode);

    return 0;
}

void printStuff(const TestSubject &testData, std::ofstream &file) {
    const std::vector<double>& data = testData.getScore();
    file << std::left;
    file << std::setw(6) << data[8] << std::setw(6) << data[9] << std::setw(6)
         << data[3] << std::setw(6) << data[4] << std::setw(6) << data[5]
         << std::setw(6) << data[6] << std::setw(6) << data[7] << std::setw(6)
         << data[0] << std::setw(6) << data[1] << std::setw(6) << data[2]
         << std::setw(6) << testData.getTotalScore();

}

//based on totalScore
bool tSComp(const TestSubject &a, const TestSubject &b) {
    return a.getTotalScore() > b.getTotalScore();
}

//based on the alphabet
bool aLComp(const TestSubject &a, const TestSubject &b) {
    if (a.getNation() > b.getNation()) {
        return true;
    } else return a.getLName() > b.getLName();
}

void printStuffHandler(std::vector<TestSubject> &scores, std::vector<TestSubject> &points, std::ofstream &file,
                       const std::string &mode) {
    file << std::left;
    file << std::setw(30) << "DECATHLETE POINTS" << std::setw(6) << "100" << std::setw(6) << "LJ" << std::setw(6)
         << "SP" << std::setw(6) << "HJ" << std::setw(6) << "400" << std::setw(6) << "110H" << std::setw(6) << "DT"
         << std::setw(6) << "PV" << std::setw(6) << "JT" << std::setw(6) << "1500" << std::setw(6);

    if (mode == "points") {
        file << "TOTAL\n";
        std::sort(scores.begin(), scores.end(), tSComp);
        for (int i = 0; i < scores.size(); i++) {
            file << std::setw(10) << scores[i].getFName() << std::setw(14) << scores[i].getLName() << std::setw(7)
                 << scores[i].getNation();
            printStuff(scores[i], file);
            file << std::endl;
        }
    } else if (mode == "scores") {
        std::sort(scores.begin(), scores.end(), aLComp);
        for (int i = 0; i < scores.size(); i++) {
            file << std::setw(10) << points[i].getFName() << std::setw(14) << points[i].getLName() << std::setw(7)
                 << points[i].getNation();
            printStuff(points[i], file);
            file << std::endl;
        }
    } else if (mode == "custom") {
        //A thing here
    } else {
        file << "Invalid Mode";
    }
}
