//
// Created by gaoje on 1/24/2020.
//

#ifndef DSHW2_TESTSUBJECT_H
#define DSHW2_TESTSUBJECT_H

#include <iostream>
#include <vector>
#include <map>

class TestSubject {
public:
    TestSubject(const std::string &fName, const std::string &lName, const std::string &nation) :fName(fName), lName(lName), nation(nation) {}
    
    const std::string &getFName() { return fName; }
    const std::string &getLName() { return lName; }
    const std::string &getNation() { return nation; }
    const std::map<std::string, double> getScore() {return std::map<std::string, double>();}
    double getTotalScore()  {return this->totalScore;}

    void setFName(const std::string &fName) { this->fName = fName; }
    void setLName(const std::string &lName) { this->lName = lName; }
    void setNation(const std::string &nation) { this->nation = nation; }
    void setScore(const std::map<std::string, double> &score) {TestSubject::score = score;}


    std::string print();

    void calcTotal();


    void appendScore(std::string key, double value);



private:
    std::string fName;
    std::string lName;
    std::string nation;
    double totalScore = 0;
    std::map<std::string, double> score;


};


#endif //DSHW2_TESTSUBJECT_H
