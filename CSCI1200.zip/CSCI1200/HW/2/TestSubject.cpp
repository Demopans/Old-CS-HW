//
// Created by gaoje on 1/24/2020.
//

#include "TestSubject.h"
#include <cmath>

std::string TestSubject::print() {
    return this->fName + " " + this->lName + " " + this->nation;
}

void TestSubject::calcTotal() {
    for (int i = 0; i < score.size(); ++i) {
        this->totalScore+=this->score[i];
    }
}

void TestSubject::appendScore(std::string key, double value) {
    this->score.insert(std::pair<std::string,double>(key,value));
}








