//
// Created by gaoje on 1/25/2020.
//

#ifndef DSHW2_EVENT_H
#define DSHW2_EVENT_H


#include <vector>
#include <iostream>
#include "TestSubject.h"

class event {
private:
    std::vector<TestSubject> participants;
public:
    explicit event(const std::vector<TestSubject> &participants = {});
    const std::vector<TestSubject> &getParticipants() const;
    void setParticipants(const std::vector<TestSubject> &participants);
    void addParticipants(const TestSubject& a);

    virtual ~event();
};


#endif //DSHW2_EVENT_H
