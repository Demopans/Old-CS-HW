//
// Created by gaoje on 1/29/2020.
// Non-void functions placed here to reduce scrolling
//

#include <iostream>
#include <cmath>
#include "TestSubject.h"
#include "event.h"
#include <iomanip>
#include <fstream>
#include <sstream>


//converts all valid strings into doubles, also time format
//if a is empty, returns a 0
double timeCov(const std::string &a) {
    bool flag = true;
    int index = -1;
    //finds the :
    for (int i = 0; i < a.length() && flag; i++) {
        if (a.substr(i, i) == ":") {
            flag = false;
            index = i;
        }
    }
    if (!a.empty()) {
        int b = 0;
        double c = std::stod(a.substr(index + 1, a.length()));
        if (a.substr(0, index).length() != 0 && index != -1) {
            b = std::stoi(a.substr(0, index)) * 60;
        }
        return b + c;
    } else {
        return 0;
    }
}

std::vector<TestSubject> compress(const std::vector<event> &a) {
    std::vector<TestSubject> testSubjects;
    std::vector<TestSubject> init = a[0].getParticipants();
    //inits testSubjects
    for (int j = 0; j < init.size(); ++j) {
        testSubjects.push_back(init[j]);
    }

    for (int i = 1; i < a.size(); i++) {
        //extracts TestSubject
        std::vector<TestSubject> testSub = a[i].getParticipants();
        //
        for (int k = 0; k < init.size(); ++k) {
            for (int j = 0; j < testSub.size(); j++) {
                if (testSub[j].print() == testSubjects[k].print()) {
                    testSubjects[k].setScore(testSub[j].getScore()[0]);
                    testSub.erase(testSub.begin() + j);//wtf
                }
            }
        }
    }
    return testSubjects;
}

TestSubject scoreCalc(TestSubject &a) {
    TestSubject finalScoring(a.getFName(), a.getLName(), a.getNation());
    // modifiers in input order
    double aMod[10] = {0.2797, 10.14, 0.03768, 51.39, 0.8465, 1.53775, 5.74352, 12.91, 25.4347, 0.14354};
    double bMod[10] = {100, 7, 480, 1.5, 75, 82, 28.5, 4, 18, 220};
    double cMod[10] = {1.35, 1.08, 1.85, 1.05, 1.42, 1.81, 1.92, 1.1, 1.81, 1.4};
    bool isTrack[10] = {false, false, true, false, false, true, true, false, true, false};
    std::vector<double> inputData = a.getScore();
    //because different unit confusions require copy pasting editing
    /*
    //POLE_VAULT
    int score = aMod[0] * pow((inputData[0] * 100 - bMod[0]), cMod[0]);
    finalScoring.setScore(score);
    //JAVELIN_THROW
    score = aMod[1] * pow((inputData[1] - bMod[1]), cMod[1]);
    finalScoring.setScore(score);
    //1500_METERS
    score = aMod[2] * pow((bMod[2] - inputData[2]), cMod[2]);
    finalScoring.setScore(score);
    //SHOT_PUT
    score = aMod[3] * pow((inputData[3] - bMod[3]), cMod[3]);
    finalScoring.setScore(score);
    //HIGH_JUMP
    score = aMod[4] * pow((inputData[4] * 100 - bMod[4]), cMod[4]);
    finalScoring.setScore(score);
    //400_METERS
    score = aMod[5] * pow((bMod[5] - inputData[5]), cMod[5]);
    finalScoring.setScore(score);
    //110_METERS_HURDLES
    score = aMod[6] * pow((bMod[6] - inputData[6]), cMod[6]);
    finalScoring.setScore(score);
    //DISCUS_THROW
    score = aMod[7] * pow((inputData[7] - bMod[7]), cMod[7]);
    finalScoring.setScore(score);
    //100_METERS
    score = aMod[8] * pow((bMod[8] - inputData[8]), cMod[8]);
    finalScoring.setScore(score);
    //LONG_JUMP
    score = aMod[9] * pow((inputData[9] * 100 - bMod[9]), cMod[9]);
    finalScoring.setScore(score);
    */
    finalScoring.calcTotal();

    return finalScoring;
}

std::vector<std::string> split(const std::string &a, const char &b = ' ') {
    std::vector<std::string> output;
    int init = 0;
    for (int i = 0; i < a.length(); ++i) {
        if (a[i] == b or i == a.length() - 1) {
            output.push_back(a.substr(init, i));
            init = i + 1;
        }
    }
    return output;
}

void eraseNulls(std::vector<event> &a);

std::vector<event> parseFile(std::ifstream &file) {
    std::string str;
    std::vector<event> events;
    event index;

    //ensures events are sorted correctly
    bool flag0 = false;
    std::string eventType;
    //for debugging
    int ittr = 1;
    while (std::getline(file, str)) {
        std::stringstream strSS(str);
        std::string fName, lName, nation, score;
        strSS >> fName >> lName >> nation >> score;
        if(fName.empty()){
            if(flag0){
                events.push_back(index);
                //clears index
                index.setParticipants(std::vector<TestSubject>());
                flag0 = false;
            }
            continue;
        } else if (fName == "event"){
            flag0 = true;
            eventType = lName;
            continue;
        } else if(flag0){
            TestSubject person(fName,lName,nation);
            double scr = timeCov(score);
            person.appendScore(eventType,scr);
            index.addParticipants(person);
        }
        ittr++;
    }
    eraseNulls(events);
    return events;
}

//removes junk information
void eraseNulls(std::vector<event> &a){
    for (int i = 0; i < a.size(); ++i) {
        if(a[i].getParticipants().empty()){
            a.erase(a.begin()+i);
        }
    }
}