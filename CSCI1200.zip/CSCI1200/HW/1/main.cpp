#include <iostream>
#include <fstream>
#include <cmath>

std::string isoscelesTriangle(const std::string &input, int length);

std::string rightTriangle(const std::string &input, int length);

std::string square(const std::string &input, int length);

std::string leftTriangle(const std::string &input, int length);

std::string ePernus(const std::string &input, int length);

std::string maxArc(const std::string &input, int length);

std::string squircle(const std::string &input, int length);

std::string generateShape(const std::string &input, const std::string &type, int length);

std::string circle(const std::string &input, int length);

int main(int argc, char *argv[]) {

    std::string fileName = argv[4]; //filename
    //std::cout << fileName;
    std::fstream f;
    f.open(fileName);
    std::ifstream in_str(argv[3]);


    std::string chars = argv[1];
    int length = std::stoi(argv[2]);
    std::string shape = argv[3];

    // checks if file can be opened
    /*if (in_str.good()) {
        std::cerr << ": Can't open " << fileName << " to read.\n";
        exit(1);
    }*/

    std::string fin = generateShape(chars, shape, length);
    std::ofstream out_str(fin);
    f << fin;
    f.close();
    std::cout << fin;

    return 0;
}

std::string generateShape(const std::string &input, const std::string &type, int length) {
    std::string output;
    if (type == "square") {
        output = square(input, length);
    } else if (type == "right_triangle") {
        output = rightTriangle(input, length);
    } else if (type == "isosceles_triangle") {
        output = isoscelesTriangle(input, length);
    } else if (type == "left_triangle") {
        output = leftTriangle(input, length);
    } else if (type == "e_pernus") {
        output = ePernus(input, length);
    } else if (type == "min_arc") {
        output = maxArc(input, length);
    } else if (type == "squircle") {
        output = squircle(input, length);
    } else if (type == "circle"){
        output = circle(input, length);
    } else {
        output = "Invalid input";
    }
    return output;
}

std::string square(const std::string &input, int length) {
    /*
     * const std::string& input: pattern of letters
     * int length: side length of square
     * */
    std::string shape(length, '*');
    shape += "\n";
    std::string a = shape;
    int inputLen = input.length();
    int ct = 0;
    for (int i = 0; i < length - 2; i++) {
        shape += "*";
        for (int j = 0; j < length - 2; j++) {
            shape += input[ct % inputLen];
            ct++;
        }
        shape += "*\n";
    }
    shape += a;
    return shape;
}

std::string rightTriangle(const std::string &input, int length) {
    std::string shape = "*\n**\n";
    int inputLen = input.length();
    int ct = 0;
    int ittr = 0;
    for (int i = 0; i < length - 3; i++) {
        shape += "*";
        for (int j = 0; j < ittr + 1; j++) {
            shape += input[ct % inputLen];
            ct++;
        }
        ittr++;
        shape += "*\n";
    }
    //constant adjusts bottom
    std::string end(ittr + 3, '*');
    shape += end;
    return shape;
}

std::string isoscelesTriangle(const std::string &input, int length) {
    std::string shape(length - 1, ' ');
    shape += "*\n";
    int inputLen = input.length();
    int ct = 0;

    int spIttr = length - 2;
    int stIttr = 0;

    for (int i = 0; i < length - 2; i++) {
        shape += std::string(spIttr, ' ');
        shape += "*";
        for (int j = 0; j < stIttr + 1; j++) {
            shape += input[ct % inputLen];
            ct++;
        }
        spIttr--;
        stIttr += 2;
        shape += "*\n";
    }
    //constant adjusts bottom
    std::string end(stIttr + 3, '*');
    shape += end;
    return shape;
}

std::string leftTriangle(const std::string &input, int length) {
    std::string shape(length - 1, ' ');
    shape += "*\n";
    int inputLen = input.length();
    int ct = 0;

    int spIttr = length - 2;
    int stIttr = 0;

    for (int i = 0; i < length - 3; i++) {
        shape += std::string(spIttr, ' ');
        shape += "*";
        for (int j = 0; j < stIttr + 1; j++) {
            shape += input[ct % inputLen];
            ct++;
        }
        spIttr--;
        stIttr++;
        shape += "*\n";
    }
    //constant adjusts bottom
    std::string end(stIttr + 3, '*');
    shape += end;
    return shape;
}

std::string ePernus(const std::string &input, int length) {
    return "No";// I shall never draw you a ePernus
}

int calcSpacing(int ittr, int max) {
    int out = (int) (std::pow((std::pow(max, 2) - (std::pow(ittr, 2))), 0.5));
    return out;
}

std::string maxArc(const std::string &input, int length) {
    std::string shape = "*\n";

    int inputLen = input.length();
    int ct = 0;

    int limit = calcSpacing(1, length);
    for (int i = 0; i < length - 2; i++) {
        shape += "*";
        for (int j = 0; j < limit - 2; j++) {
            shape += input[ct % inputLen];
            ct++;
        }
        shape += "*\n";
        limit = calcSpacing(i + 1, length);
    }
    shape += std::string(limit + 2, '*');

    return shape;
}

int squricleBuffer(int ittr, int max) {
    int con = 4;
    int out = std::floor(std::pow((std::pow(max, con) - (std::pow(ittr, con))), 1.0 / con));
    return out;
}

std::string squircle(const std::string &input, int length) {
    std::string shape;


    int inputLen = input.length();
    int ct = 0;

    int hLen = length / 2;
    //top half
    int ittr = hLen;
    int spacing = squricleBuffer(ittr, hLen);
    for (int i = 0; i < hLen; i++) {
        shape += std::string(hLen - spacing - 1, ' ');
        shape += "*";
        int limit = spacing;
        for (int j = 0; j < limit * 2; j++) {
            shape += input[ct % inputLen];
            ct++;
        }
        shape += "*\n";
        ittr--;
        spacing = squricleBuffer(ittr, hLen);
    }
    ittr = 1;
    spacing = squricleBuffer(ittr, hLen);
    for (int i = 0; i < hLen; i++) {
        shape += std::string(hLen - spacing - 1, ' ');
        shape += "*";
        int limit = spacing;
        for (int j = 0; j < limit * 2; j++) {
            shape += input[ct % inputLen];
            ct++;
        }
        shape += "*\n";
        ittr++;
        spacing = squricleBuffer(ittr, hLen);
    }
    return shape;
}

int circleBuffer(int ittr, int max) {
    int con = 2;
    int out = std::floor(std::pow((std::pow(max, con) - (std::pow(ittr, con))), 1.0 / con));
    return out;
}

std::string circle(const std::string &input, int length) {
    std::string shape;


    int inputLen = input.length();
    int ct = 0;

    int hLen = length / 2;
    //top half
    int ittr = hLen;
    int spacing = circleBuffer(ittr, hLen);
    for (int i = 0; i < hLen; i++) {
        shape += std::string(hLen - spacing - 1, ' ');
        shape += "*";
        int limit = spacing;
        for (int j = 0; j < limit * 2; j++) {
            shape += input[ct % inputLen];
            ct++;
        }
        shape += "*\n";
        ittr--;
        spacing = circleBuffer(ittr, hLen);
    }
    ittr = 1;
    spacing = circleBuffer(ittr, hLen);
    for (int i = 0; i < hLen; i++) {
        shape += std::string(hLen - spacing - 1, ' ');
        shape += "*";
        int limit = spacing;
        for (int j = 0; j < limit * 2; j++) {
            shape += input[ct % inputLen];
            ct++;
        }
        shape += "*\n";
        ittr++;
        spacing = circleBuffer(ittr, hLen);
    }
    return shape;
}
