//
// Created by gaoje on 2/7/2020.
//

#include "Board.h"
#include <iostream>
#include <utility>

// code that increases array size by 2x+1 so I don't have to write it else where.
// Accounts for cases where sMax = 0. Will keep this function for future use
void growSArray(int *&sPtr, int &sLen, int &sMax) {
    /**
     *  @param sPtr: reference to a pointer array to modify
     *  @param sLen: length of said pointer array
     *  @param sMax: Maximum slots said pointer array can hold
     */
    int *newPtr;
    //assumes array size of 0
    sMax = 2 * sMax + 1;
    newPtr = new int[sMax];
    for (int i = 0; i < sMax; ++i) {
        if (i < sLen) {
            newPtr[i] = sPtr[i];
        }
    }
    sLen++;
    delete[] sPtr;//will expand later
    sPtr = newPtr;
}

Board::Board(std::string p1K, std::string p2K, std::string blanks) :
        p1K(std::move(p1K)), p2K(std::move(p2K)), blanks(std::move(blanks)) {
    /**
    *   @param p1K: Player1 Token
     *  @param p2K: Player2 Token
     *  @param blanks: Blank Token
    */
    //builds the board, I think, Will check over
    row = new int *[rowLen];
    for (int i = 0; i < rowLen; i++) {
        //column
        row[i] = new int[colLen]();
        //for (int j = 0; j < colLen; ++j) {row[i][j] = 0;}
        colMax = colLen;
    }
}

int Board::numTokensInRow(const int &rowI) {
    /**
     * @param &rowI: index position of row
     * Counts non blanks
     */
    if (rowI >= colLen) {
        return -1;
    }
    int ct = 0;
    for (int i = 0; i < rowLen; ++i) {
        int data = row[i][rowI];
        if (data != 0) {
            ct++;
        }
    }
    return ct;
}

int Board::numTokensInColumn(const int &colI) {
    /**
     * @param &colI: index position of column
     * Counts non blanks
     */
    if (colI >= rowLen) {
        return -1;
    }
    int ct = 0;
    for (int i = 0; i < colLen; ++i) {
        if (row[colI][i] != 0) {
            ct++;
        }
    }
    return ct;
}

std::string Board::insert(const int &col, const bool &player) {
/**
 * @param col: column
 * @param player: True: player1, False: player2
 * inserts token in a column, affected by gravity.
 */

    //rowLen check
    if (col >= rowLen) {
        if (col >= rowMax) {
            //adds columns
            //std::cout<<rowLen<<std::endl;
            growSArray(*row, rowLen, rowMax);
            //std::cout<<rowLen<<std::endl;
        } else {
            //activates new column
            rowLen++;
        }
        //inits new spaces
        row[rowLen - 1] = new int[colMax];
        //std::cout << rowLen <<std::endl;
        for (int j = 0; j < colLen; ++j) {
            row[rowLen - 1][j] = 0;
        }

    }
    //increases column length once limit is reached
    int index0 = colLen;
    for (int i = 0; i < colLen; ++i) {
        int data = row[col][i];
        if (data == 0) {
            index0 = i;
            break;
        }
    }
    if (index0 == colLen) {
        if (colLen == colMax) {
            for (int i = 0; i < rowMax; ++i) {
                //since growSArray modifies references
                int a = colLen;
                int b = colMax;
                growSArray(row[i], a, b);
                colMax = 2 * colMax + 1;
            }
            for (int i = 0; i < rowLen; ++i) {
                row[i][colLen] = 0;
            }
        }
        colLen++;
    }

    //insert de l'token
    if (player) {
        row[col][index0] = 1;
    } else {
        row[col][index0] = 2;
    }
    int code = check4();
    if (code == 0) {
        return blanks;
    } else if (code == 1) {
        return p1K;
    } else if (code == 2) {
        return p2K;
    }
    return blanks;
}

// Various debug functions
int Board::numRows() { return colLen; }

int Board::getColLen() { return Board::numRows(); }

int Board::numColumns() { return rowLen; }

int Board::getRowLen() { return Board::numColumns(); }

std::string Board::buildBoard() {
    /**
     * builds the board from int keys
     */
    std::string initBuild;
    for (int j = colLen - 1; j >= 0; --j) {
        for (int i = 0; i < rowLen; i++) {
            int key = row[i][j];
            if (key == 1) {
                initBuild += p1K;
            } else if (key == 2) {
                initBuild += p2K;
            } else {
                initBuild += blanks;//may be bad taste, but will remain until I can get a graphical memory viewer

            }
            if (i != rowLen - 1) {
                initBuild += " ";
            }
        }
        initBuild += "\n";
    }
    return initBuild;
}

//for debugging
int **Board::getRow() const { return row; }

int Board::check4() {
    /**
     * return codes:
     *  0: blank wins
     *  1: player1 wins
     *  2: player2 wins
     */
    //horzontal checking
    int a = 0;
    int b = 0;
    for (int i = 0; i < colLen; ++i) {
        int tCt = numTokensInRow(i);
        if (tCt >= 4) {
            for (int j = 0; j < rowLen; ++j) {
                int data = row[i][j];
                if (data == 1) {
                    a++;
                    b = 0;
                } else if (data == 2) {
                    b++;
                    a = 0;
                } else {
                    a = 0;
                    b = 0;
                }
                if (a == 4 || b == 4) {
                    if (a == 4) {
                        return 1;
                    } else {
                        return 2;
                    }
                }
            }
        }
    }

    //vertical checking
    a = 0;
    b = 0;
    for (int i = 0; i < rowLen; ++i) {
        int tCt = numTokensInColumn(i);
        if (tCt >= 4) {
            for (int j = 0; j < colLen; ++j) {
                int data = row[i][j];
                if (data == 1) {
                    a++;
                    b = 0;
                } else if (data == 2) {
                    b++;
                    a = 0;
                } else {
                    a = 0;
                    b = 0;
                }
                if (a == 4 || b == 4) {
                    if (a == 4) {
                        return 1;
                    } else {
                        return 2;
                    }
                }
            }
        }
    }

    return 0;
}

void Board::clear() {
    //clears rows
    for (int i = 0; i < rowMax; ++i) {
        delete[] row[i];
    }
    delete[] row;
    //builds new rows
    row = new int *[rowLen];
    for (int i = 0; i < rowLen; i++) {
        //column
        row[i] = new int[colLen];
        for (int j = 0; j < colLen; ++j) {
            row[i][j] = 0;
        }
        colMax = colLen;
    }
}

std::string Board::debugRow() {
    /**
     * builds the board from int keys but with try catch
     */
    std::string initBuild;
    for (int j = colLen - 1; j >= 0; --j) {
        for (int i = 0; i < rowLen; i++) {
            int key;
            try {
                key = row[i][j];
            } catch (int err) {
                key = 666;
            }
            if (key == 1) {
                initBuild += "1";
            } else if (key == 2) {
                initBuild += "2";
            } else if (key == 666) {
                initBuild += "N";
            } else {
                initBuild += "0";//may be bad taste, but will remain until I can get a graphical memory viewer
            }
        }
        initBuild += "\n";
    }
    return initBuild;
}

//Magic duct tape
std::ostream &operator<<(std::ostream &os, Board &b) {
    std::string board = b.buildBoard();
    os << board;
    return os;
}
