//
// Created by gaoje on 2/7/2020.
//

#ifndef HW3_BOARD_H
#define HW3_BOARD_H

#include <iostream>
#include <vector>
#include <tuple>

class Board{
public:
    //constructor
    Board(std::string p1K, std::string p2K, std::string blanks);

    //primary functions
    int numTokensInRow(const int &rowI);
    int numTokensInColumn(const int &colI);
    std::string insert (const int &col, const bool &player);
    void clear();
    int numRows();int getColLen();//does same thing but for debug
    int numColumns();int getRowLen();//does same thing but for debug
    std::string buildBoard();
    int **getRow() const;
    int check4();

    //clion debug functions
    std::string debugRow();

    ~Board(){for (int i = 0; i < rowMax; ++i) {delete[] row[i];}delete[] row;}

private:
    //primary data
    std::string p1K;
    std::string p2K;
    std::string blanks;
    int **row;
    int rowLen = 4;
    int rowMax = 4;
    int colLen = 5;
    int colMax;
    // Done to abstract the board data in order to work around pointer limitations. Also saves on ram usage, as not everyone has 8GB of ram
    // Placed here as reference
    std::tuple<std::string,int> slotData[3] = {
            {blanks,0},//or all other nums until I get a fix on a memory function
            {p1K,1},
            {p2K,2}
    };
};
//mem function placed here
void growSArray(int *&sPtr, int &sLen, int &sMax);
std::ostream& operator<<(std::ostream& os, Board &b);
#endif //HW3_BOARD_H
