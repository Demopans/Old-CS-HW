HOMEWORK 3: CONNECT FOUR


NAME:  Jeff Gao


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

Google, StackOverflow, People from my Eve Online corp

Remember: Your implementation for this assignment must be done on your
own, as described in the "Academic Integrity for Homework" handout.


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  Many Moons



ORDER NOTATION:
For each of the functions below, write the order notation O().
Write each answer in terms of m = the number of rows and n = the
number of columns.  You should assume that calling new [] or delete []
on an array will take time proportional to the number of elements in
the array.

insert (excluding checking for connected four):
    O(nm) worst case

insert (including checking for connected four):
    O(nm) worst case

numTokensInColumn:O(n)

numTokensInRow:O(m)

numColumns:O(1)

numRows:O(1)

print: O(mn)

clear:


TESTING & DEBUGGING STRATEGY:
Clion without the integrated Valgrind for logic checking.
Valgrind via a Ubuntu virtual machine.


MISC. COMMENTS TO GRADER:
.-.
