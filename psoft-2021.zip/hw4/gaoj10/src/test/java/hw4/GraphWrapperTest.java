package hw4;

import org.junit.Test;
import java.util.*;

import static org.junit.Assert.*;

//submitty doesn't have this testing library
//import org.junit.jupiter.api.Test;
//import static org.junit.jupiter.api.Assertions.*;

public class GraphWrapperTest {
    // build
    Graph<String, String,Integer> ug1 = new Graph<>();
    Graph<String, String,Integer> ug2 = new Graph<>();
    Graph<String, String,Integer> dg1 = new Graph<>(true);
    Graph<String, String,Integer> dg2 = new Graph<>(true);

    @Test
    public void getNodes() {//tests addNode() as well
        // the basics
        ug1.addNode("1");
        ug1.addNode("2");
        assertEquals(ug1.getNodes(),new HashSet<>(Arrays.asList("1", "2")));
        //duplicate
        ug1.addNode("1");
        ug1.addNode("2");
        assertEquals(ug1.getNodes(),new HashSet<>(Arrays.asList("1", "2")));
        //copy constructor test
        Graph<String, String,Integer> tmp = new Graph<>(ug1);
        assertEquals(tmp,ug1);
        //null tests
        try{
            ug1.addNode(null);
        }catch (Exception e){
            System.out.println(e);
        }
        //self referencing
        ug1 = new Graph<>(ug1);
        assertEquals(ug1.getNodes(),new HashSet<>(Arrays.asList("1", "2")));
    }

    @Test
    public void query() {
        ug2.addNode("1");
        ug2.addNode("2");
        ug2.addEdge("1","2","",0);
        System.out.println(Arrays.toString(ug2.query("1").toArray()));
        System.out.println(Arrays.toString(ug2.query("2").toArray()));
        ug2.addNode("3");
        ug2.addNode("4");
        ug2.addNode("5");
        ug2.addNode("6");
        ug2.addEdge("2","3","",0);
        ug2.addEdge("4","3","",0);
        ug2.addEdge("4","5","",0);
        System.out.println(Arrays.toString(ug2.query("3").toArray()));
        System.out.println(Arrays.toString(ug2.query("4").toArray()));
        System.out.println(Arrays.toString(ug2.query("5").toArray()));
        System.out.println(Arrays.toString(ug2.query("6").toArray()));
        assertEquals(ug2.query("a").size(),0);
    }

    @Test
    public void addEdge() {
        ug2.addNode("3");
        ug2.addNode("4");
        ug2.addEdge("4","3","",0);
        //invalid
        try{
            ug2.addEdge("3","4","",0);
            System.out.println(Arrays.toString(ug2.query("3").toArray()));
        }catch (Exception e){
            System.out.println(e);
        }
    }

    Graph<String, String,Integer> ug3 = null;
    @Test
    public void largeCon(){
        HashMap<String, HashSet<Triple<String, String, Integer>>> tmp = new HashMap<>();
        for (String o : ug1.getNodes()) {
            HashSet<Triple<String, String, Integer>> t = ug1.query(o);
            tmp.put(o,t);
        }
        ug3 = new Graph<>(tmp,false,false,false);
        assertEquals(ug3,ug1);
    }

    @Test
    public void errorCases(){
        // expect exceptions
        ug3 = new Graph<>();
        try{
            ug3.addNode(null);
        }catch (Exception e){
            System.out.println(e);
        }
        try{
            ug3.addEdge(null,null,null,null);
        }catch (Exception e){
            System.out.println(e);
        }
        try{
            new Graph<>(null,true,true,false);
        }catch (Exception e){
            System.out.println(e);
        }
        try{
            ug3.query(null);
        }catch (Exception e){
            System.out.println(e);
        }
        try{
            ug3.addEdge("null","a","",9);
        }catch (Exception e){
            System.out.println(e);
        }
    }

    @Test
    public void overrides(){
        System.out.println(dg1);
        System.out.println(dg1.hashCode());
        assertNotEquals(dg1, new HashSet<String>());

    }

    //test wrapper functions
    GraphWrapper gw1 = new GraphWrapper();
    @Test
    public void listNodesW() {
        gw1.addNode("1");
        gw1.addNode("2");
        gw1.addNode("3");
        for (Iterator<String> it = gw1.listNodes(); it.hasNext(); ) {
            String node = it.next();
            System.out.println(node);
        }
    }

    @Test
    public void listChildrenW() {
        gw1.addNode("1");
        gw1.addNode("2");
        gw1.addNode("3");
        gw1.addEdge("1","2","0");
        gw1.addEdge("1","1","2");
        gw1.addEdge("1","3","0");
        gw1.addEdge("1","3","5");
        for (Iterator<String> it = gw1.listChildren("1"); it.hasNext(); ) {
            String node = it.next();
            System.out.println(node);
        }
    }
    //implementation is barebones.
}