package hw5;

// import org.junit.jupiter.api.Test; // submitty hates jupiter for some reason
import org.junit.*;
import java.io.*;
import static org.junit.Assert.*;

import java.io.IOException;


class Helper{
    static String modDir(){
        String a = System.getProperty("user.dir");
        return a.substring(0,a.length()-8)+"\\data\\marvel.csv";
    }
}
public class MarvelPathsTest{
    MarvelPaths g = new MarvelPaths(Helper.modDir());

    @Test
    public void bothInGraphSameNode() {
        assertEquals(g.findPath("PETERS, SHANA TOC","PETERS, SHANA TOC"),"path from PETERS, SHANA TOC to PETERS, SHANA TOC:\n");
    }

    @Test
    public void oneNotInGraph() {
        assertEquals(g.findPath("PETERS, SHANA TOC","THELEGEND27"),"unknown character THELEGEND27\n");
    }

    @Test
    public void bothNotInGraph() {
        assertEquals(g.findPath("ACADEMICINTEGRETYCUTLER","THELEGEND27"),
                "unknown character ACADEMICINTEGRETYCUTLER\n unknown character THELEGEND27\n");
    }

    @Test
    public void bothNotInGraphSameNode() {
        assertEquals(g.findPath("THELEGEND27","THELEGEND27"),
                "unknown character THELEGEND27\nunknown character THELEGEND27\n");
    }

    @Test
    public void example1() {
        assertEquals(g.findPath("PETERS, SHANA TOC","KNIGHT, MISTY"),
                "path from PETERS, SHANA TOC to KNIGHT, MISTY:\n PETERS, SHANA TOC to KNIGHT, MISTY via M/CP 80/3 ");
    }

    @Test
    public void example2() {
        assertEquals(g.findPath("PETERS, SHANA TOC","SEERESS"),
                "path from PETERS, SHANA TOC to SEERESS:\nPETERS, SHANA TOC to KNIGHT, MISTY via M/CP 80/3\nKNIGHT, MISTY to ALEXANDER, CALEB via N 17\n ALEXANDER, CALEB to HULK/DR. ROBERT BRUC via N@ 1/3\n HULK/DR. ROBERT BRUC to RAVAGE/PROF. GEOFFRE via RH2 2\n RAVAGE/PROF. GEOFFRE to SEERESS via M/CP 117/4\n ");
    }


}