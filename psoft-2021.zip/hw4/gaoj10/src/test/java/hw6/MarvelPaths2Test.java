package hw6;
import org.junit.*;// why must there be 2 different testing frameworks?
import java.util.*;
import static org.junit.Assert.*;
/**
 * Helper class for testing in Intellij. Eclipse appears to use a different file structure. Why? idk
 */
class Helper{
    static String modDir(){
        String a = System.getProperty("user.dir");
        return a.substring(0,a.length()-8)+"\\data\\marvel.csv";
    }
}
public class MarvelPaths2Test {
    MarvelPaths2 g = new MarvelPaths2();
    @Before
    public void prepare() { g.createNewGraph(Helper.modDir()); }

    @Test
    public void path1(){
        assertEquals("path from PETERS, SHANA TOC to PETERS, SHANA TOC:\n" +
                "total cost: 0.000\n",g.findPath("PETERS, SHANA TOC","PETERS, SHANA TOC"));
    }

    @Test
    public void path2(){
        assertEquals("unknown character MONA\n" +
                "unknown character LUMINE\n",g.findPath("MONA","LUMINE"));
    }
    @Test
    public void provided(){
        assertEquals("path from PETERS, SHANA TOC to SEERESS:\n" +
                "PETERS, SHANA TOC to KNIGHT, MISTY with weight 1.000\n" +
                "KNIGHT, MISTY to CAGE, LUKE/CARL LUCA with weight 0.017\n" +
                "CAGE, LUKE/CARL LUCA to HULK/DR. ROBERT BRUC with weight 0.032\n" +
                "HULK/DR. ROBERT BRUC to RAVAGE/PROF. GEOFFRE with weight 0.500\n" +
                "RAVAGE/PROF. GEOFFRE to SEERESS with weight 1.000\n" +
                "total cost: 2.549\n",g.findPath("PETERS, SHANA TOC","SEERESS"));
    }
}