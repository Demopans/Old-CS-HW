package hw7;

import hw4.Graph;
import hw4.GraphAlgo;
import hw4.Path;

import java.util.*;

/** viewer, translates between CampusPaths and Graph **/
class CampusAccess implements CampusInterface {
    /** placeholder **/
    private static volatile CampusInterface instance;
    private CampusAccess(){
        if (instance!=null) throw new RuntimeException("Use getInstance() method to get the single instance of this class.");

        instance = this;
        g = new Graph<>(new HashMap<>(),true,false,false);
        IDLookup = new HashMap<>();
        instance = this;
        nameLookup = new HashMap<>();
    }
    /** Fields **/
    private static Graph<Integer,String,Float> g;//id, labelType, distance
    private static HashMap<Integer, ArrayList<String>> IDLookup;
    private static HashMap<String,Integer> nameLookup;
    /** methods **/
    static CampusInterface getInstance(){
        if (instance==null) instance = new CampusAccess();
        return CampusAccess.instance;
    }

    /**
     *
     * @param building a non null string that is the id of the building
     * @param info a non null array formatted as the following: [name, x, y]
     */
    @Override
    public void addBuilding(Integer building, ArrayList<String> info){
        if (info.get(0).equals("")){// intersections have no names
            CampusAccess.g.addNode(building);
            CampusAccess.IDLookup.putIfAbsent(building,info);
            CampusAccess.nameLookup.putIfAbsent("Intersection "+building,building);
        }else {
            CampusAccess.g.addNode(building);
            CampusAccess.IDLookup.putIfAbsent(building,info);
            CampusAccess.nameLookup.putIfAbsent(info.get(0),building);
        }
    }

    @Override
    public void addPath(Integer a, Integer b){
        ArrayList<String> aa = CampusAccess.IDLookup.get(a),bb = CampusAccess.IDLookup.get(b);
        ArrayList<Float> aaa,bbb;
        // get coord vals
        aaa = new ArrayList<>(Arrays.asList(Float.valueOf(aa.get(1)), Float.valueOf(aa.get(2))));
        bbb = new ArrayList<>(Arrays.asList(Float.valueOf(bb.get(1)), Float.valueOf(bb.get(2))));
        //add to graph
        g.addEdge(a,b,"", findDistance(aaa,bbb));
    }
    private float findDistance(ArrayList<Float> a, ArrayList<Float> b){
        double x = Math.pow(a.get(0)- b.get(0),2), y = Math.pow(a.get(1)- b.get(1),2);
        return (float) Math.sqrt(x+y);
    }
    @Override
    public HashSet<Integer> getBuildings(){ return g.getNodes(); }

    @Override
    public ArrayList<String> getDataFromID(Integer id){ return IDLookup.get(id); }

    @Override
    public Integer queryName(String name) {
        return nameLookup.get(name);
    }

    @Override
    public Path<Integer, String, Float> findPath(Integer a, Integer b) {
        GraphAlgo<Integer, String, Float> gg = new GraphAlgo<>(g); // interim solution, static classes don't play well with templates
        return gg.findPath(a,b, (float) 0);
    }
}
