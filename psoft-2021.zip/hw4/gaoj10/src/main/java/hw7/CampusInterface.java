package hw7;

import hw4.Path;

import java.sql.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Queue;

/**
 * Designed specifically for use with graph data structures, May work with OpenMaps API with some duct tape
 */
public interface CampusInterface {
    /**
     * @param building a non null string that is the id of the building
     * @param info a non null array formatted as the following: [name, x, y]
     */
    void addBuilding(Integer building, ArrayList<String> info);

    /**
     * Adds a bi directional path between a and b
     * @param a a non null ID that must be in the dataset
     * @param b a non null ID that must be in the dataset
     */
    void addPath(Integer a, Integer b);

    /**
     * @return all buildings that are in the dataset
     */
    HashSet<Integer> getBuildings();

    /**
     * @param id a non null ID that must be in the dataset
     * @return meta data formmated as the following: [name, x, y]
     */
    ArrayList<String> getDataFromID(Integer id);

    /**
     * returns an ID that is associated with the name
     * @param name a non null String
     * @return an ID
     */
    Integer queryName(String name);

    /**
     * searches for the shortest path between a and b, if exists. Otherwise, returns Path.EMPTY
     * @param a a non null ID that must be in the dataset
     * @param b a non null ID that must be in the dataset
     * @return a Path object
     */
    Path<Integer,String,Float> findPath(Integer a, Integer b);
}
