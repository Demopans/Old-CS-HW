package hw7;

import hw4.Path;
import hw4.Triple;

import java.io.*;
import java.util.*;
import java.util.regex.*;



/**
 * controller, private thread safe singleton
 **/
class CampusPaths {
    /**
     * Fields
     **/
    private static CampusPaths instance;
    private static ArrayList<String> options;
    private static CampusInterface campusInterface;
    private static BufferedReader br;
    /**
     * Methods
     **/
    private CampusPaths() {
        if (instance != null) throw new Error("Use getInstance() method to get the single instance of this class.");
        instance = this;
    }

    public static CampusPaths getInstance() {
        if (instance == null) instance = new CampusPaths();
        campusInterface = CampusAccess.getInstance();
        options = new ArrayList<>(2);
        br = new BufferedReader(new InputStreamReader(System.in));
        return instance;
    }

    private static void readNodeData(String filename)
            throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line,a, c, d;
        int b;
        while ((line = reader.readLine()) != null) {
            Pattern p = Pattern.compile("(.*?),([0-9]+),([0-9]+),([0-9]+)");// hooray regex
            Matcher m = p.matcher(line);
            if (m.matches()) {
                a = m.group(1);
                b = Integer.parseInt(m.group(2));
                c = m.group(3);
                d = m.group(4);
            } else {
                throw new IOException("File " + filename + " not a valid CSV (BUILDING,ID,X,Y) file.");
            }
            // form node
            ArrayList<String> point = new ArrayList<>(Arrays.asList(a, c, d));
            campusInterface.addBuilding(b, point);
        }
    }

    private static void readEdgeData(String filename)
            throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        int a, b;

        while ((line = reader.readLine()) != null) {
            Pattern p = Pattern.compile("(.*?),(.*?)");// hooray regex
            Matcher m = p.matcher(line);
            if (m.matches()) {
                a = Integer.parseInt(m.group(1));
                b = Integer.parseInt(m.group(2));
            } else {
                throw new IOException("File " + filename + " not a valid CSV (X,Y) file.");
            }
            // form node
            campusInterface.addPath(a, b);
        }
    }

    public static void main(String[] args) {
        campusInterface = CampusAccess.getInstance();
        instance = getInstance();
        try {
            readNodeData("data/RPI_map_data_Nodes.csv");
            readEdgeData("data/RPI_map_data_Edges.csv");
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        String h = "q";
        while (true) {
            try {
                if ((h = br.readLine()) == null) break;
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            switch (h) {
                case "r":
                    r();
                    options = new ArrayList<>(2);
                    break;
                case "q": return;
                case "m": m();break;
                case "i":
                    try {
                        readNodeData("data/RPI_map_data_Nodes.csv");
                        readEdgeData("data/RPI_map_data_Edges.csv");
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                    break;
                case "b": b();break;
                case "clear": clear();break;
                case "\n":
                case "\r":
                case " ":
                    break;
                default:
                    System.out.println("Unknown option");
                    break;
            }
        }
    }

    private static void clear() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                Runtime.getRuntime().exec("cls");
                System.console().flush();
            }
            else {
                Runtime.getRuntime().exec("clear");
                System.console().flush();
            }
        }
        catch (final Exception e) {
            //  Handle any exceptions.
        }
    }

    private static void b() {
        HashSet<Integer> b = campusInterface.getBuildings();
        TreeSet<String> bs = new TreeSet<>();

        for (Integer s : b) {
            ArrayList<String> d = campusInterface.getDataFromID(s);
            String name = d.get(0);
            if (name.equals("")){continue;}
            bs.add(name);
        }
        for (String s : bs) {
            System.out.printf("%s,%s%n",s, campusInterface.queryName(s));
        }
    }

    private static void m(){
        System.out.println("b lists all buildings (only buildings) in the form name,id in lexicographic (alphabetical) order of name.\n" +
                           "r prompts the user for the ids or names of two buildings (only buildings!) and prints directions for the shortest route between them.\n" +
                           "q quits the program. (Note: this command should simply cause the main method to return. Calling System.exit to terminate the program will break the tests.)\n" +
                           "m prints a menu of all commands. Feel free to add functionality. Our tests cover only the functionality specified above.\n" +
                           "c clears the console\n");
    }

    private static void r(){
        try {
            rRead();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        // sanity
        if (!rVerify()) return;

        Path<Integer,String,Float> p =
                campusInterface.findPath(Integer.parseInt(options.get(0)), Integer.parseInt(options.get(1)));
        printPath(p);
    }
    private static void rRead() throws IOException {
        //prompt
        System.out.println("First building id/name, followed by Enter:");
        String tt = br.readLine();
        options.add(0, tt);

        System.out.println("Second building id/name, followed by Enter:");
        tt = br.readLine();
        options.add(1, tt);
    }

    /**
     * verifies input data, terminates invalid inputs
     * @return true if input is good
     */
    private static boolean rVerify(){
        String a = options.get(0), b = options.get(1);
        int aa,bb;
        try {
            //possible ids
            aa = Integer.parseInt(a);
        }catch (NumberFormatException e){
            //arent ids, try to look up name
            aa = campusInterface.queryName(a)!=null?campusInterface.queryName(a):-1;
        }
        try {
            //possible ids
            bb = Integer.parseInt(b);
        }catch (NumberFormatException e){
            //arent ids, try to look up name
            bb = campusInterface.queryName(b)!=null?campusInterface.queryName(b):-1;
        }

        // check ids
        HashSet<Integer> t = campusInterface.getBuildings();
        boolean aInSet = t.contains(aa), bInSet = t.contains(bb);
        if (!aInSet||!bInSet){
            if (!aInSet&&!bInSet){
                if (aa==bb&&aa==-1){
                    if (a.equals(b)){
                        System.out.printf("Unknown building: [%s]\n", a);
                    }else {
                        System.out.printf("Unknown building: [%s]\nUnknown building: [%s]\n", a,b);
                    }
                }else if (aa==bb){
                    System.out.printf("Unknown building: [%s]\n", a);
                }
            } else if (!t.contains(aa)){ System.out.printf("Unknown building: [%s]\n", a);
            } else {System.out.printf("Unknown building: [%s]\n", b);}
            return false;
        }else {//intersection
            ArrayList<String> an = campusInterface.getDataFromID(aa), bn = campusInterface.getDataFromID(bb);
            boolean aI = an.get(0).isEmpty(),bI = bn.get(0).isEmpty();

            if (aI||bI){
                if (aI&&bI){
                    if (an.equals(bn)){
                        System.out.printf("Unknown building: [%s]\n", aa);
                    }else {
                        System.out.printf("Unknown building: [%s]\nUnknown building: [%s]\n", aa,bb);
                    }
                } else if (an.get(0).isEmpty()){ System.out.printf("Unknown building: [%s]\n", aa);
                } else {System.out.printf("Unknown building: [%s]\n", bb);}
                return false;
            }
        }

        options.set(0,aa+"");options.set(1,bb+"");// Buildings stored as ids from now on
        return true;
    }

    private static void printPath(Path<Integer,String,Float> p){
        String a = options.get(0),b = options.get(1);
        System.out.printf("From %s to %s\n",campusInterface.getDataFromID(Integer.parseInt(a)).get(0),
                campusInterface.getDataFromID(Integer.parseInt(b)).get(0));

        ArrayList<Triple<Integer,String,Float>> pp = p.getPath();
        ArrayList<String> tmp = campusInterface.getDataFromID(Integer.parseInt(a));
        if (!pp.isEmpty()){
            for (Triple<Integer, String, Float> integerStringFloatTriple : pp) {
                int id = integerStringFloatTriple.x;
                ArrayList<String> d = campusInterface.getDataFromID(id);
                String dir = findDir(tmp, d);

                String name = d.get(0);
                if (name.equals("")) {
                    System.out.printf("\tWalk %s to (Intersection %s)\n", dir, id);
                } else {
                    System.out.printf("\tWalk %s to (%s)\n", dir, name);
                }
                tmp = d;
            }
            System.out.printf("Total distance: %.3f pixel units.\n",p.getW());
        }else {
            if (a.equals(b)){
                System.out.printf("Total distance: %.3f pixel units.\n",p.getW());
            }else {
                System.out.printf("There is no path from %s to %s.\n",
                        campusInterface.getDataFromID(Integer.parseInt(a)).get(0),
                        campusInterface.getDataFromID(Integer.parseInt(b)).get(0)
                        );
            }
        }
    }
    private static class DegreeToQuadrant {

        List<QuadrantItem> quadrants;
        String[] QuadrantNames = new String[]{
                "North",
                "NorthEast",
                "East",
                "SouthEast",
                "South",
                "SouthWest",
                "West",
                "NorthWest"
        };

        DegreeToQuadrant() {
            double leftValue = 360 - 22.5;
            double rightValue = 22.5;
            double step = 45;
            quadrants = new ArrayList<>();
            for (String qname : QuadrantNames) {
                QuadrantItem quadrantItem = null;
                if (qname.equals("North"))
                    quadrantItem = new QuadrantItem(qname, leftValue, rightValue, "or");
                else {
                    leftValue = rightValue;
                    rightValue = leftValue + step;
                    quadrantItem = new QuadrantItem(qname, leftValue, rightValue, "and");
                }
                quadrants.add(quadrantItem);
            }
        }

        String getQuadrantName(double degree) {
            for (QuadrantItem quadrantItem : quadrants)
                if (quadrantItem.isIn(degree))
                    return quadrantItem.m_quadrantName;
            return "";
        }

        private static class QuadrantItem {
            String m_quadrantName;
            String m_operation; //or , and
            double m_left;
            double m_right;
            HashMap<String, QuadrantItem> quadrants;

            QuadrantItem(String name, double left, double right, String operation) {
                m_quadrantName = name;
                m_operation = operation;
                m_left = left;
                m_right = right;
            }

            boolean isIn(double degree) {
                if (m_operation.equals("and"))
                    return degree > m_left && degree < m_right;
                else
                    return degree > m_left || degree < m_right;
            }
        }

    }

    /**
     * Helper function, finds direction between 2 nodes
     */
    private static String findDir(ArrayList<String> a, ArrayList<String> b) {
        //calculate dx and dy
        ArrayList<Float> pa = new ArrayList<>();
        pa.add(Float.valueOf(a.get(1)));
        pa.add(Float.valueOf(a.get(2)));
        ArrayList<Float> pb = new ArrayList<>();
        pb.add(Float.valueOf(b.get(1)));
        pb.add(Float.valueOf(b.get(2)));
        float dx = pb.get(0) - pa.get(0),dy=pb.get(1) - pa.get(1);

        //ToDO: yes, divide by zero is a possibility. Yes, I will have to get around to fixing it
        double r = (Math.atan2(dy,dx));
        return new DegreeToQuadrant().getQuadrantName((Math.toDegrees(r)+360+90)%360);
    }
}