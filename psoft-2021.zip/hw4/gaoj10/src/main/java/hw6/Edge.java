package hw6;

import java.util.Objects;

/**
 * Special edge object, a,b are interchangeable for temp edge hashing
 */
public class Edge {
    String a, b;

    public Edge(String a, String b) {
        this.a = a;
        this.b = b;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Edge)) return false;
        Edge edge = (Edge) o;
        return (Objects.equals(a, edge.a) && Objects.equals(b, edge.b)) || (Objects.equals(b, edge.a) && Objects.equals(a, edge.b));
    }

    @Override
    public int hashCode() {
        return Objects.hash(a) + Objects.hash(b);
    }

    @Override
    public String toString() {
        return "Pair{" +
                "a='" + a + '\'' +
                ", b='" + b + '\'' +
                '}';
    }
}
