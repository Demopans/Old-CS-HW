package hw6;

import hw5.*;
import hw4.*;

import java.io.IOException;
import java.util.*;


class MarvelPaths2 {
    Graph<String,String,Float> g;

    public MarvelPaths2() {
        this.g = new Graph<>(new HashMap<>(), true, false, false);
    }

    public MarvelPaths2(String filename){ createNewGraph(filename); }

    /**
     * Resets the graph and builds a new one
     * @param filename a non-null String object containing path to the database file
     */
    public void createNewGraph(String filename){
        g = new Graph<>(new HashMap<>(), true, false,false);
        HashMap<String, Set<String>> a = new HashMap<>();
        HashSet<String> b = new HashSet<>();
        try {
            MarvelParser.readData(filename,a,b);
        } catch (IOException ioException) {
            ioException.printStackTrace();
            System.exit(-1);
        }
        // create graph from chars
        for (String s : b) {
            g.addNode(s);
        }
        HashMap<Edge,Integer> temp = new HashMap<>();
        for (Map.Entry<String, Set<String>> entry : a.entrySet()) {
            ArrayList<String> t = new ArrayList<>(entry.getValue());
            // form pairs
            for (int i = 0; i < t.size(); i++) {
                for (int j = i+1; j < t.size(); j++) {
                    Edge e = new Edge(t.get(i),t.get(j));
                    //does e exist?
                    if (temp.containsKey(e)){
                        temp.replace(e,temp.get(e),temp.get(e)+1);
                    }else {
                        temp.put(e,1);
                    }
                }
            }
        }

        // form graph from edges
        for (Map.Entry<Edge, Integer> entry : temp.entrySet()) {
            g.addEdge(entry.getKey().a,entry.getKey().b,"",1/entry.getValue().floatValue());
        }
    }

    /**
     * Implemention of D's algorithm to the Marvel Dataset. Assuming valid entries of char1 and char2, the
     * algorithm is able to find the lowest cost path possible, if it exist. If there are more than 1 possible minimum paths,
     * the algo returns 1 at random due to how Objects.hash() and PriorityQueue behaves
     * @param char1 an non-null string representing the starting character
     * @param char2 an non-null string representing the dest character
     * @return path from char1 to char2 if it exists
     * ToDO: Migrate to hw4.Graph as an optional algorithm for weighted graphs.
     */
    public String findPath(final String char1, final String char2){
        // sanity
        boolean x = g.query(char1).isEmpty(),y = g.query(char2).isEmpty();
        if (x&&y){return "unknown character "+char1+"\n"+"unknown character "+char2+"\n";}
        else if (x){return "unknown character "+char1+"\n";}
        else if (y){return "unknown character "+char2+"\n";}

        // init comparison function
        Comparator<Triple<String,String,Float>> comparator = Comparator.comparing(a -> a.z);
        // init priority queue
        Queue<Triple<String,String,Float>> q = new PriorityQueue<>(comparator);
        // init storage of paths, ref table for the queue
        HashMap<Triple<String,String,Float>,Path<String,String,Float>> paths = new HashMap<>();
        // stores visited nodes
        HashSet<String> visited = new HashSet<>();
        //add path to itself
        final float ZERO = 0;
        Triple<String,String,Float> sel = new Triple<>(char1,char1, ZERO);
        q.add(sel);
        paths.put(sel, new Path<>(new ArrayList<>(),ZERO));
        //search
        while (!q.isEmpty()){
            //pop best member
            Triple<String,String,Float> s = q.poll();
            String end = s.y;

            if (end.equals(char2)){ return constructPath(paths.get(s),s); }

            //does path exist?
            if (visited.contains(end)){
                continue;//longer path comes later thanks to the priority queue
            }

            //from last element in path, add new nodes to path, adjust weights accordingly
            //structure: dest node, label (unused), weights
            HashSet<Triple<String,String,Float>> e = g.query(end);

            //safe to construct possible paths since D's would have found one by this point
            for (Triple<String, String, Float> triple : e) {
                String next = triple.x;
                //if not exists
                if (!visited.contains(next)){
                    //create new path data
                    Path<String,String,Float> p = paths.get(s);
                    ArrayList<Triple<String, String, Float>> pp = new ArrayList<>(p.getPath());
                    pp.add(triple);
                    float f = triple.z + s.z;
                    Triple<String,String,Float> k = new Triple<>(char1, next, f);
                    //push new path data to eval
                    q.add(k);
                    paths.put(k, new Path<>(pp,f));
                }
            }
            //mark this node as visited
            visited.add(end);
        }
        //unable to find path
        return "path from "+char1+" to "+char2+":\n no path found\n";
    }


    private String constructPath(
            final Path<String, String, Float> p, Triple<String,String,Float> k){
        String char1 = k.x;
        String char2 = k.y;
        StringBuilder a = new StringBuilder("path from " + char1 + " to " + char2 + ":\n");
        if (!char1.equals(char2)){
            a.append(char1).append(" to ").append(p.getPath().get(0).x).append(" with weight ").append(String.format("%.3f", p.getPath().get(0).z)).append("\n");
        }
        for (int j = 1; j < p.getPath().size(); j++) {
            a.append(p.getPath().get(j - 1).x).append(" to ").append(p.getPath().get(j).x).append(" with weight ").append(String.format("%.3f", p.getPath().get(j).z)).append("\n");
        }
        a.append(String.format("total cost: %.3f\n", p.getW()));
        return new String(a);
    }
}