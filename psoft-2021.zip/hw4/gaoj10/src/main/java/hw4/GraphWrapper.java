package hw4;

import java.security.InvalidParameterException;
import java.util.*;

/**
 * methods such as erdos graph generation and Dijkstra's go here.
 * Reserved room for further implementation
 */
/*
class GraphMethods{
    // stuff
}
*/


public class GraphWrapper {
    public Graph<String,String,Integer> g;

    public GraphWrapper() {
        this.g = new Graph<>();
    }

    public void addNode(String nodeData) {
        this.g.addNode(nodeData);
    }

    public void addEdge(String parentNode, String childNode, String edgeLabel) {
        this.g.addEdge(parentNode, childNode, edgeLabel, 0);
    }

    public Iterator<String> listNodes() {
        ArrayList<String> tmp = new ArrayList<>(g.getNodes());
        Collections.sort(tmp);
        return new Iterator<String>() {
            int i = 0;

            @Override
            public boolean hasNext() {
                return i < tmp.size();
            }

            @Override
            public String next() {
                return tmp.get(i++);
            }
        };
    }


    public Iterator<String> listChildren(String parentNode) {
        //get edge set in question
        ArrayList<Triple<String, String, Integer>> tmp = new ArrayList<>(g.query(parentNode));
        tmp.sort((Triple<String, String, Integer> a, Triple<String, String, Integer> b) -> {
            // hw spec isn't asking for anything more
            if (a.x.equals(b.x)) {
                return a.y.compareTo(b.y);
            } else {
                return a.x.compareTo(b.x);
            }
        });

        return new Iterator<String>() {
            int i = 0;

            @Override
            public boolean hasNext() {
                return i < tmp.size();
            }

            @Override
            public String next() {
                return tmp.get(i).x + "(" + tmp.get(i++).y + ")";
            }
        };

    }
}