package hw4;

import java.util.Objects;

public class Pair<X,Y> {
    // piggy back off of Triple
    Triple<X,Y,Boolean> d;

    public Pair(X x, Y y) {
        this.d = new Triple<>(x,y,false);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pair<?, ?> pair = (Pair<?, ?>) o;
        return Objects.equals(d, pair.d);
    }

    @Override
    public int hashCode() {
        return Objects.hash(d);
    }

    @Override
    public String toString() {
        return "Pair{" +
                "x=" + d.x + "," +
                "y=" + d.y +
                '}';
    }
}
