package hw4;

import java.security.InvalidParameterException;
import java.util.*;

/**
 * Graph super class. Holds common data fields
 * @param <N> A type for the node. Must implement hashCode, equals, compareTo
 * @param <L> A type for the label. Must implement hashCode, equals, compareTo
 * @param <V> A numeric type for weights. Supported types are: Integer, Float, Double, Short, Long, Byte
 */
public class Graph<N, L, V extends Number & Comparable<V>> {
    /**
     * Constants
     */
    static final Graph<?,?,?> NULL = null;
    static final Graph<?,?,?> DEFAULT = new Graph<>();

    /**
     * Fields
     */
    final Boolean weighted;
    final Boolean isDirected;
    boolean negEdge = false;
    /* Format: {node name : node name, edge label, weight}
     * It is very much possible for a label and a weight to be different for purposes where it would make sense to differentiate them.
     */
    HashMap<N, HashSet<Triple<N, L, V>>> adjList;//Naturally prevents duplicates

    /* Constructors */
    /**
     * Constructs a graph from an adjacency list, along with some other required fields. Should only be used in case of larger datasets
     *
     * @param adjList    defines all the nodes, as well as it's neighbors
     * @param w          whether the graph is weighted or not. If w is null, throws NullPointerException
     * @param isDirected Permissible inputs: [u: undirected, d: directed].
     *                   If isDirected is null, throws NullPointerException. If isDirected is invalid, throws InvalidParameterException
     * @requires nothing. error cases are simply terminated at once
     */
    public Graph(HashMap<N, HashSet<Triple<N, L, V>>> adjList, Boolean w, Boolean isDirected, Boolean negEdge)
            throws InvalidParameterException, NullPointerException {
        // no
        if (w == null || adjList == null || isDirected == null) {
            throw new NullPointerException();
        }

        this.adjList = adjList;
        this.weighted = w;
        this.isDirected = isDirected;
        this.negEdge = negEdge;
        //assert (checkRep());
    }

    /**
     * Default constructor
     */
    public Graph() {
        this.isDirected = false;
        this.weighted = false;
        this.adjList = new HashMap<>();
    }

    /**
     * Choosy constructor
     *
     * @param directed whether the graph is directed
     * @requires directed be not null
     */
    public Graph(Boolean directed) {
        isDirected = directed;
        this.weighted = false;
        this.adjList = new HashMap<>();
    }

    /**
     * Copy Constructor
     *
     * @param a Undirected Graph to copy
     * @requires nothing. error cases are simply terminated at once (also, a is already valid anyways)
     */
    public Graph(Graph<N, L,V> a) {
        this.adjList = a.adjList;
        this.weighted = a.weighted;
        this.isDirected = a.isDirected;
        this.negEdge = a.negEdge;
    }

    /* Functions */
    /**
     * @return copy of the set of nodes. Constant lookup times possible
     */
    public final HashSet<N> getNodes() { return new HashSet<>(adjList.keySet()); }

    /**
     * Get neighbors of a node
     *
     * @param parentNode any non null node
     * @return all edges associated with that node. if node is not in graph, returns empty set
     */
    public final HashSet<Triple<N, L, V>> query(N parentNode) {
        if (parentNode == null) {
            throw new NullPointerException();
        } else if (!adjList.containsKey(parentNode)) {
            return new HashSet<>();
        } else {
            return new HashSet<>(adjList.get(parentNode));
        }
    }

    /**
     * adds a new node to the graph, along with a dummy value
     *
     * @param newNode the new node to add. Cannot be null
     * @modifies adjList
     */
    public void addNode(N newNode) throws NullPointerException {
        if (newNode == null) {
            throw new NullPointerException();
        }
        HashSet<Triple<N, L, V>> empty = new HashSet<>();
        this.adjList.putIfAbsent(newNode, empty);
        //assert (checkRep());
    }

    /**
     * links a new edge between 2 nodes. If link already exists, do nothing
     *
     * @param parentNode Node in adjacency list.
     * @param childNode  Node in adjacency list
     * @param edgeLabel  What to label this edge
     * @param edgeWeight The weight of this edge
     * @throws NullPointerException     when any of the parameters are null
     * @throws MissingResourceException when keys doesn't exist
     * @requires nothing. The Terminator lives
     * @modifies adjList
     */
    @SuppressWarnings("unchecked")
    public void addEdge(N parentNode, N childNode, L edgeLabel, V edgeWeight)
            throws NullPointerException, MissingResourceException {
        //no
        if (parentNode == null || childNode == null || edgeLabel == null || edgeWeight == null) {
            throw new NullPointerException();
        }
        //check if nodes exist
        if (!adjList.containsKey(parentNode) || !adjList.containsKey(childNode)) {
            throw new MissingResourceException("", "", "");
        }

        //build edge data
        HashSet<Triple<N, L, V>> tmpSet = adjList.get(parentNode);

        if (weighted){
            if (edgeWeight instanceof Integer){
                negEdge = (Integer) edgeWeight < 0;
            } else if (edgeWeight instanceof Float){
                negEdge = (Float) edgeWeight < 0;
            } else if (edgeWeight instanceof Double){
                negEdge = (Double) edgeWeight < 0;
            } else if (edgeWeight instanceof Short){
                negEdge = (Short) edgeWeight < 0;
            } else if (edgeWeight instanceof Long){
                negEdge = (Long) edgeWeight < 0;
            } else if (edgeWeight instanceof Byte){
                negEdge = (Byte) edgeWeight < 0;
            } else {
                throw new Error("Unsupported numeric type");
            }
            tmpSet.add(new Triple<>(childNode, edgeLabel, edgeWeight));
        }else {
            // V should be able to be cast to itself
            if (edgeWeight instanceof Integer){
                tmpSet.add(new Triple<>(childNode, edgeLabel, (V)Integer.valueOf(0)));
            } else if (edgeWeight instanceof Float){
                tmpSet.add(new Triple<>(childNode, edgeLabel, (V)Float.valueOf(0)));
            } else if (edgeWeight instanceof Double){
                tmpSet.add(new Triple<>(childNode, edgeLabel, (V)Double.valueOf(0)));
            } else if (edgeWeight instanceof Short){
                short s = 0;
                tmpSet.add(new Triple<>(childNode, edgeLabel, (V)Short.valueOf(s)));
            } else if (edgeWeight instanceof Long){
                tmpSet.add(new Triple<>(childNode, edgeLabel, (V)Long.valueOf(0)));
            } else if (edgeWeight instanceof Byte){
                byte b = 0;
                tmpSet.add(new Triple<>(childNode, edgeLabel, (V)Byte.valueOf(b)));
            } else {
                throw new Error("Unsupported numeric type");
            }

        }
        adjList.replace(parentNode, tmpSet);

        //add second link for undirected graphs
        if (!isDirected) {
            //build edge data
            tmpSet = adjList.get(childNode);
            tmpSet.add(new Triple<>(parentNode, edgeLabel, edgeWeight));
            adjList.replace(childNode, tmpSet);
        }
    }

    /**
     * Standard class overrides
     */
    @Override
    public String toString() {
        return "Graph{" +
                "weighted=" + weighted +
                ", adjList=" + adjList +
                ", isDirected='" + isDirected + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Graph)) return false;
        Graph<?, ?, ?> graph = (Graph<?, ?, ?>) o;
        return Objects.equals(weighted, graph.weighted) && Objects.equals(isDirected, graph.isDirected) && Objects.equals(adjList, graph.adjList);
    }

    @Override
    public int hashCode() {
        return Objects.hash(weighted, isDirected, adjList);
    }
}