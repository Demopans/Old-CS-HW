package hw4;

import java.util.*;

@SuppressWarnings("unchecked")
public class GraphAlgo<N, L, V extends Number & Comparable<V>> {
    Graph<N,L,V> g;
    public GraphAlgo(Graph<N,L,V> ptr){
        g = ptr;
    }
    /**
     * Assuming n1 and n2 are in the graph, findPath finds a path between n1 and n2, assuming it exists
     * If graph is weighted, findPath() defaults to Dijkstra's for the case of no negative edges, and Floyd-Warshall otherwise
     * Otherwise, findPath() uses BFS
     * Any user of findPath() should keep in mind that there is minimal error handling
     * @requires listed in @params
     * @param n1 a non null start node, must be in the graph
     * @param n2 a non null end node, must be in the graph
     * @param t a non null value used for type evaluation
     * @return a Path object detailing the path, if exists. Otherwise, returns a generic empty path
     */
    public Path<N, L, V> findPath(N n1, N n2, V t){
        // build path
        if (g.weighted){
            if (!g.negEdge){// Dijkstra's
                return dijkstra(n1,n2,t);
            }else {//Floyd-Warshall
                return floydWarshall(n1,n2,t);
            }
        }else {
            return bfs(n1,n2,t);//bfs doesn't care about weights
        }
    }

    /**
     * Floyd-Warshall method of pathing.
     * ToDO: implement the darn thing
     * @requires listed in @params
     * @param n1 a non null start node, must be in the graph
     * @param n2 a non null end node, must be in the graph
     * @param t a non null value used for type evaluation
     * @return a Path object detailing the path, if exists. Otherwise, returns a generic empty path
     */
    private Path<N,L,V> floydWarshall(N n1, N n2, V t) {
        throw new Error("Floyd-Warshall is currently not implemented");
    }

    /**
     * Gets a zero value out of supported numeric values
     */
    private V zero(V t){
        if (t instanceof Integer){
            return (V)Integer.valueOf(0);
        } else if (t instanceof Float){
            return (V)Float.valueOf(0);
        } else if (t instanceof Double){
            return (V)Double.valueOf(0);
        } else if (t instanceof Short){
            short a = (short) 0;
            return (V)Short.valueOf(a);
        } else if (t instanceof Long){
            return (V)Long.valueOf(0);
        } else {
            byte a = (byte) 0;
            return (V) Byte.valueOf(a);
        }
    }

    /**
     * Helper function for handling typing
     */
    private Pair<HashMap<Triple<N, N, V>,Path<N, L, V>>,Triple<N, N,V>> initVals(N n1, V t){
        HashMap<Triple<N, N, V>,Path<N, L, V>> table = new HashMap<>();
        Triple<N, N,V> start = new Triple<>(n1,n1,(V) Integer.valueOf(0));
        table.put(start,new Path<>(new ArrayList<>(),zero(t)));
        return new Pair<>(table,start);
    }

    /**
     * Helper function for handling typing
     */
    private Triple<N,N,V> addW(N n1, N e, V t, V v){
        if (t instanceof Integer){
            return new Triple<>(n1,e,(V) Integer.valueOf((Integer) t + (Integer) v));
        } else if (t instanceof Float){
            return new Triple<>(n1,e,(V) Float.valueOf((Float) t + (Float) v));
        } else if (t instanceof Double){
            return new Triple<>(n1,e,(V) Double.valueOf((Double) t + (Double) v));
        } else if (t instanceof Short){
            short a = (Short)t,b=(Short)v,c= (short) (a+b);
            return new Triple<>(n1,e,(V) Short.valueOf(c));
        } else if (t instanceof Long){
            return new Triple<>(n1,e,(V) Long.valueOf((Long) t + (Long) v));
        } else {
            byte a = (Byte) t,b=(Byte) v,c= (byte) (a+b);
            return new Triple<>(n1,e,(V) Byte.valueOf(c));
        }

    }
    /**
     * dijkstra's method used in findPath
     * @requires listed in @params
     * @param n1 a non null start node, must be in the graph
     * @param n2 a non null end node, must be in the graph
     * @param t a non null value used for type evaluation
     * @return a Path object detailing the path, if exists. Otherwise, returns a generic empty path
     */
    private Path<N,L,V> dijkstra(N n1, N n2, V t){
        //init lookup table
        Pair<HashMap<Triple<N, N, V>,Path<N, L, V>>,Triple<N, N,V>> temp = initVals(n1,t);
        HashMap<Triple<N, N, V>,Path<N, L, V>> table = temp.d.x;
        Triple<N, N,V> start = temp.d.y;
        // init visited
        HashSet<N> v = new HashSet<>();
        // init queue
        // the priority queue implementation is best left elsewhere. hopefully, this uses an integer priority queue
        Queue<Triple<N, N,V>> q = new PriorityQueue<>(Comparator.comparing(a -> a.z));
        //add start to queue
        q.add(start);
        while (!q.isEmpty()){
            Triple<N,N,V> eval = q.poll();
            N e = eval.y;
            if (e.equals(n2)){//is eval the answer?
                return table.get(eval);
            }else if (v.contains(e)){//were we here before?
                continue;
            }
            HashSet<Triple<N, L, V>> edges = g.adjList.get(eval.y);
            for (Triple<N, L, V> edge : edges) {
                //add to path
                Path<N,L,V> p = table.get(eval);
                ArrayList<Triple<N,L,V>> pp = p.getPath();
                pp.add(edge);
                //create key
                Triple<N,N,V> tmp;
                N es = edge.x;
                tmp = addW(n1,es,p.w, edge.z);
                // add key to table and queue
                table.putIfAbsent(tmp,new Path<>(pp, tmp.z));
                q.add(tmp);
            }
            v.add(e);
        }
        // build empty output
        return (Path<N, L, V>) Path.EMPTY;//No path found
    }

    /**
     * BFS method used in findPath
     * @requires listed in @params
     * @param n1 a non null start node, must be in the graph
     * @param n2 a non null end node, must be in the graph
     * @param t a non null value used for type evaluation
     * @return a Path object detailing the path, if exists. Otherwise, returns a generic empty path
     */
    private Path<N,L,V> bfs(N n1, N n2, V t){
        //init lookup table
        Pair<HashMap<Triple<N, N, V>,Path<N, L, V>>,Triple<N, N,V>> temp = initVals(n1,t);
        HashMap<Triple<N, N, V>,Path<N, L, V>> table = temp.d.x;
        Triple<N, N,V> start = temp.d.y;
        // init visited
        HashSet<N> v = new HashSet<>();

        Queue<Triple<N, N,V>> q = new LinkedList<>();
        //add start to queue
        q.add(start);
        while (!q.isEmpty()){
            Triple<N,N,V> eval = q.poll();
            N e = eval.y;
            if (e.equals(n2)){//is eval the answer?
                return table.get(eval);
            }else if (v.contains(e)){//were we here before?
                continue;
            }
            HashSet<Triple<N, L, V>> edges = g.adjList.get(eval.y);
            for (Triple<N, L, V> edge : edges) {
                //add to path
                Path<N,L,V> p = table.get(eval);
                ArrayList<Triple<N,L,V>> pp = p.getPath();
                pp.add(edge);
                //create key
                Triple<N,N,V> tmp;
                N es = edge.x;
                tmp = addW(n1,es,p.w, edge.z);
                // add key to table and queue
                table.putIfAbsent(tmp,new Path<>(pp, tmp.z));
                q.add(tmp);
            }
            v.add(e);
        }
        // build empty output
        return (Path<N,L,V>) Path.EMPTY;
    }

}
