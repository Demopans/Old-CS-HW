package hw4;

import java.util.Objects;

public class Triple<X, Y, Z> {
    public final X x;
    public final Y y;
    public final Z z;

    public Triple(X x, Y y, Z z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    /**
     * IDE generated override
     *
     * @param o where o is any object
     * @return true if everything is equal, false otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Triple)) return false;
        Triple<?, ?, ?> triple = (Triple<?, ?, ?>) o;
        return Objects.equals(x, triple.x) && Objects.equals(y, triple.y) && Objects.equals(z, triple.z);
    }

    /**
     * IDE generated override
     *
     * @return some number
     */
    @Override
    public int hashCode() {
        int id = 1337;
        return Objects.hash(x, y, z, id);
    }

    public String toString() {
        return "Triple{" +
                "x=" + x +
                ", y=" + y +
                ", z='" + z + '\'' +
                '}';
    }
}
