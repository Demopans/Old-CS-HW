package hw4;

import java.util.*;

/**
 * helper class
 */
public class Path<N,L,V extends Number & Comparable<V>> {
    final ArrayList<Triple<N, L, V>> path;
    final V w;

    public static final Path<?,?,?> EMPTY = new Path<>(new ArrayList<>(),null);

    public Path(ArrayList<Triple<N, L, V>> path, V w) {
        this.path = path;
        this.w = w;
    }

    public ArrayList<Triple<N, L, V>> getPath() {
        return new ArrayList<>(path);
    }

    public V getW() {
        return w;
    }

    // basic overrides

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Path<?, ?, ?> path1 = (Path<?, ?, ?>) o;
        return Objects.equals(path, path1.path) && Objects.equals(w, path1.w);
    }

    @Override
    public int hashCode() {
        return Objects.hash(path, w);
    }

    @Override
    public String toString() {
        return "Path{" +
                "path=" + path +
                ", w=" + w +
                '}';
    }
    void t(V... o){

    }
}
