package hw5;

import hw4.Graph;
import hw4.Triple;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

class MarvelPaths {
    private Graph g = new Graph();

    /**
     * instant constructor, builds a graph from a dataset
     * @requires listed in params
     * @param filename path to the .csv file, must be a non-null string
     * @effects builds a graph
     */
    public MarvelPaths(String filename){
        createNewGraph(filename);
    }

    /**
     * generic constructor, does effectively nothing
     */
    public MarvelPaths(){
        g = new Graph();
    }

    /**
     * @requires listed in params
     * @param filename path to the .csv file, must be a non-null string
     * @effects builds a graph after clearing it
     */
    public void createNewGraph(String filename) {
        g = new Graph();
        HashMap<String, Set<String>> a = new HashMap<>();
        HashSet<String> b = new HashSet<>();
        try {
            MarvelParser.readData(filename,a,b);
        } catch (IOException ioException) {
            ioException.printStackTrace();
            System.exit(-1);
        }
        // create graph from chars
        for (String s : b) {
            g.addNode(s);
        }
        // characters that share the same book are linked
        for (String s : a.keySet()) {
            Set<String> tmp = a.get(s);
            ArrayList<String> t = new ArrayList<>(tmp);

            for (int i = 0; i < t.size(); i++) {
                for (int j = i+1; j < t.size(); j++) {
                    g.addEdge(t.get(i), t.get(j),s,0);
                }
            }
        }
    }

    /**
     * Attempts to find a path from node1 to node2
     * @requires listed in params
     * @param node1 start node, must be a non-null string
     * @param node2 end node, must be a non-null string
     * @return the 1st path, if exists from node1 to node2, where 1st follows the lexicographic least possible
     */
    public String findPath(String node1, String node2){
        LinkedHashSet<Triple<String, String, String>> v = new LinkedHashSet<>();

        //push first member into queue, search by edge
        HashSet<Triple<String, String, Integer>> t0 = g.query(node1);

        // sanity
        boolean x = t0.isEmpty(),y = g.query(node2).isEmpty();
        if (x&&y){return "unknown character "+node1+"\n"+"unknown character "+node2+"\n";}
        else if (x){return "unknown character "+node1+"\n";}
        else if (y){return "unknown character "+node2+"\n";}

        //convert then sort
        ArrayList<Triple<String, String, Integer>> t1 = new ArrayList<>(t0);
        t1.sort((a,b) -> {
            if (a.x.equals(b.x)&&a.y.equals(b.y)){return a.z - b.z;}
            else if (a.x.equals(b.x)){return a.y.compareTo(b.y);}
            else{return a.x.compareTo(b.x);}
        });

        // move sorted list to queue, IDE generated conversion
        Queue<Triple<String, String, String>> q = t1.stream().map(triple -> new Triple<>(node1, triple.x, triple.y)).collect(Collectors.toCollection(LinkedList::new));

        String currentEdge = "";
        while (!q.isEmpty()){
            Triple<String, String, String> t = q.remove();
            currentEdge = t.x;
            String consideredEdge = t.y;
            // did we visit t?
            if (v.contains(t)||v.contains(new Triple<>(currentEdge,consideredEdge, t.z))){
                continue;
            }

            // Janked edges structure : (end, start, label)
            v.add(new Triple<>(consideredEdge,currentEdge,t.z));
            // eval t
            if (currentEdge.equals(node2)){
                //construct path from visited nodes
                return output(v, node1, node2);
            }
            // add children
            t0 = g.query(consideredEdge);
            t1 = new ArrayList<>(t0);
            t1.sort((a,b) -> {
                if (a.x.equals(b.x)&&a.y.equals(b.y)){return a.z - b.z;}
                else if (a.x.equals(b.x)){return a.y.compareTo(b.y);}
                else{return a.x.compareTo(b.x);}
            });

            for (Triple<String, String, Integer> triple : t1) {
                q.add(new Triple<>(consideredEdge,triple.x,triple.y));
            }
        }
        // no hits
        return "path from "+node1+" to "+node2+":\n no path found\n";
    }

    /**
     * helper function, builds path from set of visited nodes
     * @requires listed in params
     * @param v set of visited nodes, cannot be null
     * @param node1 start node, must be a non-null string
     * @param node2 end node, must be a non-null string
     * @return path from node1 to node2
     */
    private String output(LinkedHashSet<Triple<String, String, String>> v, String node1, String node2){
        StringBuilder a = new StringBuilder("path from "+node1+" to "+node2+":\n");
        // sort for lexography
        ArrayList<Triple<String, String, String>> t1 = new ArrayList<>(v);
        t1.sort((x,y) -> {
            if (x.x.equals(y.x) && x.y.equals(y.y)){return x.z.compareTo(y.z);}
            else if (x.x.equals(y.x)){return x.y.compareTo(y.y);}
            else{return x.x.compareTo(y.x);}
        });
        // reverse bst following visited nodes

        //construct path from the endm
        ArrayList<ArrayList<String>> path = new ArrayList<>();
        String l = node2;
        while (!l.equals(node1)){
            String d;
            for (Triple<String, String, String> triple : v) {
                if (triple.x.equals(l)){
                    d = triple.y;
                    path.add(0, new ArrayList<>(Arrays.asList(d, l,triple.z)));
                    l = d;
                    break;
                }
            }
        }
        for (ArrayList<String> p : path) {
            a.append(p.get(0)).append(" to ").append(p.get(1)).append(" via ").append(p.get(2)).append("\n");
        }
        return new String(a);
    }
}

