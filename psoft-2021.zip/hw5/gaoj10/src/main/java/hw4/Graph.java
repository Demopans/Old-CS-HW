package hw4;

import java.security.InvalidParameterException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.MissingResourceException;
import java.util.Objects;

/**
 * Graph super class. Holds common data fields
 */
public class Graph {
    /**
     * Constants
     */
    static final Graph NULL = null;
    static final Graph DEFAULT = new Graph();

    /**
     * Fields
     */
    final private Boolean weighted;
    private final Boolean isDirected;
    /* Format: {node name : node name, edge label, weight}
     * It is very much possible for a label and a weight to be different for purposes where it would make sense to differentiate them.
     */
    protected HashMap<String, HashSet<Triple<String, String, Integer>>> adjList;//Naturally prevents duplicates

    /** Constructors */
    /**
     * Constructs a graph from an adjacency list, along with some other required fields. Should only be used in case of larger datasets
     *
     * @param adjList    defines all the nodes, as well as it's neighbors
     * @param w          whether the graph is weighted or not. If w is null, throws NullPointerException
     * @param isDirected Permissible inputs: [u: undirected, d: directed].
     *                   If isDirected is null, throws NullPointerException. If isDirected is invalid, throws InvalidParameterException
     * @requires nothing. error cases are simply terminated at once
     */
    public Graph(HashMap<String, HashSet<Triple<String, String, Integer>>> adjList, Boolean w, Boolean isDirected)
            throws InvalidParameterException, NullPointerException {
        // no
        if (w == null || adjList == null || isDirected == null) {
            throw new NullPointerException();
        }

        this.adjList = adjList;
        this.weighted = w;
        this.isDirected = isDirected;
        //assert (checkRep());
    }

    /**
     * Default constructor
     */
    public Graph() {
        this.isDirected = false;
        this.weighted = false;
        this.adjList = new HashMap<>();
    }

    /**
     * Choosey constructor
     *
     * @param directed whether the graph is directed
     * @requires directed be not null
     */
    public Graph(Boolean directed) {
        isDirected = directed;
        this.weighted = false;
        this.adjList = new HashMap<>();
    }

    /**
     * Copy Constructor
     *
     * @param a Undirected Graph to copy
     * @requires nothing. error cases are simply terminated at once (also, a is already valid anyways)
     */
    public Graph(Graph a) {
        this.adjList = a.adjList;
        this.weighted = a.weighted;
        this.isDirected = a.isDirected;
    }

    /** Functions */
    /**
     * @return copy of the set of nodes. Constant lookup times possible
     */
    public final HashSet<String> getNodes() {
        return new HashSet<>(adjList.keySet());
    }

    /**
     * Get neighbors of a node
     *
     * @param parentNode
     * @return
     */
    public final HashSet<Triple<String, String, Integer>> query(String parentNode) {
        if (parentNode == null) {
            throw new NullPointerException();
        } else if (!adjList.containsKey(parentNode)) {
            return new HashSet<>();
        } else {
            return new HashSet<>(adjList.get(parentNode));
        }
    }

    /**
     * adds a new node to the graph, along with a dummy value
     *
     * @param newNode the new node to add. Cannot be null
     * @modifies adjList
     */
    public void addNode(String newNode) throws NullPointerException {
        if (newNode == null) {
            throw new NullPointerException();
        }
        HashSet<Triple<String, String, Integer>> empty = new HashSet<>();
        this.adjList.putIfAbsent(newNode, empty);
        //assert (checkRep());
    }

    /**
     * links a new edge between 2 nodes. If link already exists, do nothing
     *
     * @param parentNode Node in adjacency list.
     * @param childNode  Node in adjacency list
     * @param edgeLabel  What to label this edge
     * @param edgeWeight The weight of this edge
     * @throws NullPointerException     when any of the parameters are null
     * @throws MissingResourceException when keys doesn't exist
     * @requires nothing. The Terminator lives
     * @modifies adjList
     */
    public void addEdge(String parentNode, String childNode, String edgeLabel, Integer edgeWeight)
            throws NullPointerException, MissingResourceException {
        //no
        if (parentNode == null || childNode == null || edgeLabel == null || edgeWeight == null) {
            throw new NullPointerException();
        }
        //check if nodes exist
        if (!adjList.containsKey(parentNode) || !adjList.containsKey(childNode)) {
            throw new MissingResourceException("", "", "");
        }

        //build edge data
        HashSet<Triple<String, String, Integer>> tmpSet = adjList.get(parentNode);
        tmpSet.add(new Triple<>(childNode, edgeLabel, edgeWeight));
        adjList.replace(parentNode, tmpSet);

        //add second link for undirected graphs
        if (!isDirected) {
            //build edge data
            tmpSet = adjList.get(childNode);
            tmpSet.add(new Triple<>(parentNode, edgeLabel, edgeWeight));
            adjList.replace(childNode, tmpSet);
        }
        // assert (checkRep());
    }

    /**
     * Ensures representation isn't violated
     *
     * @return true if rep is kept
     */
    private boolean checkRep() {
        HashSet<String> set = getNodes();
        if (!this.isDirected) {
            for (String i : set) {
                HashSet<Triple<String, String, Integer>> items = adjList.get(i);
                for (Triple<String, String, Integer> item : items) {
                    Triple<String, String, Integer> test = new Triple<>(i, item.y, item.z);
                    if (!adjList.containsKey(item.x)) { return false; }
                    if (!adjList.get(item.x).contains(test)) {
                        return false;
                    }
                }
            }
        } else {
            //duplicates are already handled by HashSet and HashMap, and directed graphs aren't necessarily well connected. oh well
        }
        return true;
    }

    /**
     * Standard class overrides
     */
    @Override
    public String toString() {
        return "Graph{" +
                "weighted=" + weighted +
                ", adjList=" + adjList +
                ", isDirected='" + isDirected + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Graph)) return false;
        Graph graph = (Graph) o;
        return Objects.equals(weighted, graph.weighted) && Objects.equals(adjList, graph.adjList) && Objects.equals(isDirected, graph.isDirected);
    }

    @Override
    public int hashCode() {
        return Objects.hash(weighted, adjList, isDirected);
    }
}
